"use client"

import { WifiOff } from "lucide-react"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Button } from "@/components/ui/button"
import { useAuth } from "@/context/auth-context"

export function OfflineBanner() {
  const { isOffline, retryConnection, error } = useAuth()

  if (!isOffline) return null

  return (
    <Alert variant="destructive" className="mb-4">
      <WifiOff className="h-4 w-4" />
      <AlertTitle>Sin conexión</AlertTitle>
      <AlertDescription className="flex flex-col gap-2">
        <p>{error || "No hay conexión a internet. Algunas funciones pueden estar limitadas."}</p>
        <Button variant="outline" size="sm" onClick={() => retryConnection()} className="w-fit">
          Reintentar conexión
        </Button>
      </AlertDescription>
    </Alert>
  )
}
