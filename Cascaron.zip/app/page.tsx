"use client"

import { useEffect, useState } from "react"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import Image from "next/image"
import { FileText, ArrowRight, CheckCircle } from "lucide-react"
import { useSession } from "@supabase/auth-helpers-react"

export default function HomePage() {
  const session = useSession()
  const [mounted, setMounted] = useState(false)

  // Evitar problemas de hidratación
  useEffect(() => {
    setMounted(true)
  }, [])

  if (!mounted) {
    return (
      <div className="flex justify-center items-center min-h-[60vh]">
        <div className="text-center">
          <div className="h-8 w-8 animate-spin mx-auto mb-4 border-4 border-[#9ACA3C] border-t-transparent rounded-full"></div>
          <p className="text-gray-600">Cargando...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-16 py-8">
      {/* Hero Section */}
      <section className="flex flex-col md:flex-row gap-8 items-center">
        <div className="flex-1 space-y-6">
          <h1 className="text-4xl md:text-5xl font-bold text-[#1e1e2d]">
            Pedidos de Almuerzos Escolares <span className="text-[#9ACA3C]">Simplificados</span>
          </h1>
          <p className="text-lg text-gray-600">
            Plataforma fácil de usar para gestionar los pedidos de almuerzos escolares de tus hijos. Ahorra tiempo y
            asegúrate de que tus hijos reciban comidas nutritivas.
          </p>
          <div className="flex flex-wrap gap-4">
            {session ? (
              <Button asChild size="lg" className="bg-[#9ACA3C] hover:bg-[#8BB52E]">
                <Link href="/dashboard">
                  Ir al Dashboard <ArrowRight className="ml-2 h-5 w-5" />
                </Link>
              </Button>
            ) : (
              <>
                <Button asChild size="lg" className="bg-[#9ACA3C] hover:bg-[#8BB52E]">
                  <Link href="/registro">
                    Registrarse <ArrowRight className="ml-2 h-5 w-5" />
                  </Link>
                </Button>
                <Button asChild size="lg" variant="outline">
                  <Link href="/login">Iniciar Sesión</Link>
                </Button>
              </>
            )}
          </div>
        </div>
        <div className="flex-1">
          <div className="relative h-64 md:h-96 w-full">
            <Image
              src="/food-order-icon.png"
              alt="Pedidos de Almuerzos Escolares"
              fill
              style={{ objectFit: "contain" }}
              priority
            />
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="space-y-8">
        <h2 className="text-3xl font-bold text-center text-[#1e1e2d]">
          ¿Por qué elegir nuestra <span className="text-[#9ACA3C]">plataforma</span>?
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="bg-white p-6 rounded-lg shadow-md hover:shadow-lg transition-shadow">
            <div className="bg-[#F5F8EE] p-3 rounded-full w-12 h-12 flex items-center justify-center mb-4">
              <FileText className="text-[#9ACA3C] h-6 w-6" />
            </div>
            <h3 className="text-xl font-bold mb-2">Pedidos Fáciles</h3>
            <p className="text-gray-600">
              Realiza pedidos de almuerzos para tus hijos en minutos con nuestro formulario intuitivo.
            </p>
          </div>
          <div className="bg-white p-6 rounded-lg shadow-md hover:shadow-lg transition-shadow">
            <div className="bg-[#F5F8EE] p-3 rounded-full w-12 h-12 flex items-center justify-center mb-4">
              <CheckCircle className="text-[#9ACA3C] h-6 w-6" />
            </div>
            <h3 className="text-xl font-bold mb-2">Comidas Nutritivas</h3>
            <p className="text-gray-600">
              Menús balanceados y nutritivos, diseñados para satisfacer las necesidades de los estudiantes.
            </p>
          </div>
          <div className="bg-white p-6 rounded-lg shadow-md hover:shadow-lg transition-shadow">
            <div className="bg-[#F5F8EE] p-3 rounded-full w-12 h-12 flex items-center justify-center mb-4">
              <FileText className="text-[#9ACA3C] h-6 w-6" />
            </div>
            <h3 className="text-xl font-bold mb-2">Historial Completo</h3>
            <p className="text-gray-600">
              Accede al historial de pedidos y mantén un registro de los almuerzos de tus hijos.
            </p>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-[#F5F8EE] p-8 rounded-lg shadow-md text-center">
        <h2 className="text-3xl font-bold mb-4 text-[#1e1e2d]">
          Comienza a usar nuestra <span className="text-[#9ACA3C]">plataforma</span> hoy mismo
        </h2>
        <p className="text-lg text-gray-600 mb-6 max-w-2xl mx-auto">
          Regístrate ahora y simplifica la gestión de los almuerzos escolares de tus hijos. ¡Es gratis y fácil de usar!
        </p>
        {session ? (
          <Button asChild size="lg" className="bg-[#9ACA3C] hover:bg-[#8BB52E]">
            <Link href="/dashboard">
              Ir al Dashboard <ArrowRight className="ml-2 h-5 w-5" />
            </Link>
          </Button>
        ) : (
          <Button asChild size="lg" className="bg-[#9ACA3C] hover:bg-[#8BB52E]">
            <Link href="/registro">
              Registrarse Ahora <ArrowRight className="ml-2 h-5 w-5" />
            </Link>
          </Button>
        )}
      </section>
    </div>
  )
}
