"use client"

import { useEffect, useState } from "react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { FileText, History, User2, AlertTriangle } from "lucide-react"
import Link from "next/link"
import { useSession } from "@supabase/auth-helpers-react"
import AuthRedirect from "@/components/auth-redirect"

export default function DashboardPage() {
  const session = useSession()
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    // Dar tiempo para que la sesión se cargue
    const timer = setTimeout(() => {
      setIsLoading(false)
    }, 1000)

    return () => clearTimeout(timer)
  }, [])

  // Si está cargando, mostrar indicador
  if (isLoading) {
    return (
      <div className="flex justify-center items-center min-h-[60vh]">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-[#9ACA3C]"></div>
      </div>
    )
  }

  // Si no hay sesión después de cargar, usar el componente de redirección
  if (!session) {
    return <AuthRedirect redirectTo="/dashboard" message="Verificando sesión..." />
  }

  // Si hay sesión, mostrar el dashboard
  return <DashboardContent session={session} />
}

function DashboardContent({ session }: { session: any }) {
  const [userName, setUserName] = useState("")

  useEffect(() => {
    // Extraer el nombre del usuario del email
    if (session?.user?.email) {
      const emailParts = session.user.email.split("@")
      if (emailParts.length > 0) {
        // Capitalizar la primera letra
        const name = emailParts[0]
        setUserName(name.charAt(0).toUpperCase() + name.slice(1))
      }
    }
  }, [session])

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-4">
        <h1 className="text-3xl font-bold text-[#1e1e2d]">Dashboard</h1>
        <p className="text-gray-600">
          Bienvenido, <span className="font-semibold">{userName}</span>. Desde aquí puedes gestionar tus pedidos y
          acceder a todas las funciones.
        </p>
      </div>

      {/* Tarjetas de acciones principales */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card className="shadow-md hover:shadow-lg transition-shadow">
          <CardHeader className="bg-[#F5F8EE] rounded-t-lg">
            <CardTitle className="flex items-center text-[#9ACA3C]">
              <FileText className="mr-2 h-5 w-5" />
              Realizar Pedido
            </CardTitle>
            <CardDescription>Haz un nuevo pedido para tus hijos</CardDescription>
          </CardHeader>
          <CardContent className="pt-4">
            <p className="text-sm text-gray-600">
              Completa el formulario para realizar un pedido de almuerzos escolares.
            </p>
          </CardContent>
          <CardFooter>
            <Button asChild className="w-full bg-[#9ACA3C] hover:bg-[#8BB52E]">
              <Link href="/formulario">Ir al Formulario</Link>
            </Button>
          </CardFooter>
        </Card>

        <Card className="shadow-md hover:shadow-lg transition-shadow">
          <CardHeader className="bg-[#F5F8EE] rounded-t-lg">
            <CardTitle className="flex items-center text-[#9ACA3C]">
              <History className="mr-2 h-5 w-5" />
              Historial de Pedidos
            </CardTitle>
            <CardDescription>Revisa tus pedidos anteriores</CardDescription>
          </CardHeader>
          <CardContent className="pt-4">
            <p className="text-sm text-gray-600">Consulta el estado y detalles de todos tus pedidos anteriores.</p>
          </CardContent>
          <CardFooter>
            <Button asChild className="w-full bg-[#9ACA3C] hover:bg-[#8BB52E]">
              <Link href="/historial">Ver Historial</Link>
            </Button>
          </CardFooter>
        </Card>

        <Card className="shadow-md hover:shadow-lg transition-shadow">
          <CardHeader className="bg-[#F5F8EE] rounded-t-lg">
            <CardTitle className="flex items-center text-[#9ACA3C]">
              <User2 className="mr-2 h-5 w-5" />
              Mi Perfil
            </CardTitle>
            <CardDescription>Gestiona tu información personal</CardDescription>
          </CardHeader>
          <CardContent className="pt-4">
            <p className="text-sm text-gray-600">Actualiza tus datos personales y la información de tus hijos.</p>
          </CardContent>
          <CardFooter>
            <Button asChild className="w-full bg-[#9ACA3C] hover:bg-[#8BB52E]">
              <Link href="/perfil">Editar Perfil</Link>
            </Button>
          </CardFooter>
        </Card>
      </div>

      {/* Información adicional */}
      <Card className="shadow-md bg-blue-50 border-blue-200">
        <CardHeader>
          <CardTitle className="text-blue-700 flex items-center">
            <AlertTriangle className="mr-2 h-5 w-5" />
            Información Importante
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-blue-700">
            Recuerda que los pedidos deben realizarse con al menos 24 horas de anticipación. Para cualquier consulta,
            contáctanos a través de nuestro formulario de ayuda.
          </p>
        </CardContent>
      </Card>
    </div>
  )
}
