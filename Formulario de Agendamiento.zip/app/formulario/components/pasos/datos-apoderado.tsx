"use client"

import type React from "react"
import { useState, useEffect } from "react"

import type { FormData } from "../formulario-multi-step"

interface DatosApoderadoProps {
  formData: FormData
  actualizarFormData: (data: Partial<FormData>) => void
  siguientePaso: () => void
}

export function DatosApoderado({ formData, actualizarFormData, siguientePaso }: DatosApoderadoProps) {
  const [mostrarMensajeSala, setMostrarMensajeSala] = useState(false)
  const [mostrarSelectorCurso, setMostrarSelectorCurso] = useState(false)

  // Efecto para mostrar/ocultar el mensaje de sala y selector de curso según el lugar de retiro seleccionado
  useEffect(() => {
    const esSala = formData.lugarRetiro === "Sala"
    setMostrarMensajeSala(esSala)
    setMostrarSelectorCurso(esSala)

    // Si cambia el lugar de retiro y ya no es Sala, limpiar los campos de curso y letra
    if (!esSala) {
      actualizarFormData({
        cursoSala: null,
        letraSala: null,
      })
    }
  }, [formData.lugarRetiro])

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    siguientePaso()
  }

  // Verificar si el formulario está completo para habilitar el botón de continuar
  const formularioCompleto = () => {
    if (formData.tipoUsuario === "funcionario") {
      if (!formData.lugarRetiro) return false

      // Si el lugar es Sala, verificar que se haya seleccionado curso y letra
      if (formData.lugarRetiro === "Sala" && (!formData.cursoSala || !formData.letraSala)) {
        return false
      }
    }
    return true
  }

  // Si es cliente recurrente, mostrar los datos precargados
  if (formData.esClienteRecurrente) {
    return (
      <div className="transition-all duration-300">
        <h2 className="text-xl font-semibold text-gray-800 mb-6">
          {formData.tipoUsuario === "funcionario" ? "Datos del Funcionario" : "Datos del Apoderado"}
        </h2>

        <div className="bg-[#F5F8EE] p-4 rounded-xl mb-6">
          <p className="text-sm text-gray-700">
            <span className="font-medium">¡Bienvenido de nuevo!</span> Hemos cargado tus datos automáticamente.
          </p>
        </div>

        <div className="space-y-6">
          <div className="bg-[#F5F8EE] rounded-xl p-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <p className="text-sm text-gray-500">Nombre:</p>
                <p className="text-base font-medium">{formData.nombreApoderado}</p>
              </div>
              <div>
                <p className="text-sm text-gray-500">Correo:</p>
                <p className="text-base font-medium">{formData.correoApoderado}</p>
              </div>
              <div>
                <p className="text-sm text-gray-500">Teléfono:</p>
                <p className="text-base font-medium">{formData.telefono}</p>
              </div>

              {formData.tipoUsuario === "funcionario" && (
                <div>
                  <p className="text-sm text-gray-500">Lugar de retiro:</p>
                  <select
                    value={formData.lugarRetiro || ""}
                    onChange={(e) =>
                      actualizarFormData({
                        lugarRetiro: e.target.value as "Casino1" | "Casino2" | "Sala" | null,
                      })
                    }
                    className="w-full px-4 py-3 rounded-xl border border-gray-300 focus:outline-none focus:ring-2 focus:ring-[#9ACA3C] focus:border-transparent transition-all duration-200"
                    required
                  >
                    <option value="">Seleccionar lugar</option>
                    <option value="Casino1">Casino 1</option>
                    <option value="Casino2">Casino 2</option>
                    <option value="Sala">Sala</option>
                  </select>
                </div>
              )}
            </div>

            {/* Selector de curso y letra para entrega en sala */}
            {mostrarSelectorCurso && (
              <div className="mt-4 space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label htmlFor="cursoSala" className="block text-sm font-medium text-gray-700 mb-2">
                      Curso para entrega en sala
                    </label>
                    <select
                      id="cursoSala"
                      value={formData.cursoSala || ""}
                      onChange={(e) =>
                        actualizarFormData({
                          cursoSala: e.target.value as "Prekinder" | "Kinder" | "1st Grade" | "2nd Grade" | null,
                        })
                      }
                      className="w-full px-4 py-3 rounded-xl border border-gray-300 focus:outline-none focus:ring-2 focus:ring-[#9ACA3C] focus:border-transparent transition-all duration-200"
                      required
                    >
                      <option value="">Seleccionar curso</option>
                      <option value="Prekinder">Prekinder</option>
                      <option value="Kinder">Kinder</option>
                      <option value="1st Grade">1st Grade</option>
                      <option value="2nd Grade">2nd Grade</option>
                    </select>
                  </div>
                  <div>
                    <label htmlFor="letraSala" className="block text-sm font-medium text-gray-700 mb-2">
                      Letra del curso
                    </label>
                    <select
                      id="letraSala"
                      value={formData.letraSala || ""}
                      onChange={(e) =>
                        actualizarFormData({
                          letraSala: e.target.value as "A" | "B" | "C" | "D" | null,
                        })
                      }
                      className="w-full px-4 py-3 rounded-xl border border-gray-300 focus:outline-none focus:ring-2 focus:ring-[#9ACA3C] focus:border-transparent transition-all duration-200"
                      required
                    >
                      <option value="">Seleccionar letra</option>
                      <option value="A">A</option>
                      <option value="B">B</option>
                      <option value="C">C</option>
                      <option value="D">D</option>
                    </select>
                  </div>
                </div>
              </div>
            )}

            {mostrarMensajeSala && (
              <div className="mt-4 bg-yellow-50 p-3 rounded-lg border border-yellow-200">
                <p className="text-sm text-yellow-700">
                  <span className="font-medium">Nota:</span> La entrega en sala solo está disponible para Playgroup,
                  Kinder, 1° grado y 2° grado. Para otros cursos, se entregará en el casino correspondiente.
                </p>
              </div>
            )}
          </div>

          <div className="pt-4">
            <button
              type="button"
              onClick={siguientePaso}
              className="w-full bg-[#9ACA3C] text-white py-3 px-6 rounded-xl hover:bg-[#8BB52E] focus:outline-none focus:ring-2 focus:ring-[#9ACA3C] focus:ring-offset-2 transition-all duration-200 disabled:opacity-50"
              disabled={!formularioCompleto()}
            >
              Continuar
            </button>
          </div>
        </div>
      </div>
    )
  }

  // Si no es cliente recurrente, mostrar el formulario normal
  return (
    <div className="transition-all duration-300">
      <h2 className="text-xl font-semibold text-gray-800 mb-6">
        {formData.tipoUsuario === "funcionario" ? "Datos del Funcionario" : "Datos del Apoderado"}
      </h2>

      <form onSubmit={handleSubmit}>
        <div className="space-y-6">
          <div>
            <label htmlFor="nombreApoderado" className="block text-base font-medium text-gray-700 mb-2">
              Nombre Completo
            </label>
            <input
              type="text"
              id="nombreApoderado"
              value={formData.nombreApoderado}
              onChange={(e) => actualizarFormData({ nombreApoderado: e.target.value })}
              className="w-full px-4 py-3 rounded-xl border border-gray-300 focus:outline-none focus:ring-2 focus:ring-[#9ACA3C] focus:border-transparent transition-all duration-200"
              placeholder="Ingresa tu nombre completo"
              required
            />
          </div>

          <div>
            <label htmlFor="correoApoderado" className="block text-base font-medium text-gray-700 mb-2">
              Correo Electrónico
            </label>
            <input
              type="email"
              id="correoApoderado"
              value={formData.correoApoderado}
              onChange={(e) => actualizarFormData({ correoApoderado: e.target.value })}
              className="w-full px-4 py-3 rounded-xl border border-gray-300 focus:outline-none focus:ring-2 focus:ring-[#9ACA3C] focus:border-transparent transition-all duration-200"
              placeholder="Ingresa tu correo electrónico"
              required
            />
          </div>

          <div>
            <label htmlFor="telefono" className="block text-base font-medium text-gray-700 mb-2">
              Teléfono
            </label>
            <input
              type="tel"
              id="telefono"
              value={formData.telefono}
              onChange={(e) => actualizarFormData({ telefono: e.target.value })}
              className="w-full px-4 py-3 rounded-xl border border-gray-300 focus:outline-none focus:ring-2 focus:ring-[#9ACA3C] focus:border-transparent transition-all duration-200"
              placeholder="Ingresa tu número de teléfono"
              required
            />
          </div>

          {formData.tipoUsuario === "funcionario" && (
            <div>
              <label htmlFor="lugarRetiro" className="block text-base font-medium text-gray-700 mb-2">
                Lugar de Retiro
              </label>
              <select
                id="lugarRetiro"
                value={formData.lugarRetiro || ""}
                onChange={(e) =>
                  actualizarFormData({
                    lugarRetiro: e.target.value as "Casino1" | "Casino2" | "Sala" | null,
                  })
                }
                className="w-full px-4 py-3 rounded-xl border border-gray-300 focus:outline-none focus:ring-2 focus:ring-[#9ACA3C] focus:border-transparent transition-all duration-200"
                required
              >
                <option value="">Seleccionar lugar</option>
                <option value="Casino1">Casino 1</option>
                <option value="Casino2">Casino 2</option>
                <option value="Sala">Sala</option>
              </select>
            </div>
          )}

          {/* Selector de curso y letra para entrega en sala */}
          {mostrarSelectorCurso && (
            <div className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label htmlFor="cursoSala" className="block text-base font-medium text-gray-700 mb-2">
                    Curso para entrega en sala
                  </label>
                  <select
                    id="cursoSala"
                    value={formData.cursoSala || ""}
                    onChange={(e) =>
                      actualizarFormData({
                        cursoSala: e.target.value as "Prekinder" | "Kinder" | "1st Grade" | "2nd Grade" | null,
                      })
                    }
                    className="w-full px-4 py-3 rounded-xl border border-gray-300 focus:outline-none focus:ring-2 focus:ring-[#9ACA3C] focus:border-transparent transition-all duration-200"
                    required
                  >
                    <option value="">Seleccionar curso</option>
                    <option value="Prekinder">Prekinder</option>
                    <option value="Kinder">Kinder</option>
                    <option value="1st Grade">1st Grade</option>
                    <option value="2nd Grade">2nd Grade</option>
                  </select>
                </div>
                <div>
                  <label htmlFor="letraSala" className="block text-base font-medium text-gray-700 mb-2">
                    Letra del curso
                  </label>
                  <select
                    id="letraSala"
                    value={formData.letraSala || ""}
                    onChange={(e) =>
                      actualizarFormData({
                        letraSala: e.target.value as "A" | "B" | "C" | "D" | null,
                      })
                    }
                    className="w-full px-4 py-3 rounded-xl border border-gray-300 focus:outline-none focus:ring-2 focus:ring-[#9ACA3C] focus:border-transparent transition-all duration-200"
                    required
                  >
                    <option value="">Seleccionar letra</option>
                    <option value="A">A</option>
                    <option value="B">B</option>
                    <option value="C">C</option>
                    <option value="D">D</option>
                  </select>
                </div>
              </div>
            </div>
          )}

          {mostrarMensajeSala && (
            <div className="bg-yellow-50 p-3 rounded-lg border border-yellow-200">
              <p className="text-sm text-yellow-700">
                <span className="font-medium">Nota:</span> La entrega en sala solo está disponible para Playgroup,
                Kinder, 1° grado y 2° grado. Para otros cursos, se entregará en el casino correspondiente.
              </p>
            </div>
          )}

          <div className="pt-4">
            <button
              type="submit"
              className="w-full bg-[#9ACA3C] text-white py-3 px-6 rounded-xl hover:bg-[#8BB52E] focus:outline-none focus:ring-2 focus:ring-[#9ACA3C] focus:ring-offset-2 transition-all duration-200 disabled:opacity-50"
              disabled={!formularioCompleto()}
            >
              Siguiente
            </button>
          </div>
        </div>
      </form>
    </div>
  )
}
