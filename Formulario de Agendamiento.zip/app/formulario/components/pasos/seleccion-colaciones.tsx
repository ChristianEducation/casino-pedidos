"use client"

import type React from "react"
import { useState, useEffect } from "react"
import type { FormData, OpcionMenu, DatosHijo } from "../formulario-multi-step"
import { consultarEstructuraTablaColaciones } from "@/lib/supabase"

interface SeleccionColacionesProps {
  formData: FormData
  actualizarFormData: (data: Partial<FormData>) => void
  siguientePaso: () => void
  anteriorPaso: () => void
  opcionesColaciones: OpcionMenu[]
}

export function SeleccionColaciones({
  formData,
  actualizarFormData,
  siguientePaso,
  anteriorPaso,
  opcionesColaciones,
}: SeleccionColacionesProps) {
  // Inicializar hijoActivo con el ID del primer hijo si existe
  const [hijoActivo, setHijoActivo] = useState<string>(() => {
    return formData.hijos.length > 0 ? formData.hijos[0].id : ""
  })

  const [colacionesCargadas, setColacionesCargadas] = useState<boolean>(false)
  const [errorColaciones, setErrorColaciones] = useState<string | null>(null)

  // Actualizar hijoActivo cuando cambian los hijos
  useEffect(() => {
    if (formData.hijos.length > 0 && !formData.hijos.find((h) => h.id === hijoActivo)) {
      setHijoActivo(formData.hijos[0].id)
    }
  }, [formData.hijos, hijoActivo])

  // Verificar las colaciones disponibles al cargar el componente
  useEffect(() => {
    const verificarColaciones = async () => {
      try {
        // Consultar directamente la tabla para verificar los datos
        const resultado = await consultarEstructuraTablaColaciones()
        console.log("Verificación de colaciones:", resultado)

        // Verificar las colaciones que recibimos como prop
        console.log("Colaciones recibidas como prop:", opcionesColaciones)

        setColacionesCargadas(true)

        if (!resultado && opcionesColaciones.length === 0) {
          setErrorColaciones("No se pudo encontrar la tabla de colaciones en la base de datos.")
        }
      } catch (error) {
        console.error("Error al verificar colaciones:", error)
        setErrorColaciones("Error al verificar colaciones en la base de datos.")
      }
    }

    verificarColaciones()
  }, [opcionesColaciones])

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    siguientePaso()
  }

  const handleColacionChange = (hijoId: string, dia: keyof DatosHijo["colaciones"], valor: string | null) => {
    actualizarFormData({
      hijos: formData.hijos.map((hijo) => {
        if (hijo.id === hijoId) {
          return {
            ...hijo,
            colaciones: {
              ...hijo.colaciones,
              [dia]: valor,
            },
          }
        }
        return hijo
      }),
    })
  }

  // Función para formatear la fecha en formato legible
  const formatearFecha = (fecha: string): string => {
    const opciones: Intl.DateTimeFormatOptions = { day: "numeric", month: "long" }
    return new Date(fecha).toLocaleDateString("es-ES", opciones)
  }

  // Función para formatear precio en pesos chilenos
  const formatearPrecio = (precio: number): string => {
    return new Intl.NumberFormat("es-CL", {
      style: "currency",
      currency: "CLP",
      minimumFractionDigits: 0,
    }).format(precio)
  }

  if (formData.hijos.length === 0) {
    return (
      <div className="transition-all duration-300">
        <h2 className="section-title">Selección de Colaciones</h2>

        <div className="info-card bg-yellow-50">
          <p className="text-sm text-yellow-700">
            {formData.tipoUsuario === "funcionario"
              ? "No has agregado hijos para pedidos. Si deseas realizar pedidos para tus hijos, regresa al paso anterior."
              : "No hay alumnos registrados. Por favor, regresa al paso anterior y agrega al menos un alumno."}
          </p>
        </div>

        <div className="pt-4">
          <button type="button" onClick={anteriorPaso} className="w-full btn-secondary">
            Volver
          </button>
        </div>
      </div>
    )
  }

  // Encontrar el hijo activo de manera segura
  const hijoActual =
    formData.hijos.length > 0 ? formData.hijos.find((hijo) => hijo.id === hijoActivo) || formData.hijos[0] : null
  const hijoIndex = hijoActual ? formData.hijos.findIndex((hijo) => hijo.id === hijoActual.id) : -1
  const esFuncionarioPrincipal = formData.tipoUsuario === "funcionario" && hijoIndex === 0

  // Función para renderizar el desplegable de colaciones con descripciones
  const renderColacionSelect = (dia: keyof DatosHijo["colaciones"]) => {
    if (!colacionesCargadas) {
      return (
        <div className="py-2 px-4 bg-gray-100 rounded-xl flex items-center justify-center">
          <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-[#9ACA3C] mr-3"></div>
          <span className="text-gray-600">Cargando colaciones...</span>
        </div>
      )
    }

    if (errorColaciones) {
      return <div className="py-2 text-red-500 text-sm bg-red-50 p-3 rounded-xl">{errorColaciones}</div>
    }

    if (opcionesColaciones.length === 0) {
      return (
        <div className="py-2 text-gray-500 text-sm bg-gray-50 p-3 rounded-xl">
          No hay opciones de colaciones disponibles. Por favor, continúe con el siguiente paso.
        </div>
      )
    }

    return (
      <select
        id={`colacion-${dia}`}
        value={hijoActual?.colaciones?.[dia] || ""}
        onChange={(e) => handleColacionChange(hijoActual.id, dia, e.target.value || null)}
        className="form-select"
      >
        <option value="">No seleccionar</option>
        {opcionesColaciones.map((opcion) => (
          <option key={opcion.id} value={opcion.nombre}>
            {opcion.descripcion} - {formatearPrecio(opcion.precio)}
          </option>
        ))}
      </select>
    )
  }

  return (
    <div className="transition-all duration-300">
      <h2 className="section-title">Selección de Colaciones</h2>

      {/* Información de depuración */}
      {!colacionesCargadas && (
        <div className="info-card">
          <p className="info-text">
            <span className="font-medium">Cargando colaciones...</span>
          </p>
        </div>
      )}

      {errorColaciones && (
        <div className="bg-red-50 border border-red-200 p-4 rounded-xl mb-6">
          <p className="text-sm text-red-700">
            <span className="font-medium">Error:</span> {errorColaciones}
          </p>
          <p className="text-sm text-red-700 mt-2">
            Puede continuar con el formulario, pero no podrá seleccionar colaciones.
          </p>
        </div>
      )}

      {colacionesCargadas && opcionesColaciones.length === 0 && !errorColaciones && (
        <div className="info-card bg-yellow-50">
          <p className="text-sm text-yellow-700">
            <span className="font-medium">No se encontraron colaciones en la base de datos.</span> Puede continuar con
            el formulario sin seleccionar colaciones.
          </p>
        </div>
      )}

      {/* Información de la semana seleccionada */}
      {formData.semanaSeleccionada && (
        <div className="info-card">
          <p className="info-text">
            <span className="font-medium">Pedido para la semana:</span> {formData.semanaSeleccionada.nombre}
          </p>
          <p className="info-text">
            <span className="font-medium">Período:</span> Del {formatearFecha(formData.semanaSeleccionada.fechaInicio)}{" "}
            al {formatearFecha(formData.semanaSeleccionada.fechaFin)}
          </p>
        </div>
      )}

      {/* Selector de hijo/alumno */}
      {formData.hijos.length > 0 && (
        <div className="mb-6">
          <label className="form-label">Selecciona para quién estás haciendo el pedido</label>
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
            {formData.hijos.map((hijo, index) => (
              <button
                key={hijo.id}
                type="button"
                onClick={() => setHijoActivo(hijo.id)}
                className={`p-3 rounded-lg text-left transition-all duration-300 ${
                  hijoActivo === hijo.id
                    ? "bg-[#F5F8EE] border-[#9ACA3C] border-2"
                    : "bg-gray-50 border border-gray-200 hover:border-[#9ACA3C]"
                }`}
              >
                <p className="font-medium">
                  {formData.tipoUsuario === "funcionario" && index === 0 ? "Tú" : hijo.nombre}
                </p>
                <p className="text-sm text-gray-600">
                  {hijo.curso} {hijo.letra}
                </p>
              </button>
            ))}
          </div>
        </div>
      )}

      <p className="text-gray-600 mb-6">
        Selecciona las opciones de colación para cada día. Puedes dejar días sin seleccionar si no deseas pedir colación
        para ese día.
      </p>

      <form onSubmit={handleSubmit}>
        <div className="space-y-6">
          {hijoActual && (
            <div className="info-card">
              <p className="info-text font-medium">
                {esFuncionarioPrincipal
                  ? "Seleccionando colaciones para ti"
                  : `Seleccionando colaciones para: ${hijoActual.nombre}`}
              </p>
            </div>
          )}

          {/* Lunes */}
          <div>
            <label htmlFor="colacion-lunes" className="form-label">
              Lunes
            </label>
            {renderColacionSelect("lunes")}
          </div>

          {/* Martes */}
          <div>
            <label htmlFor="colacion-martes" className="form-label">
              Martes
            </label>
            {renderColacionSelect("martes")}
          </div>

          {/* Miércoles */}
          <div>
            <label htmlFor="colacion-miercoles" className="form-label">
              Miércoles
            </label>
            {renderColacionSelect("miercoles")}
          </div>

          {/* Jueves */}
          <div>
            <label htmlFor="colacion-jueves" className="form-label">
              Jueves
            </label>
            {renderColacionSelect("jueves")}
          </div>

          {/* Viernes */}
          <div>
            <label htmlFor="colacion-viernes" className="form-label">
              Viernes
            </label>
            {renderColacionSelect("viernes")}
          </div>

          {/* Observaciones */}
          <div className="mt-8 border-t border-gray-200 pt-6">
            <label htmlFor="observaciones-colaciones" className="form-label">
              Observaciones sobre colaciones
            </label>
            <textarea
              id="observaciones-colaciones"
              value={formData.observacionesColaciones}
              onChange={(e) => actualizarFormData({ observacionesColaciones: e.target.value })}
              className="form-input"
              placeholder="Escribe aquí cualquier observación o requerimiento especial sobre las colaciones"
              rows={3}
            />
            <p className="mt-2 text-sm text-gray-500">
              Por ejemplo: alergias, preferencias alimentarias, restricciones dietéticas, etc.
            </p>
          </div>

          <div className="pt-4 flex space-x-4">
            <button type="button" onClick={anteriorPaso} className="w-1/2 btn-secondary">
              Anterior
            </button>
            <button type="submit" className="w-1/2 btn-primary">
              Siguiente
            </button>
          </div>
        </div>
      </form>
    </div>
  )
}
