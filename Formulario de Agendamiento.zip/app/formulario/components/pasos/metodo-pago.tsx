"use client"

import type React from "react"

import { useState } from "react"
import type { FormData } from "../formulario-multi-step"

interface MetodoPagoProps {
  formData: FormData
  actualizarFormData: (data: Partial<FormData>) => void
  siguientePaso: () => void
  anteriorPaso: () => void
}

export function MetodoPago({ formData, actualizarFormData, siguientePaso, anteriorPaso }: MetodoPagoProps) {
  const [fileError, setFileError] = useState<string | null>(null)

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    siguientePaso()
  }

  return (
    <div className="transition-all duration-300">
      <h2 className="text-xl font-semibold text-gray-800 mb-6">Método de Pago</h2>

      <form onSubmit={handleSubmit}>
        <div className="space-y-6">
          <div className="space-y-4">
            <label className="block text-base font-medium text-gray-700 mb-2">Selecciona tu método de pago</label>

            <div className="space-y-3">
              <div className="flex items-center">
                <input
                  type="radio"
                  id="pago-pendiente"
                  name="metodoPago"
                  value="Pendiente"
                  checked={formData.metodoPago === "Pendiente"}
                  onChange={() => actualizarFormData({ metodoPago: "Pendiente" })}
                  className="h-5 w-5 text-[#9ACA3C] focus:ring-[#9ACA3C]"
                />
                <label htmlFor="pago-pendiente" className="ml-3 block text-base text-gray-700">
                  Pagaré después
                </label>
              </div>

              <div className="flex items-center">
                <input
                  type="radio"
                  id="pago-espera"
                  name="metodoPago"
                  value="espera_pago"
                  checked={formData.metodoPago === "espera_pago"}
                  onChange={() => actualizarFormData({ metodoPago: "espera_pago" })}
                  className="h-5 w-5 text-[#9ACA3C] focus:ring-[#9ACA3C]"
                />
                <label htmlFor="pago-espera" className="ml-3 block text-base text-gray-700">
                  Pagar ahora
                </label>
              </div>
            </div>
          </div>

          <div className="pt-4 flex space-x-4">
            <button
              type="button"
              onClick={anteriorPaso}
              className="w-1/2 bg-gray-200 text-gray-800 py-3 px-6 rounded-xl hover:bg-gray-300 focus:outline-none focus:ring-2 focus:ring-gray-500 focus:ring-offset-2 transition-all duration-200"
            >
              Anterior
            </button>
            <button
              type="submit"
              className="w-1/2 bg-[#9ACA3C] text-white py-3 px-6 rounded-xl hover:bg-[#8BB52E] focus:outline-none focus:ring-2 focus:ring-[#9ACA3C] focus:ring-offset-2 transition-all duration-200"
            >
              Siguiente
            </button>
          </div>
        </div>
      </form>
    </div>
  )
}
