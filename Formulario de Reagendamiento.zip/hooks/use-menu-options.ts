"use client"

import { useState, useEffect } from "react"
import { getMenuOptionsForDay } from "@/lib/menu-utils"
import type { OpcionMenu } from "@/types"

export function useMenuOptions(date: string) {
  const [options, setOptions] = useState<OpcionMenu[]>([])
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    async function fetchOptions() {
      if (!date) {
        setOptions([])
        return
      }

      try {
        setLoading(true)
        setError(null)

        const menuOptions = await getMenuOptionsForDay(date)
        setOptions(menuOptions)
      } catch (err) {
        console.error(`Error al cargar opciones de menú para ${date}:`, err)
        setError("Error al cargar las opciones de menú. Por favor, intente nuevamente.")
      } finally {
        setLoading(false)
      }
    }

    fetchOptions()
  }, [date])

  return { options, loading, error }
}
