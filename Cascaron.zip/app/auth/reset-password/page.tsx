"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { toast } from "@/components/ui/use-toast"
import Image from "next/image"
import Link from "next/link"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { AlertCircle, CheckCircle2 } from "lucide-react"
import { supabase } from "@/lib/supabase-client"
import { useRouter } from "next/navigation"

export default function ResetPasswordPage() {
  const [password, setPassword] = useState("")
  const [confirmPassword, setConfirmPassword] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [resetSuccess, setResetSuccess] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const router = useRouter()

  useEffect(() => {
    // Verificar que el usuario llegó aquí desde un enlace de restablecimiento de contraseña
    const checkResetPasswordSession = async () => {
      if (!supabase) {
        setError("Cliente de Supabase no inicializado. Verifica las variables de entorno.")
        return
      }

      const { data, error } = await supabase.auth.getSession()
      if (error) {
        setError("Error al verificar la sesión. Por favor, intenta nuevamente.")
        return
      }

      if (!data.session) {
        setError(
          "No se encontró una sesión válida para restablecer la contraseña. Por favor, solicita un nuevo enlace de restablecimiento.",
        )
      }
    }

    checkResetPasswordSession()
  }, [])

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (password !== confirmPassword) {
      setError("Las contraseñas no coinciden")
      toast({
        title: "Error",
        description: "Las contraseñas no coinciden",
        variant: "destructive",
      })
      return
    }

    if (password.length < 6) {
      setError("La contraseña debe tener al menos 6 caracteres")
      toast({
        title: "Error",
        description: "La contraseña debe tener al menos 6 caracteres",
        variant: "destructive",
      })
      return
    }

    setIsLoading(true)
    setError(null)

    try {
      if (!supabase) {
        throw new Error("Cliente de Supabase no inicializado. Verifica las variables de entorno.")
      }

      const { error } = await supabase.auth.updateUser({
        password,
      })

      if (error) throw error

      setResetSuccess(true)
      toast({
        title: "Contraseña actualizada",
        description: "Tu contraseña ha sido actualizada correctamente.",
      })

      // Redirigir al login después de 3 segundos
      setTimeout(() => {
        router.push("/login")
      }, 3000)
    } catch (error: any) {
      setError(error.message || "Error al actualizar la contraseña")
      toast({
        title: "Error",
        description: error.message || "Error al actualizar la contraseña",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  if (resetSuccess) {
    return (
      <div className="flex justify-center items-center min-h-[80vh]">
        <Card className="w-full max-w-md shadow-lg">
          <CardHeader className="space-y-1 bg-green-50">
            <div className="flex justify-center mb-4 text-green-500">
              <CheckCircle2 size={48} />
            </div>
            <CardTitle className="text-2xl text-center text-green-600">¡Contraseña Actualizada!</CardTitle>
            <CardDescription className="text-center">Tu contraseña ha sido actualizada correctamente.</CardDescription>
          </CardHeader>
          <CardContent className="pt-6">
            <p className="text-gray-700 text-center">
              Serás redirigido a la página de inicio de sesión en unos segundos...
            </p>
          </CardContent>
          <CardFooter className="flex flex-col space-y-4">
            <Button asChild className="w-full bg-[#9ACA3C] hover:bg-[#8BB52E]">
              <Link href="/login">Ir a Iniciar Sesión</Link>
            </Button>
          </CardFooter>
        </Card>
      </div>
    )
  }

  return (
    <div className="flex justify-center items-center min-h-[80vh]">
      <Card className="w-full max-w-md shadow-lg">
        <CardHeader className="space-y-1 bg-[#F5F8EE]">
          <div className="flex justify-center mb-4">
            <div className="relative w-48 h-16">
              <Image src="/images/logo.png" alt="Delicias Food Service" fill style={{ objectFit: "contain" }} />
            </div>
          </div>
          <CardTitle className="text-2xl text-center text-[#9ACA3C]">Restablecer Contraseña</CardTitle>
          <CardDescription className="text-center">Ingresa tu nueva contraseña</CardDescription>
        </CardHeader>
        <CardContent className="pt-6">
          <div className="space-y-4">
            {error && (
              <Alert variant="destructive">
                <AlertCircle className="h-4 w-4" />
                <AlertTitle>Error</AlertTitle>
                <AlertDescription>{error}</AlertDescription>
              </Alert>
            )}

            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="password">Nueva Contraseña</Label>
                <Input
                  id="password"
                  type="password"
                  placeholder="••••••••"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                  minLength={6}
                  className="border-gray-300 focus:border-[#9ACA3C] focus:ring-[#9ACA3C]"
                />
                <p className="text-xs text-gray-500">La contraseña debe tener al menos 6 caracteres</p>
              </div>
              <div className="space-y-2">
                <Label htmlFor="confirmPassword">Confirmar Contraseña</Label>
                <Input
                  id="confirmPassword"
                  type="password"
                  placeholder="••••••••"
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  required
                  className="border-gray-300 focus:border-[#9ACA3C] focus:ring-[#9ACA3C]"
                />
              </div>
              <Button type="submit" className="w-full bg-[#9ACA3C] hover:bg-[#8BB52E]" disabled={isLoading}>
                {isLoading ? "Actualizando..." : "Actualizar Contraseña"}
              </Button>
            </form>
          </div>
        </CardContent>
        <CardFooter className="flex flex-col space-y-4">
          <div className="text-center text-sm">
            <Link href="/login" className="text-[#9ACA3C] hover:underline">
              Volver a Iniciar Sesión
            </Link>
          </div>
        </CardFooter>
      </Card>
    </div>
  )
}
