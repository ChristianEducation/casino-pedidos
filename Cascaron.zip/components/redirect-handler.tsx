"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { toast } from "@/components/ui/use-toast"

interface RedirectHandlerProps {
  to: string
  message?: string
  delay?: number
  showToast?: boolean
  toastTitle?: string
  toastDescription?: string
}

export default function RedirectHandler({
  to,
  message = "Redirigiendo...",
  delay = 100,
  showToast = false,
  toastTitle,
  toastDescription,
}: RedirectHandlerProps) {
  const router = useRouter()
  const [isRedirecting, setIsRedirecting] = useState(true)

  useEffect(() => {
    if (!isRedirecting) return

    console.log(`RedirectHandler: Redirigiendo a ${to} en ${delay}ms`)

    if (showToast && toastTitle) {
      toast({
        title: toastTitle,
        description: toastDescription,
      })
    }

    const redirectTimeout = setTimeout(() => {
      router.push(to)
    }, delay)

    return () => {
      clearTimeout(redirectTimeout)
    }
  }, [to, delay, router, isRedirecting, showToast, toastTitle, toastDescription])

  return (
    <div className="flex justify-center items-center min-h-[60vh]">
      <div className="text-center">
        <div className="h-8 w-8 animate-spin mx-auto mb-4 border-4 border-[#9ACA3C] border-t-transparent rounded-full"></div>
        <p className="text-gray-600">{message}</p>
      </div>
    </div>
  )
}
