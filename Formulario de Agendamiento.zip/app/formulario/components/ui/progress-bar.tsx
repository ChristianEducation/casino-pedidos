interface ProgressBarProps {
  paso: number
  totalPasos: number
  tipoUsuario?: "apoderado" | "funcionario" | null
}

export function ProgressBar({ paso, totalPasos, tipoUsuario }: ProgressBarProps) {
  const porcentaje = (paso / totalPasos) * 100

  return (
    <div className="w-full">
      <div className="flex justify-between mb-2">
        {Array.from({ length: totalPasos }).map((_, index) => (
          <div
            key={index}
            className={`flex flex-col items-center ${index + 1 <= paso ? "text-[#9ACA3C]" : "text-gray-400"}`}
          >
            <div
              className={`w-8 h-8 rounded-full flex items-center justify-center mb-1 
                ${index + 1 <= paso ? "bg-[#9ACA3C] text-white" : "bg-gray-200 text-gray-500"}`}
            >
              {index + 1}
            </div>
            <span className="text-xs hidden sm:block">
              {index === 0 && "Apoderado"}
              {index === 1 && (tipoUsuario === "funcionario" ? "Hijo" : "Alumno")}
              {index === 2 && "Almuerzos"}
              {index === 3 && "Colaciones"}
              {index === 4 && "Pago"}
              {index === 5 && "Resumen"}
            </span>
          </div>
        ))}
      </div>
      <div className="w-full bg-gray-200 rounded-full h-2.5">
        <div
          className="bg-[#9ACA3C] h-2.5 rounded-full transition-all duration-300"
          style={{ width: `${porcentaje}%` }}
        ></div>
      </div>
    </div>
  )
}
