"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { ArrowLeft } from "lucide-react"
import Link from "next/link"
import ProtectedRoute from "@/components/protected-route"

export default function FormularioPage() {
  return (
    <ProtectedRoute>
      <FormularioContent />
    </ProtectedRoute>
  )
}

function FormularioContent() {
  const [isLoading, setIsLoading] = useState(true)

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-2">
        <Button variant="ghost" size="icon" asChild>
          <Link href="/dashboard">
            <ArrowLeft className="h-5 w-5" />
            <span className="sr-only">Volver</span>
          </Link>
        </Button>
        <h1 className="text-3xl font-bold tracking-tight text-gray-800">Formulario de Pedidos</h1>
      </div>

      <Card className="border border-gray-200 shadow-sm">
        <CardHeader className="bg-[#F5F8EE]">
          <CardTitle className="text-xl text-[#9ACA3C]">Realizar Pedido</CardTitle>
          <CardDescription>Complete el formulario a continuación para realizar su pedido escolar</CardDescription>
        </CardHeader>
        <CardContent className="p-0 h-[800px] relative">
          {isLoading && (
            <div className="absolute inset-0 flex items-center justify-center bg-white bg-opacity-80 z-10">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-[#9ACA3C]"></div>
            </div>
          )}
          <iframe
            src="https://pedidosdeliciasfoodservices.vercel.app/"
            className="w-full h-full border-0"
            onLoad={() => setIsLoading(false)}
            title="Formulario de Pedidos"
          />
        </CardContent>
      </Card>
    </div>
  )
}
