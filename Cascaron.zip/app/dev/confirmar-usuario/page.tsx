"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { toast } from "@/components/ui/use-toast"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Info } from "lucide-react"
import { supabase } from "@/lib/supabase-client"
import Link from "next/link"

export default function ConfirmarUsuarioPage() {
  const [email, setEmail] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [result, setResult] = useState<string | null>(null)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)
    setResult(null)

    try {
      if (!supabase) {
        throw new Error("Cliente de Supabase no inicializado. Verifica las variables de entorno.")
      }

      // Buscar el usuario por correo electrónico
      const { data, error } = await supabase.auth.admin.listUsers()

      if (error) {
        throw new Error("No se pudo obtener la lista de usuarios. Asegúrate de tener permisos de administrador.")
      }

      const user = data.users.find((u) => u.email === email)

      if (!user) {
        throw new Error("Usuario no encontrado. Verifica que el correo electrónico sea correcto.")
      }

      setResult(`
        Usuario encontrado:
        - ID: ${user.id}
        - Email: ${user.email}
        - Email confirmado: ${user.email_confirmed_at ? "Sí" : "No"}
        
        Para confirmar manualmente este usuario:
        1. Ve al panel de Supabase (https://app.supabase.com)
        2. Selecciona tu proyecto
        3. Ve a "Authentication" > "Users"
        4. Busca el usuario con el correo: ${email}
        5. Haz clic en los tres puntos (...) y selecciona "Confirm email"
      `)

      toast({
        title: "Usuario encontrado",
        description: "Se han generado instrucciones para confirmar manualmente el usuario.",
      })
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      })
      setResult(error.message)
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="flex justify-center items-center min-h-[80vh]">
      <Card className="w-full max-w-md shadow-lg">
        <CardHeader className="space-y-1 bg-amber-50">
          <CardTitle className="text-2xl text-center text-amber-600">Herramienta de Desarrollo</CardTitle>
          <CardDescription className="text-center">
            Confirmar usuario manualmente (solo para desarrollo)
          </CardDescription>
        </CardHeader>
        <CardContent className="pt-6">
          <div className="space-y-4">
            <Alert className="bg-amber-50 border-amber-200">
              <Info className="h-4 w-4 text-amber-600" />
              <AlertTitle className="text-amber-600">Solo para desarrollo</AlertTitle>
              <AlertDescription className="text-amber-700">
                Esta herramienta es solo para entornos de desarrollo. Te ayudará a encontrar usuarios y generar
                instrucciones para confirmarlos manualmente en el panel de Supabase.
              </AlertDescription>
            </Alert>

            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="email">Correo Electrónico</Label>
                <Input
                  id="email"
                  type="email"
                  placeholder="correo@ejemplo.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                  className="border-gray-300 focus:border-amber-500 focus:ring-amber-500"
                />
              </div>
              <Button type="submit" className="w-full bg-amber-500 hover:bg-amber-600 text-white" disabled={isLoading}>
                {isLoading ? "Buscando..." : "Buscar Usuario"}
              </Button>
            </form>

            {result && (
              <div className="mt-4 p-4 bg-gray-50 rounded-md border border-gray-200">
                <h3 className="font-medium text-gray-900 mb-2">Resultado:</h3>
                <pre className="whitespace-pre-wrap text-sm text-gray-700">{result}</pre>
              </div>
            )}
          </div>
        </CardContent>
        <CardFooter className="flex flex-col space-y-4">
          <Button asChild variant="outline" className="w-full">
            <Link href="/login">Volver a Iniciar Sesión</Link>
          </Button>
        </CardFooter>
      </Card>
    </div>
  )
}
