import { NextResponse } from "next/server"
import type { WebhookPayload } from "@/types"

const N8N_WEBHOOK_URL = process.env.N8N_WEBHOOK_URL || "https://n8n.example.com/webhook/nuevo-pedido"

export async function POST(request: Request) {
  try {
    const data = await request.json()

    // Validar datos recibidos
    if (!data.user_id || !data.nombre_estudiante || !data.fecha_entrega || !data.tipo_pedido) {
      return NextResponse.json({ error: "Datos incompletos para el nuevo pedido" }, { status: 400 })
    }

    // Preparar payload para n8n
    const payload: WebhookPayload = {
      tipo: "nuevo_pedido",
      datos: {
        user_id: data.user_id,
        nombre_estudiante: data.nombre_estudiante,
        curso: data.curso,
        casino_entrega: data.casino_entrega,
        fecha_entrega: data.fecha_entrega,
        tipo_pedido: data.tipo_pedido,
        opcion_menu: data.opcion_menu,
        observacion: data.observacion,
        timestamp: new Date().toISOString(),
      },
    }

    // Enviar datos a n8n
    const response = await fetch(N8N_WEBHOOK_URL, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(payload),
    })

    if (!response.ok) {
      throw new Error(`Error al enviar datos a n8n: ${response.statusText}`)
    }

    const result = await response.json()

    return NextResponse.json({
      success: true,
      message: "Pedido registrado correctamente",
      data: result,
    })
  } catch (error) {
    console.error("Error en API de nuevo pedido:", error)
    return NextResponse.json({ error: "Error al procesar el nuevo pedido" }, { status: 500 })
  }
}
