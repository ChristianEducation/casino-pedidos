import { createClient } from "@supabase/supabase-js"
import type { Pedido, ClienteRecurrente } from "@/types"
import { getFechaLimiteModificacion } from "@/lib/date-utils"

// Obtener las variables de entorno
const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL || "https://koesipeybsasrknvgntg.supabase.co"
const supabaseAnonKey =
  process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY ||
  "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImtvZXNpcGV5YnNhc3JrbnZnbnRnIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDI5Mzg2MzEsImV4cCI6MjA1ODUxNDYzMX0.zLUMG6PRVJK1pEaAdO4pssFKGp8XMx9VAvwii4Xw1iU"

// Crear el cliente de Supabase
export const supabase = createClient(supabaseUrl, supabaseAnonKey)

/**
 * Obtiene la información de un cliente por su identificador
 */
export async function getClienteInfo(userId: string): Promise<ClienteRecurrente | null> {
  try {
    console.log(`Consultando información del cliente con userId: ${userId}`)

    let clienteData: any = null

    // Caso especial para Christian Wevar
    if (userId === "Christian Wevar") {
      console.log("Buscando específicamente a Christian Wevar por nombre_estudiante")

      // Buscar por nombre_estudiante
      const { data: dataByNombreEstudiante, error: errorByNombreEstudiante } = await supabase
        .from("clientes_recurrentes")
        .select("*")
        .eq("nombre_estudiante", "Christian Wevar")
        .single()

      if (!errorByNombreEstudiante && dataByNombreEstudiante) {
        clienteData = dataByNombreEstudiante
      } else {
        // Buscar por nombre_apoderado como fallback
        const { data: dataByNombreApoderado, error: errorByNombreApoderado } = await supabase
          .from("clientes_recurrentes")
          .select("*")
          .eq("nombre_apoderado", "Christian Wevar")
          .single()

        if (!errorByNombreApoderado && dataByNombreApoderado) {
          clienteData = dataByNombreApoderado
        } else {
          console.log("No se encontró a Christian Wevar en ninguna columna")
          return null
        }
      }
    } else {
      // Búsqueda en cascada para otros usuarios
      // 1. Buscar por user_id
      const { data: dataByUserId, error: errorByUserId } = await supabase
        .from("clientes_recurrentes")
        .select("*")
        .eq("user_id", userId)
        .single()

      if (!errorByUserId && dataByUserId) {
        clienteData = dataByUserId
      } else {
        // 2. Buscar por telegram_id
        const { data: dataByTelegram, error: errorByTelegram } = await supabase
          .from("clientes_recurrentes")
          .select("*")
          .eq("telegram_id", userId)
          .single()

        if (!errorByTelegram && dataByTelegram) {
          clienteData = dataByTelegram
        } else {
          // 3. Buscar por nombre_estudiante
          const { data: dataByNombreEstudiante, error: errorByNombreEstudiante } = await supabase
            .from("clientes_recurrentes")
            .select("*")
            .eq("nombre_estudiante", userId)
            .single()

          if (!errorByNombreEstudiante && dataByNombreEstudiante) {
            clienteData = dataByNombreEstudiante
          } else {
            // 4. Buscar por nombre_apoderado
            const { data: dataByNombreApoderado, error: errorByNombreApoderado } = await supabase
              .from("clientes_recurrentes")
              .select("*")
              .eq("nombre_apoderado", userId)
              .single()

            if (!errorByNombreApoderado && dataByNombreApoderado) {
              clienteData = dataByNombreApoderado
            } else {
              console.log(`No se encontró cliente con los identificadores proporcionados: ${userId}`)
              return null
            }
          }
        }
      }
    }

    // Procesar hijos_info si existe
    if (clienteData && clienteData.hijos_info) {
      if (typeof clienteData.hijos_info === "string") {
        try {
          clienteData.hijos_info = JSON.parse(clienteData.hijos_info)
        } catch (e) {
          console.error("Error al parsear hijos_info:", e)
          clienteData.hijos_info = []
        }
      } else if (!Array.isArray(clienteData.hijos_info)) {
        clienteData.hijos_info = []
      }
    }

    console.log(`Cliente encontrado:`, clienteData)
    return clienteData as ClienteRecurrente
  } catch (err) {
    console.error("Error al consultar información del cliente:", err)
    return null
  }
}

/**
 * Obtiene los pedidos de un usuario
 */
export async function getPedidosPorUsuario(userId: string): Promise<Pedido[]> {
  try {
    console.log(`Consultando pedidos para el usuario con ID: ${userId} en la tabla "pedido"`)

    // Obtener la fecha actual
    const today = new Date()
    today.setHours(0, 0, 0, 0)
    const fechaHoy = today.toISOString().split("T")[0]
    console.log("Fecha actual:", fechaHoy)

    let pedidosData: any[] = []

    // Caso especial para Christian Wevar
    if (userId === "Christian Wevar") {
      console.log("Buscando específicamente pedidos para Christian Wevar por nombre_estudiante")

      const { data, error } = await supabase
        .from("pedido")
        .select("*")
        .eq("nombre_estudiante", "Christian Wevar")
        .gte("fecha_entrega", fechaHoy)

      if (error) {
        console.error("Error al consultar pedidos para Christian Wevar:", error)
        return []
      }

      pedidosData = data || []
    } else {
      // Búsqueda en cascada para otros usuarios
      // 1. Buscar por user_id
      const { data: dataByUserId, error: errorByUserId } = await supabase
        .from("pedido")
        .select("*")
        .eq("user_id", userId)
        .gte("fecha_entrega", fechaHoy)

      if (!errorByUserId && dataByUserId && dataByUserId.length > 0) {
        pedidosData = dataByUserId
      } else {
        // 2. Buscar por id_usuario
        const { data: dataByIdUsuario, error: errorByIdUsuario } = await supabase
          .from("pedido")
          .select("*")
          .eq("id_usuario", userId)
          .gte("fecha_entrega", fechaHoy)

        if (!errorByIdUsuario && dataByIdUsuario && dataByIdUsuario.length > 0) {
          pedidosData = dataByIdUsuario
        } else {
          // 3. Buscar por tipo_usuario
          const { data: dataByTipoUsuario, error: errorByTipoUsuario } = await supabase
            .from("pedido")
            .select("*")
            .eq("tipo_usuario", userId)
            .gte("fecha_entrega", fechaHoy)

          if (!errorByTipoUsuario && dataByTipoUsuario && dataByTipoUsuario.length > 0) {
            pedidosData = dataByTipoUsuario
          } else {
            // 4. Buscar por nombre_estudiante
            const { data: dataByNombre, error: errorByNombre } = await supabase
              .from("pedido")
              .select("*")
              .eq("nombre_estudiante", userId)
              .gte("fecha_entrega", fechaHoy)

            if (errorByNombre) {
              console.error("Error al consultar por nombre_estudiante:", errorByNombre)
              return []
            }

            pedidosData = dataByNombre || []
          }
        }
      }
    }

    // Normalizar los datos para asegurar que dia_entrega tenga el valor de fecha_entrega
    const pedidosNormalizados = pedidosData.map((pedido) => ({
      ...pedido,
      dia_entrega: pedido.fecha_entrega || pedido.dia_entrega,
    }))

    console.log(`Pedidos encontrados para el usuario ${userId}: ${pedidosNormalizados.length}`)
    return pedidosNormalizados
  } catch (err) {
    console.error("Error al consultar pedidos por usuario:", err)
    return []
  }
}

/**
 * Verifica si un pedido puede ser modificado
 */
export function pedidoPuedeSerModificado(pedido: Pedido): boolean {
  // Usar fecha_entrega si está disponible, de lo contrario usar dia_entrega
  const fechaEntregaStr = pedido.fecha_entrega || pedido.dia_entrega

  // Verificar que la fecha de entrega sea posterior a la fecha actual
  const fechaEntrega = new Date(fechaEntregaStr)
  const hoy = new Date()
  hoy.setHours(0, 0, 0, 0)

  if (fechaEntrega <= hoy) {
    return false
  }

  // Verificar que no sea después de las 9:00 AM del día anterior
  const fechaLimite = getFechaLimiteModificacion(fechaEntregaStr)
  const ahora = new Date()

  return ahora < fechaLimite
}

/**
 * Actualiza un pedido en la base de datos
 */
export async function actualizarPedido(
  codigoPedido: string,
  nuevaFecha: string,
  nuevaOpcion: string,
): Promise<{ success: boolean; error?: string }> {
  try {
    if (!codigoPedido) {
      return { success: false, error: "Código de pedido no proporcionado" }
    }

    const updateData = {
      dia_entrega: nuevaFecha,
      fecha_entrega: nuevaFecha,
      opcion_menu: nuevaOpcion,
      observacion: `Opción de menú: ${nuevaOpcion}`,
    }

    const { error } = await supabase.from("pedido").update(updateData).eq("codigo", codigoPedido)

    if (error) {
      console.error("Error al actualizar pedido:", error)
      return { success: false, error: error.message }
    }

    return { success: true }
  } catch (err) {
    console.error("Error en actualizarPedido:", err)
    return {
      success: false,
      error: err instanceof Error ? err.message : "Error desconocido al actualizar el pedido",
    }
  }
}
