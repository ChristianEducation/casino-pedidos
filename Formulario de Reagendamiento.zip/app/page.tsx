import Link from "next/link"

export default function Home() {
  return (
    <div className="flex flex-col items-center justify-center min-h-screen p-4 bg-gray-50">
      <div className="w-full max-w-md p-6 bg-white rounded-lg shadow-md">
        <h1 className="mb-6 text-center text-2xl font-bold text-gray-800">
          Sistema de Reagendamiento de Pedidos Escolares
        </h1>
        <p className="mb-6 text-center text-gray-600">
          Para reagendar un pedido, utilice el enlace que recibió por correo electrónico o ingrese su ID de usuario a
          continuación.
        </p>
        <div className="flex flex-col items-center">
          <Link
            href="/reagendar?userId=Christian Wevar"
            className="w-full px-4 py-3 text-white bg-blue-600 rounded-md hover:bg-blue-700 text-center transition-colors"
          >
            Acceder como Christian Wevar
          </Link>
          <p className="mt-4 text-sm text-gray-500">
            Nota: Este sistema utiliza su ID de usuario único para identificar sus pedidos.
          </p>
        </div>
      </div>
    </div>
  )
}
