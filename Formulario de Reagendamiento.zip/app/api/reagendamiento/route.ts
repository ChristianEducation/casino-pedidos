import { NextResponse } from "next/server"
import type { WebhookPayload } from "@/types"

const N8N_WEBHOOK_URL = process.env.N8N_WEBHOOK_URL || "https://n8n.example.com/webhook/reagendamiento"

export async function POST(request: Request) {
  try {
    const data = await request.json()

    // Validar datos recibidos
    if (!data.pedido_id || !data.nueva_fecha || !data.nueva_opcion) {
      return NextResponse.json({ error: "Datos incompletos para el reagendamiento" }, { status: 400 })
    }

    // Preparar payload para n8n
    const payload: WebhookPayload = {
      tipo: "reagendamiento",
      datos: {
        pedido_id: data.pedido_id,
        codigo_pedido: data.codigo_pedido,
        user_id: data.user_id,
        fecha_anterior: data.fecha_anterior,
        nueva_fecha: data.nueva_fecha,
        opcion_anterior: data.opcion_anterior,
        nueva_opcion: data.nueva_opcion,
        timestamp: new Date().toISOString(),
      },
    }

    // Enviar datos a n8n
    const response = await fetch(N8N_WEBHOOK_URL, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(payload),
    })

    if (!response.ok) {
      throw new Error(`Error al enviar datos a n8n: ${response.statusText}`)
    }

    const result = await response.json()

    return NextResponse.json({
      success: true,
      message: "Reagendamiento procesado correctamente",
      data: result,
    })
  } catch (error) {
    console.error("Error en API de reagendamiento:", error)
    return NextResponse.json({ error: "Error al procesar el reagendamiento" }, { status: 500 })
  }
}
