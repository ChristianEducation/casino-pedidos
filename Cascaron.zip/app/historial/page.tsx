"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import Link from "next/link"
import { ArrowLeft } from "lucide-react"
import ProtectedRoute from "@/components/protected-route"

export default function HistoryPage() {
  return (
    <ProtectedRoute>
      <HistoryContent />
    </ProtectedRoute>
  )
}

function HistoryContent() {
  return (
    <div className="space-y-6">
      <div className="flex items-center gap-2">
        <Button variant="ghost" size="icon" asChild>
          <Link href="/dashboard">
            <ArrowLeft className="h-5 w-5" />
            <span className="sr-only">Volver</span>
          </Link>
        </Button>
        <h1 className="text-3xl font-bold tracking-tight text-gray-800">Historial de Pedidos</h1>
      </div>

      <Card className="border border-gray-200 shadow-sm">
        <CardHeader className="bg-[#F5F8EE]">
          <CardTitle className="text-xl text-[#9ACA3C]">Funcionalidad en Desarrollo</CardTitle>
          <CardDescription>
            Esta sección está actualmente en desarrollo y estará disponible próximamente.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <p className="text-gray-600">
            Aquí podrás ver el historial de tus pedidos anteriores, incluyendo fechas, estados y detalles. Vuelve pronto
            para acceder a esta funcionalidad.
          </p>
          <div className="mt-6">
            <Button asChild className="bg-[#9ACA3C] hover:bg-[#8BB52E]">
              <Link href="/dashboard">Volver al Dashboard</Link>
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
