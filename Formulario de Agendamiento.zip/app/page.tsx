import Link from "next/link"
import Image from "next/image"

export default function Home() {
  // Ejemplo de sessionId para demostración
  const demoSessionId = "619252331274270"

  return (
    <div className="min-h-screen flex items-center justify-center bg-[#F5F8EE] p-4">
      <div className="bg-white p-8 rounded-2xl shadow-md max-w-md w-full text-center">
        <div className="flex justify-center mb-6">
          <Image
            src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-hEUqx9zYXyfZPOWIn8lYLlCCGRVblj.png"
            alt="Delicias Food Service Logo"
            width={200}
            height={80}
            className="h-auto"
          />
        </div>
        <h1 className="text-2xl font-bold text-[#1e1e2d] mb-6">Bienvenido al Sistema de Pedidos</h1>
        <p className="text-gray-600 mb-8">Haz clic en el botón de abajo para acceder al formulario de pedidos.</p>
        <Link
          href={`/formulario?sessionId=${demoSessionId}`}
          className="inline-block bg-[#9ACA3C] text-white py-3 px-6 rounded-xl hover:bg-[#8BB52E] focus:outline-none focus:ring-2 focus:ring-[#9ACA3C] focus:ring-offset-2 transition-all duration-200"
        >
          Ir al Formulario
        </Link>
      </div>
    </div>
  )
}
