"use client"

import { useAuth } from "@/context/auth-context"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { AlertCircle, CheckCircle } from "lucide-react"

export default function AuthTest() {
  const { user, session, isLoading } = useAuth()
  const router = useRouter()

  if (isLoading) {
    return (
      <div className="flex justify-center items-center p-8">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-[#9ACA3C]"></div>
      </div>
    )
  }

  return (
    <Card className="w-full max-w-md mx-auto">
      <CardHeader>
        <CardTitle>Estado de Autenticación</CardTitle>
        <CardDescription>Información sobre el estado actual de la sesión</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {user ? (
          <Alert className="bg-green-50 border-green-200">
            <CheckCircle className="h-4 w-4 text-green-600" />
            <AlertTitle className="text-green-600">Autenticado</AlertTitle>
            <AlertDescription className="text-green-700">
              <p>Usuario: {user.email}</p>
              <p>ID: {user.id}</p>
            </AlertDescription>
          </Alert>
        ) : (
          <Alert variant="destructive">
            <AlertCircle className="h-4 w-4" />
            <AlertTitle>No autenticado</AlertTitle>
            <AlertDescription>No hay sesión activa</AlertDescription>
          </Alert>
        )}
      </CardContent>
      <CardFooter className="flex justify-between">
        {user ? (
          <Button variant="outline" onClick={() => router.push("/dashboard")}>
            Ir al Dashboard
          </Button>
        ) : (
          <Button onClick={() => router.push("/login")}>Iniciar Sesión</Button>
        )}
        <Button variant="ghost" onClick={() => router.refresh()}>
          Actualizar
        </Button>
      </CardFooter>
    </Card>
  )
}
