export type Json = string | number | boolean | null | { [key: string]: Json | undefined } | Json[]

export interface Database {
  public: {
    Tables: {
      clientes_recurrentes: {
        Row: {
          id: number
          telegram_id: string
          nombre_apoderado: string | null
          correo_electronico: string | null
          numero_telefono: string | null
          hijos_info: Json | null
          tipo_usuario: string | null
          ultima_interaccion: string | null
          conversation_state: string | null
          last_action: string | null
          session_context: string | null
          last_pedido_state: string | null
          fecha_ultimo_pedido: string | null
          created_at: string | null
          updated_at: string | null
        }
        Insert: {
          id?: number
          telegram_id: string
          nombre_apoderado?: string | null
          correo_electronico?: string | null
          numero_telefono?: string | null
          hijos_info?: Json | null
          tipo_usuario?: string | null
          ultima_interaccion?: string | null
          conversation_state?: string | null
          last_action?: string | null
          session_context?: string | null
          last_pedido_state?: string | null
          fecha_ultimo_pedido?: string | null
          created_at?: string | null
          updated_at?: string | null
        }
        Update: {
          id?: number
          telegram_id?: string
          nombre_apoderado?: string | null
          correo_electronico?: string | null
          numero_telefono?: string | null
          hijos_info?: Json | null
          tipo_usuario?: string | null
          ultima_interaccion?: string | null
          conversation_state?: string | null
          last_action?: string | null
          session_context?: string | null
          last_pedido_state?: string | null
          fecha_ultimo_pedido?: string | null
          created_at?: string | null
          updated_at?: string | null
        }
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      [_ in never]: never
    }
    Enums: {
      [_ in never]: never
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}
