"use client"

import type React from "react"
import { useState } from "react"
import { UserRound, Building2 } from "lucide-react"

interface SeleccionTipoUsuarioProps {
  seleccionarTipoUsuario: (tipo: "apoderado" | "funcionario") => void
}

export function SeleccionTipoUsuario({ seleccionarTipoUsuario }: SeleccionTipoUsuarioProps) {
  const [tipoSeleccionado, setTipoSeleccionado] = useState<"apoderado" | "funcionario" | null>(null)

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (tipoSeleccionado) {
      seleccionarTipoUsuario(tipoSeleccionado)
    }
  }

  return (
    <div className="transition-all duration-300">
      <h2 className="text-xl font-semibold text-gray-800 mb-6">¿Cómo deseas ingresar?</h2>

      <p className="text-gray-600 mb-6">Selecciona el tipo de usuario para continuar con tu pedido.</p>

      <form onSubmit={handleSubmit}>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
          {/* Opción Apoderado */}
          <div
            className={`border rounded-xl p-6 cursor-pointer transition-all duration-200 ${
              tipoSeleccionado === "apoderado"
                ? "border-[#9ACA3C] bg-[#F5F8EE]"
                : "border-gray-200 hover:border-[#9ACA3C] hover:bg-[#F5F8EE]/50"
            }`}
            onClick={() => setTipoSeleccionado("apoderado")}
          >
            <div className="flex flex-col items-center text-center">
              <div className="w-16 h-16 rounded-full bg-[#F5F8EE] flex items-center justify-center mb-4">
                <UserRound className="h-8 w-8 text-[#9ACA3C]" />
              </div>
              <h3 className="font-medium text-lg text-gray-800 mb-2">Apoderado</h3>
              <p className="text-sm text-gray-600">Soy apoderado y quiero realizar un pedido para mi(s) hijo(s).</p>
            </div>
          </div>

          {/* Opción Funcionario */}
          <div
            className={`border rounded-xl p-6 cursor-pointer transition-all duration-200 ${
              tipoSeleccionado === "funcionario"
                ? "border-[#9ACA3C] bg-[#F5F8EE]"
                : "border-gray-200 hover:border-[#9ACA3C] hover:bg-[#F5F8EE]/50"
            }`}
            onClick={() => setTipoSeleccionado("funcionario")}
          >
            <div className="flex flex-col items-center text-center">
              <div className="w-16 h-16 rounded-full bg-[#F5F8EE] flex items-center justify-center mb-4">
                <Building2 className="h-8 w-8 text-[#9ACA3C]" />
              </div>
              <h3 className="font-medium text-lg text-gray-800 mb-2">Funcionario</h3>
              <p className="text-sm text-gray-600">Soy funcionario del establecimiento y quiero realizar un pedido.</p>
            </div>
          </div>
        </div>

        <button
          type="submit"
          disabled={!tipoSeleccionado}
          className="w-full bg-[#9ACA3C] text-white py-3 px-6 rounded-xl hover:bg-[#8BB52E] focus:outline-none focus:ring-2 focus:ring-[#9ACA3C] focus:ring-offset-2 transition-all duration-200 disabled:opacity-50"
        >
          Continuar
        </button>
      </form>
    </div>
  )
}
