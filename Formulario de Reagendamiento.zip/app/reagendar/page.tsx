"use client"

import { useSearchParams } from "next/navigation"
import { useEffect, useState } from "react"
import { Loader2 } from "lucide-react"
import type { Pedido } from "@/types"
import { getPedidosPorUsuario, pedidoPuedeSerModificado } from "@/utils/supabase"
import PedidosList from "./components/pedidos-list"

export default function ReagendarPage() {
  const searchParams = useSearchParams()
  const userId = searchParams.get("userId") || searchParams.get("sessionId") || searchParams.get("user_id")

  const [pedidos, setPedidos] = useState<Pedido[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    async function fetchPedidos() {
      if (!userId) {
        setError("No se proporcionó un ID de usuario válido")
        setLoading(false)
        return
      }

      try {
        console.log("Obteniendo pedidos para el usuario:", userId)

        // Obtener pedidos del usuario
        const pedidosUsuario = await getPedidosPorUsuario(userId)
        console.log("Pedidos obtenidos:", pedidosUsuario)

        // Filtrar solo los pedidos que pueden ser modificados
        const pedidosModificables = pedidosUsuario.filter(pedidoPuedeSerModificado)
        console.log("Pedidos modificables:", pedidosModificables)

        setPedidos(pedidosModificables)
      } catch (err) {
        console.error("Error al cargar pedidos:", err)
        setError("Error al cargar los pedidos. Por favor, intente nuevamente.")
      } finally {
        setLoading(false)
      }
    }

    fetchPedidos()
  }, [userId])

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center min-h-screen p-4 bg-gray-50">
        <div className="w-full max-w-md p-6 bg-white rounded-lg shadow-md text-center">
          <Loader2 className="w-8 h-8 animate-spin text-blue-600 mx-auto mb-4" />
          <p className="text-gray-600">Cargando pedidos...</p>
        </div>
      </div>
    )
  }

  if (error) {
    return (
      <div className="flex flex-col items-center justify-center min-h-screen p-4 bg-gray-50">
        <div className="w-full max-w-md p-6 bg-white rounded-lg shadow-md">
          <h1 className="mb-4 text-center text-2xl font-bold text-red-600">Error</h1>
          <p className="text-center text-gray-700">{error}</p>
        </div>
      </div>
    )
  }

  if (pedidos.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center min-h-screen p-4 bg-gray-50">
        <div className="w-full max-w-md p-6 bg-white rounded-lg shadow-md">
          <h1 className="mb-4 text-center text-2xl font-bold text-gray-800">No hay pedidos disponibles</h1>
          <p className="text-center text-gray-600">
            No se encontraron pedidos válidos para reagendar con el ID de usuario proporcionado o los pedidos ya no
            pueden ser modificados.
          </p>
          <div className="mt-6 text-center">
            <a href="/" className="text-blue-600 hover:underline">
              Volver al inicio
            </a>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="flex flex-col items-center justify-center min-h-screen p-4 bg-gray-50">
      <div className="w-full max-w-2xl p-6 bg-white rounded-lg shadow-md">
        <h1 className="mb-6 text-center text-2xl font-bold text-gray-800">Reagendamiento de Pedidos</h1>
        <PedidosList pedidos={pedidos} userId={userId || ""} />
      </div>
    </div>
  )
}
