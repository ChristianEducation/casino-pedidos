import { createMiddlewareClient } from "@supabase/auth-helpers-nextjs"
import { NextResponse } from "next/server"
import type { NextRequest } from "next/server"

export async function middleware(req: NextRequest) {
  const res = NextResponse.next()
  const supabase = createMiddlewareClient({ req, res })

  try {
    // Obtener la sesión actual
    const {
      data: { session },
    } = await supabase.auth.getSession()

    const { pathname, searchParams } = req.nextUrl
    const isAuthRoute = pathname.startsWith("/login") || pathname.startsWith("/registro")
    const isProtected = ["/dashboard", "/perfil", "/historial", "/formulario"].some(
      (base) => pathname === base || pathname.startsWith(base + "/"),
    )

    console.log("Middleware: Ruta:", pathname, "Protegida:", isProtected, "Auth:", isAuthRoute, "Sesión:", !!session)

    // Si no hay sesión y la ruta está protegida, redirigir a login
    if (!session && isProtected) {
      console.log("Middleware: Redirigiendo a login desde ruta protegida")
      const redirectUrl = req.nextUrl.clone()
      redirectUrl.pathname = "/login"
      redirectUrl.searchParams.set("redirect", pathname)
      return NextResponse.redirect(redirectUrl)
    }

    // Si hay sesión y estamos en una ruta de autenticación, redirigir al dashboard o a la ruta especificada
    if (session && isAuthRoute) {
      console.log("Middleware: Redirigiendo desde ruta de auth con sesión activa")
      const target = searchParams.get("redirect") || "/dashboard"
      const redirectUrl = req.nextUrl.clone()
      redirectUrl.pathname = target
      redirectUrl.search = "" // Limpiar parámetros de búsqueda
      return NextResponse.redirect(redirectUrl)
    }

    return res
  } catch (error) {
    console.error("Error en middleware:", error)
    return res
  }
}

export const config = {
  matcher: ["/login", "/registro", "/dashboard/:path*", "/perfil/:path*", "/historial/:path*", "/formulario/:path*"],
}
