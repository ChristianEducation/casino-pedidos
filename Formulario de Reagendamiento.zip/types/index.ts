// Tipos centralizados para la aplicación

export type Pedido = {
  id?: number
  codigo?: string
  tipo_usuario?: string
  id_usuario?: string
  user_id?: string
  nombre_estudiante: string
  curso?: string
  casino_entrega?: string
  nivel?: string
  fecha_creacion?: string
  tipo_pedido: string
  semana_mes?: string
  dia_entrega: string
  fecha_entrega?: string
  precio_unitario?: number
  observacion?: string
  nombre_apoderado?: string
  telefono_apoderado?: string
  correo_electronico?: string
  estado_pago?: string
  created_at?: string
  opcion_menu?: string
}

export type OpcionMenu = {
  id?: number
  fecha: string
  dia?: string
  codigo: string
  descripcion: string
  precio_estudiante?: number
  precio_funcionario?: number
  tipo_dia?: string
  created_at?: string
}

export type ClienteRecurrente = {
  id?: number
  ultima_interaccion?: string
  telegram_id?: string
  nombre_apoderado?: string
  nombre_estudiante?: string
  correo_electronico?: string
  hijos_info?: {
    nombre: string
    curso: string
  }[]
  tipo_usuario?: string
  conversation_state?: string
  last_action?: string
  session_context?: string
  last_pedido_state?: string
  fecha_ultimo_pedido?: string
  numero_telefono?: string
}

export type SemanaDisponible = {
  id: string
  fechaInicio: string
  fechaFin: string
  label: string
  dias: DiaDisponible[]
}

export type DiaDisponible = {
  fecha: string
  label: string
  disponible: boolean
}

export type Perfil = {
  id?: string
  user_id: string
  nombre_completo: string
  correo_electronico: string
  telefono: string
  tipo_usuario: string
  hijos_info?: {
    nombre: string
    curso: string
  }[]
  created_at?: string
  updated_at?: string
}

export type WebhookPayload = {
  tipo: "registro_perfil" | "nuevo_pedido" | "reagendamiento"
  datos: any
}
