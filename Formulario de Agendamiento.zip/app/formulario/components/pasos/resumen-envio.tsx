"use client"

import type { FormData, OpcionMenu, DatosHijo } from "../formulario-multi-step"

interface MenusPorDia {
  lunes: OpcionMenu[]
  martes: OpcionMenu[]
  miercoles: OpcionMenu[]
  jueves: OpcionMenu[]
  viernes: OpcionMenu[]
}

interface ResumenEnvioProps {
  formData: FormData
  anteriorPaso: () => void
  enviarFormulario: () => void
  loading: boolean
  error: string | null
  success: boolean
  debugInfo?: string | null
  opcionesMenu: OpcionMenu[]
  opcionesColaciones: OpcionMenu[]
  menusPorDia: MenusPorDia
}

export function ResumenEnvio({
  formData,
  anteriorPaso,
  enviarFormulario,
  loading,
  error,
  success,
  debugInfo,
  opcionesMenu,
  opcionesColaciones,
  menusPorDia,
}: ResumenEnvioProps) {
  // Función para formatear la fecha en formato legible
  const formatearFecha = (fecha: string): string => {
    const opciones: Intl.DateTimeFormatOptions = { day: "numeric", month: "long" }
    return new Date(fecha).toLocaleDateString("es-ES", opciones)
  }

  // Función para formatear precio en pesos chilenos
  const formatearPrecio = (precio: number): string => {
    return new Intl.NumberFormat("es-CL", {
      style: "currency",
      currency: "CLP",
      minimumFractionDigits: 0,
    }).format(precio)
  }

  // Función para obtener el precio de una opción de menú según el día
  const obtenerPrecioMenu = (dia: string, nombre: string, esFuncionario = false): number => {
    try {
      // Verificar que menusPorDia y el día específico existan
      if (!menusPorDia || !menusPorDia[dia as keyof MenusPorDia]) {
        console.warn(`No se encontraron opciones de menú para el día "${dia}"`)
        return 0
      }

      const diaKey = dia as keyof typeof menusPorDia
      const opcion = menusPorDia[diaKey]?.find((op) => op.nombre === nombre)

      if (!opcion) {
        console.warn(`No se encontró la opción de menú "${nombre}" para el día "${dia}"`)
        return 0
      }

      // Si es funcionario, aplicar precio especial
      if (esFuncionario && opcion.precioFuncionario !== undefined) {
        console.log(`Usando precio de funcionario para ${nombre}: ${opcion.precioFuncionario}`)
        return opcion.precioFuncionario
      }

      console.log(`Usando precio regular para ${nombre}: ${opcion.precio}`)
      return opcion.precio || 0
    } catch (error) {
      console.error("Error al obtener precio del menú:", error)
      return 0
    }
  }

  // Función para obtener el precio de una opción de colación
  const obtenerPrecioColacion = (nombre: string): number => {
    try {
      if (!opcionesColaciones || opcionesColaciones.length === 0) {
        return 0
      }

      const opcion = opcionesColaciones.find((op) => op.nombre === nombre)
      if (opcion) {
        console.log(`Precio de colación ${nombre}: ${opcion.precio}`)
        return opcion.precio || 0
      }
      return 0
    } catch (error) {
      console.error("Error al obtener precio de colación:", error)
      return 0
    }
  }

  // Función para calcular el total de un hijo
  const calcularTotalHijo = (hijo: DatosHijo, esFuncionario = false): number => {
    try {
      if (!hijo) {
        console.warn("Hijo no definido en calcularTotalHijo")
        return 0
      }

      let total = 0
      let totalAlmuerzos = 0
      let totalColaciones = 0

      // Sumar almuerzos
      if (hijo.menu) {
        Object.entries(hijo.menu).forEach(([dia, opcion]) => {
          if (opcion) {
            const precio = obtenerPrecioMenu(dia, opcion, esFuncionario)
            console.log(`Precio almuerzo para ${hijo.nombre} - ${dia} (${opcion}): ${precio}`)
            totalAlmuerzos += precio
          }
        })
      }

      // Sumar colaciones
      if (hijo.colaciones) {
        Object.entries(hijo.colaciones).forEach(([dia, opcion]) => {
          if (opcion) {
            const precio = obtenerPrecioColacion(opcion)
            console.log(`Precio colación para ${hijo.nombre} - ${dia} (${opcion}): ${precio}`)
            totalColaciones += precio
          }
        })
      }

      total = totalAlmuerzos + totalColaciones
      console.log(
        `Total calculado para ${hijo.nombre}: ${total} (Almuerzos: ${totalAlmuerzos}, Colaciones: ${totalColaciones})`,
      )
      return total
    } catch (error) {
      console.error("Error al calcular total del hijo:", error)
      return 0
    }
  }

  // Verificar si hay hijos para mostrar
  const tieneHijos = formData.hijos && formData.hijos.length > 0

  // Calcular los subtotales para cada hijo
  const subtotales = formData.hijos.map((hijo, index) => {
    const esFuncionario = formData.tipoUsuario === "funcionario" && index === 0 && hijo.curso === "Funcionario"
    const subtotal = calcularTotalHijo(hijo, esFuncionario)
    console.log(`Subtotal calculado para ${hijo.nombre} (index ${index}): ${subtotal}`)
    return {
      hijo: hijo.nombre,
      subtotal: subtotal,
      esFuncionario: esFuncionario,
    }
  })

  // Calcular el total general sumando todos los subtotales
  const totalGeneral = subtotales.reduce((total, item) => total + item.subtotal, 0)

  // Función para obtener la descripción de una opción de menú según el día
  const obtenerDescripcionMenu = (dia: string, nombre: string): string => {
    try {
      if (!menusPorDia || !menusPorDia[dia as keyof MenusPorDia]) {
        return ""
      }

      const diaKey = dia as keyof typeof menusPorDia
      const opcion = menusPorDia[diaKey]?.find((op) => op.nombre === nombre)
      return opcion ? opcion.descripcion || "" : ""
    } catch (error) {
      console.error("Error al obtener descripción del menú:", error)
      return ""
    }
  }

  // Función para obtener la descripción de una opción de colación
  const obtenerDescripcionColacion = (nombre: string): string => {
    try {
      if (!opcionesColaciones || opcionesColaciones.length === 0) {
        return ""
      }

      const opcion = opcionesColaciones.find((op) => op.nombre === nombre)
      return opcion ? opcion.descripcion || "" : ""
    } catch (error) {
      console.error("Error al obtener descripción de colación:", error)
      return ""
    }
  }

  // Depurar información sobre los subtotales
  console.log("Subtotales calculados:", subtotales)
  console.log("Total general:", totalGeneral)

  // Obtener información del lugar de retiro para funcionarios
  const obtenerInfoLugarRetiro = () => {
    if (formData.tipoUsuario !== "funcionario" || !formData.lugarRetiro) {
      return null
    }

    let infoAdicional = ""
    if (formData.lugarRetiro === "Sala" && formData.cursoSala && formData.letraSala) {
      infoAdicional = ` (${formData.cursoSala} ${formData.letraSala})`
    }

    return `${formData.lugarRetiro}${infoAdicional}`
  }

  return (
    <div className="transition-all duration-300">
      <h2 className="section-title">Resumen y Envío</h2>

      {success ? (
        <div className="bg-green-50 border border-green-200 rounded-xl p-6 mb-6">
          <h3 className="text-lg font-medium text-green-800 mb-2">¡Pedido enviado con éxito!</h3>
          <p className="text-green-700">Tu pedido ha sido registrado correctamente. Gracias por tu preferencia.</p>
        </div>
      ) : (
        <>
          {/* Datos del Apoderado/Funcionario */}
          <div className="bg-[#F5F8EE] rounded-xl p-6 mb-6">
            <h3 className="text-lg font-medium text-[#1e1e2d] mb-4">
              {formData.tipoUsuario === "funcionario" ? "Datos del Funcionario" : "Datos del Apoderado"}
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <p className="text-sm text-gray-500">Nombre:</p>
                <p className="text-base font-medium">{formData.nombreApoderado}</p>
              </div>
              <div>
                <p className="text-sm text-gray-500">Correo:</p>
                <p className="text-base font-medium">{formData.correoApoderado}</p>
              </div>
              <div>
                <p className="text-sm text-gray-500">Teléfono:</p>
                <p className="text-base font-medium">{formData.telefono}</p>
              </div>
              <div>
                <p className="text-sm text-gray-500">Tipo de usuario:</p>
                <p className="text-base font-medium capitalize">{formData.tipoUsuario}</p>
              </div>
              {formData.tipoUsuario === "funcionario" && formData.lugarRetiro && (
                <div>
                  <p className="text-sm text-gray-500">Lugar de retiro:</p>
                  <p className="text-base font-medium">{obtenerInfoLugarRetiro()}</p>
                </div>
              )}
            </div>
          </div>

          {/* Información de la semana */}
          {formData.semanaSeleccionada && (
            <div className="bg-[#F5F8EE] rounded-xl p-6 mb-6">
              <h3 className="text-lg font-medium text-[#1e1e2d] mb-4">Información del Pedido</h3>
              <p className="text-base">
                <span className="font-medium">Semana:</span> {formData.semanaSeleccionada.nombre}
              </p>
              <p className="text-base">
                <span className="font-medium">Período:</span> Del{" "}
                {formatearFecha(formData.semanaSeleccionada.fechaInicio)} al{" "}
                {formatearFecha(formData.semanaSeleccionada.fechaFin)}
              </p>
            </div>
          )}

          {/* Mensaje si no hay hijos */}
          {!tieneHijos && (
            <div className="bg-yellow-50 rounded-xl p-6 mb-6">
              <h3 className="text-lg font-medium text-yellow-800 mb-2">No hay pedidos registrados</h3>
              <p className="text-yellow-700">
                {formData.tipoUsuario === "funcionario"
                  ? "No has agregado ningún hijo para pedidos. Puedes continuar sin agregar hijos o volver atrás para agregarlos."
                  : "No has agregado ningún alumno. Por favor, vuelve atrás para agregar al menos un alumno."}
              </p>
            </div>
          )}

          {/* Resumen por cada hijo/alumno */}
          {tieneHijos &&
            formData.hijos.map((hijo, index) => {
              // Determinar si este hijo es el funcionario mismo
              const esFuncionario = formData.tipoUsuario === "funcionario" && index === 0

              // Obtener el subtotal para este hijo
              const subtotalInfo = subtotales[index] || { subtotal: 0 }
              const subtotal = subtotalInfo.subtotal

              // Verificar si hay almuerzos seleccionados
              const tieneAlmuerzos = hijo.menu && Object.values(hijo.menu).some((opcion) => opcion !== null)

              // Verificar si hay colaciones seleccionadas
              const tieneColaciones =
                hijo.colaciones && Object.values(hijo.colaciones).some((opcion) => opcion !== null)

              return (
                <div key={hijo.id} className="bg-[#F5F8EE] rounded-xl p-6 mb-6">
                  <h3 className="text-lg font-medium text-[#1e1e2d] mb-4">
                    {esFuncionario ? "Tu pedido" : `Pedido para: ${hijo.nombre}`}
                  </h3>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                    <div>
                      <p className="text-sm text-gray-500">Nombre:</p>
                      <p className="text-base font-medium">{hijo.nombre}</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-500">Curso:</p>
                      <p className="text-base font-medium">
                        {hijo.curso} {hijo.letra}
                      </p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-500">Nivel:</p>
                      <p className="text-base font-medium">{hijo.nivel}</p>
                    </div>
                    {esFuncionario && (
                      <div>
                        <p className="text-sm text-gray-500">Tipo:</p>
                        <p className="text-base font-medium text-[#9ACA3C]">Funcionario (precio especial)</p>
                      </div>
                    )}
                  </div>

                  {/* Menú Seleccionado (Almuerzos) */}
                  <div className="border-t border-gray-200 pt-4 mb-4">
                    <h4 className="font-medium text-[#1e1e2d] mb-3">Almuerzos Seleccionados</h4>
                    <div className="space-y-3">
                      {tieneAlmuerzos ? (
                        Object.entries(hijo.menu)
                          .filter(([_, opcion]) => opcion !== null) // Filtrar solo los días con selección
                          .map(([dia, opcion]) => {
                            // Convertir el nombre del día a formato legible
                            const nombreDia =
                              dia === "lunes"
                                ? "Lunes"
                                : dia === "martes"
                                  ? "Martes"
                                  : dia === "miercoles"
                                    ? "Miércoles"
                                    : dia === "jueves"
                                      ? "Jueves"
                                      : "Viernes"

                            // Obtener la descripción y precio de la opción
                            const descripcion = opcion ? obtenerDescripcionMenu(dia, opcion) : ""
                            const precio = opcion ? obtenerPrecioMenu(dia, opcion, esFuncionario) : 0

                            return (
                              <div key={dia} className="border-b border-gray-200 pb-2">
                                <div className="flex justify-between">
                                  <span className="text-gray-600 font-medium">{nombreDia}:</span>
                                  <div className="text-right">
                                    <span className="font-medium">
                                      {opcion ? opcion.replace(/^(A\d+):\s*/, "") : ""}
                                    </span>
                                    <span className="block text-sm text-gray-500">{formatearPrecio(precio)}</span>
                                  </div>
                                </div>
                                {descripcion && <p className="text-sm text-gray-500 mt-1">{descripcion}</p>}
                              </div>
                            )
                          })
                      ) : (
                        <p className="text-gray-500 italic">No se ha seleccionado ningún almuerzo</p>
                      )}
                    </div>
                  </div>

                  {/* Colaciones Seleccionadas */}
                  <div className="border-t border-gray-200 pt-4 mb-4">
                    <h4 className="font-medium text-[#1e1e2d] mb-3">Colaciones Seleccionadas</h4>
                    <div className="space-y-3">
                      {tieneColaciones ? (
                        Object.entries(hijo.colaciones)
                          .filter(([_, opcion]) => opcion !== null) // Filtrar solo los días con selección
                          .map(([dia, opcion]) => {
                            // Convertir el nombre del día a formato legible
                            const nombreDia =
                              dia === "lunes"
                                ? "Lunes"
                                : dia === "martes"
                                  ? "Martes"
                                  : dia === "miercoles"
                                    ? "Miércoles"
                                    : dia === "jueves"
                                      ? "Jueves"
                                      : "Viernes"

                            // Obtener la descripción y precio de la opción
                            const descripcion = opcion ? obtenerDescripcionColacion(opcion) : ""
                            const precio = opcion ? obtenerPrecioColacion(opcion) : 0

                            return (
                              <div key={dia} className="border-b border-gray-200 pb-2">
                                <div className="flex justify-between">
                                  <span className="text-gray-600 font-medium">{nombreDia}:</span>
                                  <div className="text-right">
                                    <span className="font-medium">{descripcion}</span>
                                    <span className="block text-sm text-gray-500">{formatearPrecio(precio)}</span>
                                  </div>
                                </div>
                              </div>
                            )
                          })
                      ) : (
                        <p className="text-gray-500 italic">No se ha seleccionado ninguna colación</p>
                      )}
                    </div>
                  </div>

                  {/* Subtotal por hijo */}
                  <div className="bg-white p-4 rounded-xl">
                    <div className="flex justify-between">
                      <span className="font-medium">Subtotal:</span>
                      <span className="font-medium">{formatearPrecio(subtotal)}</span>
                    </div>
                  </div>
                </div>
              )
            })}

          {/* Total general */}
          <div className="bg-[#9ACA3C]/10 rounded-xl p-6 mb-6">
            <div className="flex justify-between items-center">
              <h3 className="text-lg font-medium text-[#1e1e2d]">Total a pagar:</h3>
              <span className="text-xl font-bold text-[#9ACA3C]">{formatearPrecio(totalGeneral)}</span>
            </div>
          </div>

          {/* Observaciones */}
          {(formData.observacionesAlmuerzos || formData.observacionesColaciones) && (
            <div className="bg-[#F5F8EE] rounded-xl p-6 mb-6">
              <h3 className="text-lg font-medium text-[#1e1e2d] mb-4">Observaciones</h3>

              {formData.observacionesAlmuerzos && (
                <div className="mb-4">
                  <p className="text-sm text-gray-500 mb-1">Sobre almuerzos:</p>
                  <p className="text-base bg-white p-3 rounded-lg border border-gray-200">
                    {formData.observacionesAlmuerzos}
                  </p>
                </div>
              )}

              {formData.observacionesColaciones && (
                <div>
                  <p className="text-sm text-gray-500 mb-1">Sobre colaciones:</p>
                  <p className="text-base bg-white p-3 rounded-lg border border-gray-200">
                    {formData.observacionesColaciones}
                  </p>
                </div>
              )}
            </div>
          )}

          {/* Método de Pago */}
          <div className="bg-[#F5F8EE] rounded-xl p-6 mb-6">
            <h3 className="text-lg font-medium text-[#1e1e2d] mb-4">Método de Pago</h3>
            <p className="text-base">{formData.metodoPago === "Pendiente" ? "Pagaré después" : "Pagar ahora"}</p>
            {formData.metodoPago === "espera_pago" && (
              <p className="mt-2 text-sm text-[#9ACA3C]">
                Al confirmar el pedido, serás redirigido a una página para subir tu comprobante de pago.
              </p>
            )}
          </div>

          {error && (
            <div className="bg-red-50 border border-red-200 rounded-xl p-6 mb-6">
              <h3 className="text-lg font-medium text-red-800 mb-2">Error al enviar el formulario</h3>
              <p className="text-red-600">{error}</p>
              <p className="mt-2 text-sm text-red-500">
                Si el problema persiste, verifica que la URL del webhook sea correcta y que el servidor esté
                funcionando.
              </p>
            </div>
          )}

          {debugInfo && (
            <div className="bg-[#F5F8EE] border border-[#9ACA3C]/30 rounded-xl p-6 mb-6 overflow-auto">
              <h3 className="text-lg font-medium text-[#1e1e2d] mb-2">Información de Depuración</h3>
              <pre className="text-xs text-gray-700 whitespace-pre-wrap">{debugInfo}</pre>
            </div>
          )}

          <div className="pt-4 flex space-x-4">
            <button type="button" onClick={anteriorPaso} disabled={loading} className="w-1/2 btn-secondary">
              Anterior
            </button>
            <button type="button" onClick={enviarFormulario} disabled={loading} className="w-1/2 btn-primary">
              {loading ? "Enviando..." : "Confirmar Pedido"}
            </button>
          </div>
        </>
      )}
    </div>
  )
}
