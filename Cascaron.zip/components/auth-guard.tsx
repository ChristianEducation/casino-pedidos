"use client"

import type React from "react"

import { useEffect } from "react"
import { useRouter } from "next/navigation"
import { useAuth } from "@/context/auth-context"

interface AuthGuardProps {
  children: React.ReactNode
  requireAuth?: boolean
  requireProfile?: boolean
  redirectTo?: string
}

export default function AuthGuard({
  children,
  requireAuth = true,
  requireProfile = false,
  redirectTo = "/login",
}: AuthGuardProps) {
  const { user, isLoading, hasProfile, isProfileComplete } = useAuth()
  const router = useRouter()

  useEffect(() => {
    // No hacer nada mientras se está cargando
    if (isLoading) return

    // Si requiere autenticación y no hay usuario, redirigir a login
    if (requireAuth && !user) {
      console.log("AuthGuard: Redirigiendo a", redirectTo, "(requiere autenticación)")
      router.push(redirectTo)
      return
    }

    // Si requiere perfil completo y no lo tiene, redirigir a perfil
    if (requireAuth && requireProfile && user) {
      if (!hasProfile || !isProfileComplete) {
        console.log("AuthGuard: Redirigiendo a /perfil (perfil incompleto)")
        router.push("/perfil")
        return
      }
    }
  }, [user, isLoading, hasProfile, isProfileComplete, requireAuth, requireProfile, redirectTo, router])

  // Mostrar nada mientras se está cargando o redirigiendo
  if (isLoading) {
    return <div className="flex justify-center items-center min-h-[60vh]">Cargando...</div>
  }

  // Si requiere autenticación y no hay usuario, no mostrar nada (se redirigirá)
  if (requireAuth && !user) {
    return <div className="flex justify-center items-center min-h-[60vh]">Redirigiendo...</div>
  }

  // Si requiere perfil completo y no lo tiene, no mostrar nada (se redirigirá)
  if (requireAuth && requireProfile && user && (!hasProfile || !isProfileComplete)) {
    return <div className="flex justify-center items-center min-h-[60vh]">Redirigiendo a completar perfil...</div>
  }

  // En cualquier otro caso, mostrar los hijos
  return <>{children}</>
}
