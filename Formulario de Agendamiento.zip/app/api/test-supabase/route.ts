import { NextResponse } from "next/server"
import { supabase } from "@/lib/supabase"

export async function GET(request: Request) {
  try {
    // Obtener el sessionId de los parámetros de consulta
    const { searchParams } = new URL(request.url)
    const sessionId = searchParams.get("sessionId")

    if (!sessionId) {
      return NextResponse.json({ error: "Se requiere sessionId" }, { status: 400 })
    }

    // Listar tablas disponibles
    const { data: tablesData, error: tablesError } = await supabase
      .from("pg_catalog.pg_tables")
      .select("tablename")
      .eq("schemaname", "public")

    if (tablesError) {
      return NextResponse.json({ error: `Error al listar tablas: ${tablesError.message}` }, { status: 500 })
    }

    // Intentar con diferentes posibles nombres de tabla
    const tableNames = ["clientes_recurrentes", "clientes_recuerrentes", "clientesrecurrentes", "clientes"]
    let clientData = null
    let tableFound = null

    for (const tableName of tableNames) {
      try {
        const { data, error } = await supabase.from(tableName).select("*").eq("telegram_id", sessionId).maybeSingle()

        if (!error || (error && !error.message.includes("does not exist"))) {
          clientData = data
          tableFound = tableName
          break
        }
      } catch (e) {
        // Continuar con la siguiente tabla
      }
    }

    return NextResponse.json({
      success: true,
      availableTables: tablesData,
      tableFound,
      clientData,
      sessionId,
    })
  } catch (error) {
    console.error("Error en la API:", error)
    return NextResponse.json({ error: "Error interno del servidor" }, { status: 500 })
  }
}
