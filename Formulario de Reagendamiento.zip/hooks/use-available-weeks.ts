"use client"

import { useState, useEffect } from "react"
import { getAvailableWeeks } from "@/lib/menu-utils"
import type { SemanaDisponible } from "@/types"

export function useAvailableWeeks(userId: string) {
  const [weeks, setWeeks] = useState<SemanaDisponible[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    async function fetchWeeks() {
      if (!userId) {
        setError("ID de usuario no proporcionado")
        setLoading(false)
        return
      }

      try {
        setLoading(true)
        setError(null)

        const availableWeeks = await getAvailableWeeks(userId)
        setWeeks(availableWeeks)
      } catch (err) {
        console.error("Error al cargar semanas disponibles:", err)
        setError("Error al cargar las semanas disponibles. Por favor, intente nuevamente.")
      } finally {
        setLoading(false)
      }
    }

    fetchWeeks()
  }, [userId])

  return { weeks, loading, error }
}
