"use client"

import type React from "react"
import { Inter } from "next/font/google"
import "./globals.css"
import Navbar from "@/components/navbar"
import { Toaster } from "@/components/ui/toaster"
import ConfigCheck from "@/components/config-check"
import DebugTools from "@/components/debug-tools"
import { createClientComponentClient } from "@supabase/auth-helpers-nextjs"
import { SessionContextProvider } from "@supabase/auth-helpers-react"
import type { Database } from "@/types/supabase"
import { useRef } from "react"

const inter = Inter({ subsets: ["latin"] })

export default function ClientLayout({
  children,
}: {
  children: React.ReactNode
}) {
  // Crear una referencia estable al cliente de Supabase
  const supabaseRef = useRef(createClientComponentClient<Database>())

  return (
    <html lang="es">
      <body className={inter.className}>
        <ConfigCheck>
          <SessionContextProvider supabaseClient={supabaseRef.current}>
            <div className="min-h-screen bg-gray-50">
              <Navbar />
              <main className="container mx-auto px-4 py-8">{children}</main>
              <Toaster />
              {/* Herramienta de depuración unificada y discreta */}
              <DebugTools />
            </div>
          </SessionContextProvider>
        </ConfigCheck>
      </body>
    </html>
  )
}
