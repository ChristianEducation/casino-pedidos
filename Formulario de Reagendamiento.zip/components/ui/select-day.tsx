"use client"

import { Calendar } from "lucide-react"
import type { SemanaDisponible } from "@/types"

interface SelectDayProps {
  selectedWeek: SemanaDisponible | null
  selectedDate: string | null
  onSelectDate: (date: string) => void
}

export function SelectDay({ selectedWeek, selectedDate, onSelectDate }: SelectDayProps) {
  if (!selectedWeek) {
    return <div className="p-3 border rounded-md bg-gray-50 text-gray-500">Seleccione una semana primero</div>
  }

  const availableDays = selectedWeek.dias.filter((day) => day.disponible)

  if (availableDays.length === 0) {
    return (
      <div className="p-3 border rounded-md bg-yellow-50 text-yellow-700">
        No hay días disponibles en la semana seleccionada
      </div>
    )
  }

  return (
    <div className="grid grid-cols-1 sm:grid-cols-3 md:grid-cols-5 gap-2">
      {selectedWeek.dias.map((day) => (
        <button
          key={day.fecha}
          type="button"
          onClick={() => day.disponible && onSelectDate(day.fecha)}
          disabled={!day.disponible}
          className={`p-3 border rounded-md text-left transition-colors ${
            !day.disponible
              ? "bg-gray-100 text-gray-400 cursor-not-allowed"
              : selectedDate === day.fecha
                ? "bg-blue-50 border-blue-300 ring-2 ring-blue-200"
                : "bg-white hover:bg-gray-50"
          }`}
        >
          <div className="flex flex-col">
            <div className="flex items-center">
              <Calendar className="h-3 w-3 mr-1 text-blue-600" />
              <span className="font-medium text-blue-600">{day.etiqueta.split(" ")[0]}</span>
            </div>
            <span className="text-gray-700">{day.etiqueta.split(" ").slice(1).join(" ")}</span>
          </div>
        </button>
      ))}
    </div>
  )
}
