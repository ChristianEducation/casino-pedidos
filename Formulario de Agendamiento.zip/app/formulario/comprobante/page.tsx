"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useSearchParams, useRouter } from "next/navigation"
import { ArrowLeft, Upload, Check, Copy } from "lucide-react"
import Image from "next/image"

// URL fija del webhook para evitar problemas con variables de entorno
const WEBHOOK_URL = process.env.NEXT_PUBLIC_WEBHOOK_URL || ""

export default function ComprobantePage() {
  const searchParams = useSearchParams()
  const router = useRouter()
  const sessionId = searchParams.get("sessionId")
  const [file, setFile] = useState<File | null>(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [success, setSuccess] = useState(false)
  const [previewUrl, setPreviewUrl] = useState<string | null>(null)

  // Añadir el estado para manejar la copia al portapapeles después de la declaración de los otros estados
  const [copiado, setCopiado] = useState(false)

  // Intentar recuperar los datos del formulario del sessionStorage
  const [formDataFromStorage, setFormDataFromStorage] = useState<any>(null)

  useEffect(() => {
    if (sessionId) {
      try {
        const storedData = sessionStorage.getItem("formData")
        if (storedData) {
          setFormDataFromStorage(JSON.parse(storedData))
        }
      } catch (error) {
        console.error("Error al recuperar datos del formulario:", error)
      }
    }
  }, [sessionId])

  // Verificar que tengamos un sessionId
  useEffect(() => {
    if (!sessionId) {
      router.push("/formulario")
    }
  }, [sessionId, router])

  // Manejar la selección de archivo
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0] || null
    setFile(selectedFile)

    // Crear una URL para previsualizar la imagen
    if (selectedFile) {
      const url = URL.createObjectURL(selectedFile)
      setPreviewUrl(url)
      return () => URL.revokeObjectURL(url)
    } else {
      setPreviewUrl(null)
    }
  }

  // Enviar el comprobante
  const enviarComprobante = async () => {
    if (!file) {
      setError("Por favor, selecciona un archivo")
      return
    }

    try {
      setLoading(true)
      setError(null)

      // En un caso real, aquí subirías el archivo a un servicio de almacenamiento
      // y obtendrías la URL del archivo subido
      // Para este ejemplo, simulamos una URL
      const fileUrl = `https://ejemplo.com/comprobantes/${sessionId}_${file.name}`

      // Enviar la URL del comprobante al webhook
      const response = await fetch(WEBHOOK_URL, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Accept: "application/json",
        },
        mode: "cors",
        body: JSON.stringify({
          sessionId,
          phone_id: formDataFromStorage?.telefono || sessionId, // Usar el teléfono si está disponible
          type: "comprobante",
          message: "Aquí está el comprobante.",
          file_url: fileUrl,
        }),
      })

      if (!response.ok) {
        throw new Error(`Error al enviar el comprobante: ${response.status} ${response.statusText}`)
      }

      setSuccess(true)
    } catch (err) {
      console.error("Error al enviar comprobante:", err)
      setError(err instanceof Error ? err.message : "Error al enviar el comprobante")
    } finally {
      setLoading(false)
    }
  }

  // Añadir la función para copiar los datos de transferencia después de la función enviarComprobante
  const copiarDatosTransferencia = () => {
    const datosTransferencia = `
Titular: Christian Wevar Herrera
RUT: 18.311.400-K
Cuenta Vista
Número de Cuenta: 18311400
Banco: Banco Estado
`
    navigator.clipboard
      .writeText(datosTransferencia.trim())
      .then(() => {
        setCopiado(true)
        setTimeout(() => setCopiado(false), 3000) // Resetear el estado después de 3 segundos
      })
      .catch((err) => {
        console.error("Error al copiar datos:", err)
      })
  }

  // Volver al inicio
  const volverAlInicio = () => {
    router.push("/")
  }

  return (
    <div className="min-h-screen bg-[#F5F8EE] py-8 px-4 sm:px-6 lg:px-8">
      <div className="max-w-3xl mx-auto">
        <div className="flex justify-center mb-6">
          <Image
            src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-hEUqx9zYXyfZPOWIn8lYLlCCGRVblj.png"
            alt="Delicias Food Service Logo"
            width={200}
            height={80}
            className="h-auto"
          />
        </div>
        <div className="bg-white rounded-2xl shadow-md overflow-hidden transition-all duration-300">
          <div className="p-6">
            <h1 className="text-2xl font-bold text-[#1e1e2d] mb-6">Subir Comprobante de Pago</h1>

            {success ? (
              <div className="space-y-6">
                <div className="bg-green-50 border border-green-200 rounded-xl p-6 mb-6">
                  <div className="flex items-center justify-center mb-4">
                    <div className="bg-green-100 rounded-full p-3">
                      <Check className="h-8 w-8 text-green-600" />
                    </div>
                  </div>
                  <h3 className="text-lg font-medium text-green-800 mb-2 text-center">
                    ¡Comprobante enviado con éxito!
                  </h3>
                  <p className="text-green-700 text-center">
                    Tu comprobante ha sido recibido correctamente. Gracias por tu preferencia.
                  </p>
                </div>

                <button
                  onClick={volverAlInicio}
                  className="w-full bg-[#9ACA3C] text-white py-3 px-6 rounded-xl hover:bg-[#8BB52E] focus:outline-none focus:ring-2 focus:ring-[#9ACA3C] focus:ring-offset-2 transition-all duration-200"
                >
                  Volver al Inicio
                </button>
              </div>
            ) : (
              <div className="space-y-6">
                <p className="text-gray-600 mb-6">
                  Por favor, sube una imagen o PDF de tu comprobante de pago para completar tu pedido.
                </p>

                <div className="bg-[#F5F8EE] border border-[#9ACA3C]/20 rounded-xl p-6 mb-6">
                  <h3 className="text-lg font-medium text-[#1e1e2d] mb-3">Datos para Transferencia</h3>
                  <div className="space-y-2">
                    <p className="text-sm text-gray-700">
                      <span className="font-medium">Titular:</span> Christian Wevar Herrera
                    </p>
                    <p className="text-sm text-gray-700">
                      <span className="font-medium">RUT:</span> 18.311.400-K
                    </p>
                    <p className="text-sm text-gray-700">
                      <span className="font-medium">Tipo de cuenta:</span> Cuenta Vista
                    </p>
                    <p className="text-sm text-gray-700">
                      <span className="font-medium">Número de Cuenta:</span> 18311400
                    </p>
                    <p className="text-sm text-gray-700">
                      <span className="font-medium">Banco:</span> Banco Estado
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={copiarDatosTransferencia}
                    className="mt-4 flex items-center justify-center w-full bg-[#9ACA3C]/10 text-[#9ACA3C] py-2 px-4 rounded-lg hover:bg-[#9ACA3C]/20 focus:outline-none focus:ring-2 focus:ring-[#9ACA3C] focus:ring-offset-2 transition-all duration-200"
                  >
                    {copiado ? (
                      <>
                        <Check className="h-4 w-4 mr-2" />
                        ¡Copiado al portapapeles!
                      </>
                    ) : (
                      <>
                        <Copy className="h-4 w-4 mr-2" />
                        Copiar datos de transferencia
                      </>
                    )}
                  </button>
                </div>

                <div className="border-2 border-dashed border-gray-300 rounded-xl p-6 text-center">
                  <input
                    type="file"
                    id="comprobante"
                    accept="image/*,.pdf"
                    onChange={handleFileChange}
                    className="hidden"
                  />
                  <label htmlFor="comprobante" className="cursor-pointer flex flex-col items-center justify-center">
                    <Upload className="h-12 w-12 text-gray-400 mb-3" />
                    <span className="text-base font-medium text-gray-700">
                      {file ? file.name : "Haz clic para seleccionar un archivo"}
                    </span>
                    <span className="text-sm text-gray-500 mt-1">Formatos aceptados: JPG, PNG, PDF (máx. 5MB)</span>
                  </label>
                </div>

                {previewUrl && file?.type.startsWith("image/") && (
                  <div className="mt-4">
                    <p className="text-sm font-medium text-gray-700 mb-2">Vista previa:</p>
                    <div className="rounded-lg overflow-hidden border border-gray-200">
                      <img src={previewUrl || "/placeholder.svg"} alt="Vista previa" className="max-h-64 mx-auto" />
                    </div>
                  </div>
                )}

                {error && (
                  <div className="bg-red-50 border border-red-200 rounded-xl p-4">
                    <p className="text-red-600">{error}</p>
                  </div>
                )}

                <div className="flex space-x-4 pt-4">
                  <button
                    type="button"
                    onClick={() => router.push(`/formulario?sessionId=${sessionId}`)}
                    className="w-1/2 flex items-center justify-center bg-gray-200 text-gray-800 py-3 px-6 rounded-xl hover:bg-gray-300 focus:outline-none focus:ring-2 focus:ring-gray-500 focus:ring-offset-2 transition-all duration-200"
                  >
                    <ArrowLeft className="h-5 w-5 mr-2" />
                    Volver
                  </button>
                  <button
                    type="button"
                    onClick={enviarComprobante}
                    disabled={!file || loading}
                    className="w-1/2 bg-[#9ACA3C] text-white py-3 px-6 rounded-xl hover:bg-[#8BB52E] focus:outline-none focus:ring-2 focus:ring-[#9ACA3C] focus:ring-offset-2 transition-all duration-200 disabled:opacity-50"
                  >
                    {loading ? "Enviando..." : "Enviar Comprobante"}
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
