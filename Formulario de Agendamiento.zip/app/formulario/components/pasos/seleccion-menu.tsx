"use client"

import type React from "react"
import { useState, useEffect } from "react"
import type { FormData, Semana, OpcionMenu, DatosHijo } from "../formulario-multi-step"
import { obtenerMenusYColacionesPorSemana } from "@/lib/supabase"

interface SeleccionMenuProps {
  formData: FormData
  actualizarFormData: (data: Partial<FormData>) => void
  siguientePaso: () => void
  anteriorPaso: () => void
  semanas: Semana[]
  opcionesMenu: OpcionMenu[]
}

interface MenusPorDia {
  lunes: OpcionMenu[]
  martes: OpcionMenu[]
  miercoles: OpcionMenu[]
  jueves: OpcionMenu[]
  viernes: OpcionMenu[]
}

export function SeleccionMenu({
  formData,
  actualizarFormData,
  siguientePaso,
  anteriorPaso,
  semanas,
  opcionesMenu,
}: SeleccionMenuProps) {
  // Inicializar hijoActivo con el ID del primer hijo si existe
  const [hijoActivo, setHijoActivo] = useState<string>(() => {
    return formData.hijos.length > 0 ? formData.hijos[0].id : ""
  })

  const [menusPorDia, setMenusPorDia] = useState<MenusPorDia>({
    lunes: [],
    martes: [],
    miercoles: [],
    jueves: [],
    viernes: [],
  })
  const [cargandoMenus, setCargandoMenus] = useState(false)
  const [errorMenus, setErrorMenus] = useState<string | null>(null)
  const [precioEstandar, setPrecioEstandar] = useState(2930)
  const [precioFuncionario, setPrecioFuncionario] = useState(1500)

  // Función para formatear precio en pesos chilenos
  const formatearPrecio = (precio: number): string => {
    return new Intl.NumberFormat("es-CL", {
      style: "currency",
      currency: "CLP",
      minimumFractionDigits: 0,
    }).format(precio)
  }

  // Actualizar hijoActivo cuando cambian los hijos
  useEffect(() => {
    if (formData.hijos.length > 0 && !formData.hijos.find((h) => h.id === hijoActivo)) {
      setHijoActivo(formData.hijos[0].id)
    }
  }, [formData.hijos, hijoActivo])

  // Cargar menús específicos para la semana seleccionada
  useEffect(() => {
    const cargarMenusPorSemana = async () => {
      if (!formData.semanaSeleccionada) return

      try {
        setCargandoMenus(true)
        setErrorMenus(null)

        const { menus } = await obtenerMenusYColacionesPorSemana(
          formData.semanaSeleccionada.id,
          formData.semanaSeleccionada.fechaInicio,
          formData.semanaSeleccionada.fechaFin,
        )

        setMenusPorDia(menus)

        // Obtener el precio estándar y de funcionario del primer menú disponible
        const diasConMenu = Object.keys(menus) as (keyof MenusPorDia)[]
        for (const dia of diasConMenu) {
          if (menus[dia].length > 0) {
            const primerMenu = menus[dia][0]
            if (primerMenu.precio) {
              setPrecioEstandar(primerMenu.precio)
            }
            if (primerMenu.precioFuncionario) {
              setPrecioFuncionario(primerMenu.precioFuncionario)
            }
            break
          }
        }
      } catch (error) {
        console.error("Error al cargar menús por semana:", error)
        setErrorMenus("No se pudieron cargar los menús para esta semana. Por favor, intenta de nuevo.")
      } finally {
        setCargandoMenus(false)
      }
    }

    cargarMenusPorSemana()
  }, [formData.semanaSeleccionada])

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    siguientePaso()
  }

  const handleMenuChange = (hijoId: string, dia: keyof DatosHijo["menu"], valor: string | null) => {
    actualizarFormData({
      hijos: formData.hijos.map((hijo) => {
        if (hijo.id === hijoId) {
          return {
            ...hijo,
            menu: {
              ...hijo.menu,
              [dia]: valor,
            },
          }
        }
        return hijo
      }),
    })
  }

  const handleSemanaChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const semanaId = e.target.value
    const semanaSeleccionada = semanas.find((s) => s.id === semanaId) || null
    actualizarFormData({ semanaSeleccionada })
  }

  // Función para formatear la fecha en formato legible
  const formatearFecha = (fecha: string): string => {
    const opciones: Intl.DateTimeFormatOptions = { day: "numeric", month: "long" }
    return new Date(fecha).toLocaleDateString("es-ES", opciones)
  }

  // Verificar si hay hijos disponibles
  if (formData.hijos.length === 0) {
    return (
      <div className="transition-all duration-300">
        <h2 className="section-title">Selección de Almuerzos</h2>

        <div className="info-card bg-yellow-50">
          <p className="text-sm text-yellow-700">
            {formData.tipoUsuario === "funcionario"
              ? "No has agregado hijos para pedidos. Si deseas realizar pedidos para tus hijos, regresa al paso anterior."
              : "No hay alumnos registrados. Por favor, regresa al paso anterior y agrega al menos un alumno."}
          </p>
        </div>

        <div className="pt-4">
          <button type="button" onClick={anteriorPaso} className="w-full btn-secondary">
            Volver
          </button>
        </div>
      </div>
    )
  }

  // Encontrar el hijo activo de manera segura
  const hijoActual =
    formData.hijos.length > 0 ? formData.hijos.find((hijo) => hijo.id === hijoActivo) || formData.hijos[0] : null

  // Determinar si el hijo actual es el funcionario
  const esFuncionarioPrincipal = hijoActual?.esFuncionario || false

  // Renderizar opciones de menú para un día específico
  const renderOpcionesMenu = (dia: keyof MenusPorDia) => {
    const opciones = menusPorDia[dia]

    if (cargandoMenus) {
      return <div className="py-2 text-gray-500 text-sm">Cargando opciones de menú...</div>
    }

    if (errorMenus) {
      return <div className="py-2 text-red-500 text-sm">Error al cargar menús: {errorMenus}</div>
    }

    if (opciones.length === 0) {
      return <div className="py-2 text-gray-500 text-sm">No hay opciones disponibles para este día.</div>
    }

    return (
      <>
        <select
          id={`menu-${dia}`}
          value={hijoActual?.menu?.[dia] || ""}
          onChange={(e) => handleMenuChange(hijoActual.id, dia as keyof DatosHijo["menu"], e.target.value || null)}
          className="form-select"
        >
          <option value="">No seleccionar</option>
          {opciones.map((opcion) => (
            <option key={opcion.id} value={opcion.nombre}>
              {opcion.descripcion || opcion.nombre}
            </option>
          ))}
        </select>
        <div className="mt-2 text-sm text-gray-600">
          {esFuncionarioPrincipal ? (
            <p>Todos los almuerzos valen {formatearPrecio(precioFuncionario)}</p>
          ) : (
            <p>Todos los almuerzos valen {formatearPrecio(precioEstandar)}</p>
          )}
        </div>
      </>
    )
  }

  return (
    <div className="transition-all duration-300">
      <h2 className="section-title">Selección de Almuerzos</h2>

      {/* Selector de semana */}
      <div className="mb-6">
        <label htmlFor="semana" className="form-label">
          Selecciona la semana para el pedido
        </label>
        <select
          id="semana"
          value={formData.semanaSeleccionada?.id || ""}
          onChange={handleSemanaChange}
          className="form-select"
          required
        >
          {semanas.map((semana) => (
            <option key={semana.id} value={semana.id}>
              {semana.nombre} ({formatearFecha(semana.fechaInicio)} al {formatearFecha(semana.fechaFin)})
            </option>
          ))}
        </select>
      </div>

      {/* Información de la semana seleccionada */}
      {formData.semanaSeleccionada && (
        <div className="info-card">
          <p className="info-text">
            <span className="font-medium">Pedido para la semana:</span> {formData.semanaSeleccionada.nombre}
          </p>
          <p className="info-text">
            <span className="font-medium">Período:</span> Del {formatearFecha(formData.semanaSeleccionada.fechaInicio)}{" "}
            al {formatearFecha(formData.semanaSeleccionada.fechaFin)}
          </p>
        </div>
      )}

      {/* Selector de hijo/alumno */}
      {formData.hijos.length > 0 && (
        <div className="mb-6">
          <label className="form-label">Selecciona para quién estás haciendo el pedido</label>
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
            {formData.hijos.map((hijo) => (
              <button
                key={hijo.id}
                type="button"
                onClick={() => setHijoActivo(hijo.id)}
                className={`p-3 rounded-lg text-left transition-all duration-300 ${
                  hijoActivo === hijo.id
                    ? "bg-[#F5F8EE] border-[#9ACA3C] border-2"
                    : "bg-gray-50 border border-gray-200 hover:border-[#9ACA3C]"
                }`}
              >
                <p className="font-medium">{hijo.esFuncionario ? "Tú" : hijo.nombre}</p>
                <p className="text-sm text-gray-600">
                  {hijo.curso} {hijo.letra}
                </p>
              </button>
            ))}
          </div>
        </div>
      )}

      <p className="text-gray-600 mb-6">
        Selecciona las opciones de almuerzo para cada día. Puedes dejar días sin seleccionar si no deseas pedir almuerzo
        para ese día.
      </p>

      <form onSubmit={handleSubmit}>
        <div className="space-y-6">
          {hijoActual && (
            <div className="info-card">
              <p className="info-text font-medium">
                {esFuncionarioPrincipal
                  ? "Seleccionando almuerzos para ti"
                  : `Seleccionando almuerzos para: ${hijoActual.nombre}`}
              </p>
              {esFuncionarioPrincipal && (
                <p className="info-text mt-1">Como funcionario, tienes precios especiales en tus almuerzos.</p>
              )}
            </div>
          )}

          {/* Lunes */}
          <div>
            <label htmlFor="menu-lunes" className="form-label">
              Lunes
            </label>
            {renderOpcionesMenu("lunes")}
          </div>

          {/* Martes */}
          <div>
            <label htmlFor="menu-martes" className="form-label">
              Martes
            </label>
            {renderOpcionesMenu("martes")}
          </div>

          {/* Miércoles */}
          <div>
            <label htmlFor="menu-miercoles" className="form-label">
              Miércoles
            </label>
            {renderOpcionesMenu("miercoles")}
          </div>

          {/* Jueves */}
          <div>
            <label htmlFor="menu-jueves" className="form-label">
              Jueves
            </label>
            {renderOpcionesMenu("jueves")}
          </div>

          {/* Viernes */}
          <div>
            <label htmlFor="menu-viernes" className="form-label">
              Viernes
            </label>
            {renderOpcionesMenu("viernes")}
          </div>

          {/* Observaciones */}
          <div className="mt-8 border-t border-gray-200 pt-6">
            <label htmlFor="observaciones-almuerzos" className="form-label">
              Observaciones sobre almuerzos
            </label>
            <textarea
              id="observaciones-almuerzos"
              value={formData.observacionesAlmuerzos}
              onChange={(e) => actualizarFormData({ observacionesAlmuerzos: e.target.value })}
              className="form-input"
              placeholder="Escribe aquí cualquier observación o requerimiento especial sobre los almuerzos"
              rows={3}
            />
            <p className="mt-2 text-sm text-gray-500">
              Por ejemplo: alergias, preferencias alimentarias, restricciones dietéticas, etc.
            </p>
          </div>

          <div className="pt-4 flex space-x-4">
            <button type="button" onClick={anteriorPaso} className="w-1/2 btn-secondary">
              Anterior
            </button>
            <button type="submit" className="w-1/2 btn-primary">
              Siguiente
            </button>
          </div>
        </div>
      </form>
    </div>
  )
}
