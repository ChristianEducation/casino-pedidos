import { createRouteHandlerClient } from "@supabase/auth-helpers-nextjs"
import { cookies } from "next/headers"
import { NextResponse } from "next/server"
import type { NextRequest } from "next/server"

export const dynamic = "force-dynamic"

export async function GET(request: NextRequest) {
  const requestUrl = new URL(request.url)
  const code = requestUrl.searchParams.get("code")
  const redirectParam = requestUrl.searchParams.get("redirect")

  console.log("Callback de autenticación recibido")
  console.log("URL:", request.url)
  console.log("Código:", code)
  console.log("Redirección:", redirectParam)

  if (code) {
    const cookieStore = cookies()
    const supabase = createRouteHandlerClient({ cookies: () => cookieStore })

    try {
      console.log("Intercambiando código por sesión...")
      const { error } = await supabase.auth.exchangeCodeForSession(code)

      if (error) {
        console.error("Error al intercambiar código:", error)
        return NextResponse.redirect(new URL(`/login?error=${encodeURIComponent(error.message)}`, request.url))
      }

      // Determinar la URL de redirección
      let redirectUrl = "/dashboard"

      // Si hay un parámetro de redirección en la URL, usarlo
      if (redirectParam) {
        redirectUrl = redirectParam
        console.log("Usando redirección desde parámetro:", redirectUrl)
      }

      console.log("Intercambio exitoso, redirigiendo a:", redirectUrl)

      // Asegurarse de que la URL sea absoluta
      const baseUrl = new URL(request.url).origin
      const fullRedirectUrl = new URL(redirectUrl, baseUrl)

      return NextResponse.redirect(fullRedirectUrl)
    } catch (error) {
      console.error("Error en callback de autenticación:", error)
      return NextResponse.redirect(new URL(`/login?error=${encodeURIComponent("Error en autenticación")}`, request.url))
    }
  }

  // Si no hay código, redirigir a login
  console.log("No se encontró código, redirigiendo a login")
  return NextResponse.redirect(new URL("/login", request.url))
}
