import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"
import Link from "next/link"

export default function AyudaPage() {
  return (
    <div className="container mx-auto py-8 px-4">
      <h1 className="text-3xl font-bold mb-6">Ayuda y Soporte</h1>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="md:col-span-2">
          <Card>
            <CardHeader>
              <CardTitle>Preguntas Frecuentes</CardTitle>
              <CardDescription>Respuestas a las preguntas más comunes sobre nuestra plataforma</CardDescription>
            </CardHeader>
            <CardContent>
              <Accordion type="single" collapsible className="w-full">
                <AccordionItem value="item-1">
                  <AccordionTrigger>¿Cómo realizo un pedido?</AccordionTrigger>
                  <AccordionContent>
                    Para realizar un pedido, debes iniciar sesión en tu cuenta y dirigirte a la sección "Realizar
                    Pedido". Allí podrás completar el formulario con los datos necesarios para tu pedido escolar.
                  </AccordionContent>
                </AccordionItem>

                <AccordionItem value="item-2">
                  <AccordionTrigger>¿Cómo puedo ver mi historial de pedidos?</AccordionTrigger>
                  <AccordionContent>
                    Puedes acceder a tu historial de pedidos desde la sección "Historial" en el menú principal o desde
                    tu dashboard. Allí encontrarás todos tus pedidos anteriores con sus detalles.
                  </AccordionContent>
                </AccordionItem>

                <AccordionItem value="item-3">
                  <AccordionTrigger>¿Cómo actualizo mi información de perfil?</AccordionTrigger>
                  <AccordionContent>
                    Para actualizar tu información de perfil, haz clic en tu avatar en la esquina superior derecha y
                    selecciona "Mi Perfil". Allí podrás editar tu información personal y la de tus hijos.
                  </AccordionContent>
                </AccordionItem>

                <AccordionItem value="item-4">
                  <AccordionTrigger>¿Olvidé mi contraseña, cómo puedo recuperarla?</AccordionTrigger>
                  <AccordionContent>
                    Si olvidaste tu contraseña, ve a la página de inicio de sesión y haz clic en "¿Olvidaste tu
                    contraseña?". Sigue las instrucciones para recibir un correo electrónico con los pasos para
                    restablecerla.
                  </AccordionContent>
                </AccordionItem>
              </Accordion>
            </CardContent>
          </Card>
        </div>

        <div>
          <Card>
            <CardHeader>
              <CardTitle>Contacto</CardTitle>
              <CardDescription>¿Necesitas ayuda adicional?</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-sm">Si no encuentras respuesta a tu pregunta, puedes contactarnos directamente:</p>

              <div className="space-y-2">
                <p className="text-sm font-medium">Correo electrónico:</p>
                <p className="text-sm">soporte@deliciasfoodservice.com</p>
              </div>

              <div className="space-y-2">
                <p className="text-sm font-medium">Teléfono:</p>
                <p className="text-sm">+56 9 1234 5678</p>
              </div>

              <div className="space-y-2">
                <p className="text-sm font-medium">Horario de atención:</p>
                <p className="text-sm">Lunes a Viernes: 9:00 - 18:00</p>
              </div>

              <div className="pt-4">
                <Link
                  href="/dashboard"
                  className="inline-flex items-center text-[#9ACA3C] hover:text-[#8BB52E] font-medium"
                >
                  Volver al Dashboard
                </Link>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
