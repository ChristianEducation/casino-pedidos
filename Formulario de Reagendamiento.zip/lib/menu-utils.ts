import { supabase } from "@/utils/supabase"
import type { OpcionMenu, SemanaDisponible } from "@/types"
import { formatDateToLongString } from "@/lib/date-utils"

/**
 * Obtiene las opciones de menú para una fecha específica
 */
export async function getOpcionesMenuPorFecha(fecha: string): Promise<OpcionMenu[]> {
  try {
    console.log(`Consultando opciones de menú para fecha: ${fecha}`)

    const { data, error } = await supabase
      .from("almuerzos_menu")
      .select("id, fecha, dia, codigo, descripcion, precio_estudiante, precio_funcionario, tipo_dia")
      .eq("fecha", fecha)
      .eq("tipo_dia", "Hábil")
      .order("codigo", { ascending: true })

    if (error) {
      console.error("Error al obtener opciones de menú:", error)
      return []
    }

    console.log(`Opciones encontradas para ${fecha}: ${data?.length || 0}`)
    return data || []
  } catch (err) {
    console.error("Error al consultar opciones de menú:", err)
    return []
  }
}

/**
 * Obtiene las opciones de menú para una semana completa
 */
export async function getOpcionesMenuPorSemana(semanaId: string): Promise<OpcionMenu[]> {
  try {
    // El semanaId tiene el formato "fechaInicio_fechaFin"
    const [fechaInicio, fechaFin] = semanaId.split("_")

    if (!fechaInicio || !fechaFin) {
      console.error("Formato de semanaId inválido:", semanaId)
      return []
    }

    console.log(`Consultando opciones de menú para semana del ${fechaInicio} al ${fechaFin}`)

    const { data, error } = await supabase
      .from("almuerzos_menu")
      .select("id, fecha, dia, codigo, descripcion, precio_estudiante, precio_funcionario, tipo_dia")
      .gte("fecha", fechaInicio)
      .lte("fecha", fechaFin)
      .eq("tipo_dia", "Hábil")
      .order("fecha", { ascending: true })
      .order("codigo", { ascending: true })

    if (error) {
      console.error("Error al obtener opciones de menú para la semana:", error)
      return []
    }

    console.log(`Opciones encontradas para la semana: ${data?.length || 0}`)
    return data || []
  } catch (err) {
    console.error("Error al consultar opciones de menú para la semana:", err)
    return []
  }
}

/**
 * Agrupa opciones de menú por día
 */
export function agruparOpcionesPorDia(opciones: OpcionMenu[]): Record<string, OpcionMenu[]> {
  const opcionesPorDia: Record<string, OpcionMenu[]> = {}

  opciones.forEach((opcion) => {
    if (!opcionesPorDia[opcion.fecha]) {
      opcionesPorDia[opcion.fecha] = []
    }

    opcionesPorDia[opcion.fecha].push(opcion)
  })

  // Ordenar las opciones de cada día por código
  Object.keys(opcionesPorDia).forEach((fecha) => {
    opcionesPorDia[fecha].sort((a, b) => a.codigo.localeCompare(b.codigo))
  })

  return opcionesPorDia
}

/**
 * Verifica si hay opciones de menú disponibles para una fecha
 */
export async function hayOpcionesMenuDisponibles(fecha: string): Promise<boolean> {
  try {
    const opciones = await getOpcionesMenuPorFecha(fecha)
    return opciones.length > 0
  } catch (err) {
    console.error("Error al verificar disponibilidad de menú:", err)
    return false
  }
}

/**
 * Obtiene las semanas disponibles con menús desde la base de datos
 */
export async function getSemanasDisponiblesConMenu(): Promise<SemanaDisponible[]> {
  try {
    // Obtener la fecha de mañana
    const tomorrow = new Date()
    tomorrow.setDate(tomorrow.getDate() + 1)
    tomorrow.setHours(0, 0, 0, 0)
    const tomorrowStr = tomorrow.toISOString().split("T")[0]

    // Consultar fechas disponibles en la tabla almuerzos_menu
    const { data, error } = await supabase
      .from("almuerzos_menu")
      .select("fecha")
      .eq("tipo_dia", "Hábil")
      .gte("fecha", tomorrowStr)
      .order("fecha", { ascending: true })

    if (error) {
      console.error("Error al obtener fechas disponibles:", error)
      return []
    }

    // Crear conjunto de fechas disponibles
    const fechasDisponibles = new Set<string>()
    data.forEach((item) => fechasDisponibles.add(item.fecha))

    // Generar semanas disponibles
    const semanas: SemanaDisponible[] = []

    // Obtener fechas de la semana actual
    const today = new Date()
    const currentDay = today.getDay() // 0 = domingo, 1 = lunes, ..., 6 = sábado
    const daysUntilMonday = currentDay === 0 ? 1 : currentDay === 6 ? 2 : 8 - currentDay

    // Calcular el lunes de la semana actual
    const mondayCurrent = new Date(today)
    mondayCurrent.setDate(today.getDate() - currentDay + (currentDay === 0 ? -6 : 1))
    mondayCurrent.setHours(0, 0, 0, 0)

    // Calcular el viernes de la semana actual
    const fridayCurrent = new Date(mondayCurrent)
    fridayCurrent.setDate(mondayCurrent.getDate() + 4)

    // Calcular el lunes de la próxima semana
    const mondayNext = new Date(mondayCurrent)
    mondayNext.setDate(mondayCurrent.getDate() + 7)

    // Calcular el viernes de la próxima semana
    const fridayNext = new Date(mondayNext)
    fridayNext.setDate(mondayNext.getDate() + 4)

    // Formatear fechas
    const mondayCurrentStr = mondayCurrent.toISOString().split("T")[0]
    const fridayCurrentStr = fridayCurrent.toISOString().split("T")[0]
    const mondayNextStr = mondayNext.toISOString().split("T")[0]
    const fridayNextStr = fridayNext.toISOString().split("T")[0]

    // Generar días para la semana actual
    const diasSemanaActual = generateWeekDays(mondayCurrent, fridayCurrent, tomorrow, fechasDisponibles)

    // Generar días para la próxima semana
    const diasProximaSemana = generateWeekDays(mondayNext, fridayNext, tomorrow, fechasDisponibles)

    // Solo agregar la semana actual si tiene al menos un día disponible
    const diasDisponiblesSemanaActual = diasSemanaActual.filter((dia) => dia.disponible)
    if (diasDisponiblesSemanaActual.length > 0) {
      semanas.push({
        id: `${mondayCurrentStr}_${fridayCurrentStr}`,
        fechaInicio: mondayCurrentStr,
        fechaFin: fridayCurrentStr,
        label: `${mondayCurrent.getDate()} - ${fridayCurrent.getDate()} de ${getMonthName(mondayCurrent.getMonth())}`,
        dias: diasSemanaActual,
      })
    }

    // Solo agregar la próxima semana si tiene al menos un día disponible
    const diasDisponiblesProximaSemana = diasProximaSemana.filter((dia) => dia.disponible)
    if (diasDisponiblesProximaSemana.length > 0) {
      semanas.push({
        id: `${mondayNextStr}_${fridayNextStr}`,
        fechaInicio: mondayNextStr,
        fechaFin: fridayNextStr,
        label: `${mondayNext.getDate()} - ${fridayNext.getDate()} de ${getMonthName(mondayNext.getMonth())}`,
        dias: diasProximaSemana,
      })
    }

    return semanas
  } catch (err) {
    console.error("Error al obtener semanas disponibles con menú:", err)
    return []
  }
}

/**
 * Genera los días de una semana
 */
function generateWeekDays(
  monday: Date,
  friday: Date,
  minDate: Date,
  availableDates: Set<string>,
): { fecha: string; label: string; disponible: boolean }[] {
  const days = []
  const currentDate = new Date(monday)

  while (currentDate <= friday) {
    if (isWeekday(currentDate)) {
      const dateStr = currentDate.toISOString().split("T")[0]
      const isAvailable = currentDate >= minDate && availableDates.has(dateStr)

      days.push({
        fecha: dateStr,
        label: formatDateToLongString(currentDate),
        disponible: isAvailable,
      })
    }

    currentDate.setDate(currentDate.getDate() + 1)
  }

  return days
}

/**
 * Verifica si una fecha es un día hábil (lunes a viernes)
 */
function isWeekday(date: Date): boolean {
  const day = date.getDay()
  return day >= 1 && day <= 5 // 1 = lunes, 5 = viernes
}

/**
 * Obtiene el nombre del mes en español
 */
function getMonthName(month: number): string {
  const meses = [
    "enero",
    "febrero",
    "marzo",
    "abril",
    "mayo",
    "junio",
    "julio",
    "agosto",
    "septiembre",
    "octubre",
    "noviembre",
    "diciembre",
  ]
  return meses[month]
}
