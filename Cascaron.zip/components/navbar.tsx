"use client"
import Image from "next/image"
import { usePathname, useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Menu, X, LogOut, UserCircle, History, FileText, HelpCircle, Home, LayoutDashboard } from "lucide-react"
import { useState, useEffect } from "react"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
  DropdownMenuGroup,
  DropdownMenuShortcut,
} from "@/components/ui/dropdown-menu"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { toast } from "@/components/ui/use-toast"
import { useSession, useSupabaseClient } from "@supabase/auth-helpers-react"

export default function Navbar() {
  const pathname = usePathname()
  const router = useRouter()
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const session = useSession()
  const supabase = useSupabaseClient()
  const [mounted, setMounted] = useState(false)
  const [isLoading, setIsLoading] = useState(false)

  // Evitar problemas de hidratación
  useEffect(() => {
    setMounted(true)
  }, [])

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen)
  }

  const handleSignOut = async () => {
    try {
      setIsLoading(true)
      console.log("Iniciando proceso de cierre de sesión")

      // Cerrar sesión en Supabase
      await supabase.auth.signOut()

      // Mostrar toast después de cerrar sesión
      toast({
        title: "Sesión cerrada",
        description: "Has cerrado sesión correctamente",
      })

      // Redirigir a la página de inicio
      router.push("/")
    } catch (error) {
      console.error("Error al cerrar sesión:", error)
      toast({
        title: "Error",
        description: "No se pudo cerrar sesión. Intenta de nuevo.",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  // No mostrar el navbar durante la carga inicial o antes de la hidratación
  if (!mounted) {
    return (
      <header className="bg-[#1e1e2d] text-white shadow-md sticky top-0 z-50">
        <div className="container mx-auto px-4">
          <div className="flex h-16 items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="relative h-10 w-40">
                <Image
                  src="/images/logo.png"
                  alt="Delicias Food Service"
                  fill
                  style={{ objectFit: "contain" }}
                  className="object-left"
                />
              </div>
              <span className="ml-2 text-xl font-bold text-white hidden lg:inline">PedidosEscolares</span>
            </div>
          </div>
        </div>
      </header>
    )
  }

  // Definir enlaces según el estado de autenticación
  const navLinks = session
    ? [
        { href: "/", label: "Inicio", icon: Home },
        { href: "/dashboard", label: "Dashboard", icon: LayoutDashboard },
        { href: "/formulario", label: "Realizar Pedido", icon: FileText },
        { href: "/historial", label: "Historial", icon: History },
      ]
    : [
        { href: "/", label: "Inicio", icon: Home },
        { href: "/login", label: "Iniciar Sesión", icon: UserCircle },
        { href: "/registro", label: "Registrarse", icon: UserCircle },
      ]

  // Obtener las iniciales del usuario para el avatar
  const getUserInitials = () => {
    if (!session?.user?.email) return "U"
    return session.user.email.substring(0, 1).toUpperCase()
  }

  // Función para manejar la navegación
  const handleNavigation = (href: string) => {
    console.log(`Navegando a: ${href}`)
    // Cerrar el menú móvil si está abierto
    if (isMenuOpen) {
      setIsMenuOpen(false)
    }
    // Usar router.push en lugar de Link para más control
    router.push(href)
  }

  return (
    <header className="bg-[#1e1e2d] text-white shadow-md sticky top-0 z-50">
      <div className="container mx-auto px-4">
        <div className="flex h-16 items-center justify-between">
          <div className="flex items-center gap-2">
            <button onClick={() => handleNavigation("/")} className="flex items-center focus:outline-none">
              <div className="relative h-10 w-40">
                <Image
                  src="/images/logo.png"
                  alt="Delicias Food Service"
                  fill
                  style={{ objectFit: "contain" }}
                  className="object-left"
                />
              </div>
              <span className="ml-2 text-xl font-bold text-white hidden lg:inline">PedidosEscolares</span>
            </button>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-6">
            {navLinks.map((link) => (
              <button
                key={link.href}
                onClick={() => handleNavigation(link.href)}
                className={`px-3 py-2 text-sm font-medium transition-colors hover:text-[#9ACA3C] focus:outline-none ${
                  pathname === link.href ? "text-[#9ACA3C]" : "text-gray-200"
                }`}
              >
                {link.label}
              </button>
            ))}

            {session && (
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" className="relative h-10 w-10 rounded-full focus:outline-none">
                    <Avatar className="h-9 w-9 border border-gray-600">
                      <AvatarImage
                        src={session.user.user_metadata?.avatar_url || ""}
                        alt={session.user.email || "Usuario"}
                      />
                      <AvatarFallback className="bg-[#9ACA3C] text-white">{getUserInitials()}</AvatarFallback>
                    </Avatar>
                    <span className="sr-only">Menú de usuario</span>
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent className="w-56" align="end" forceMount>
                  <DropdownMenuLabel className="font-normal">
                    <div className="flex flex-col space-y-1">
                      <p className="text-sm font-medium leading-none">{session.user.email}</p>
                    </div>
                  </DropdownMenuLabel>
                  <DropdownMenuSeparator />
                  <DropdownMenuGroup>
                    <DropdownMenuItem onClick={() => handleNavigation("/dashboard")}>
                      <LayoutDashboard className="mr-2 h-4 w-4" />
                      <span>Dashboard</span>
                    </DropdownMenuItem>
                    <DropdownMenuItem onClick={() => handleNavigation("/perfil")}>
                      <UserCircle className="mr-2 h-4 w-4" />
                      <span>Mi Perfil</span>
                    </DropdownMenuItem>
                    <DropdownMenuItem onClick={() => handleNavigation("/historial")}>
                      <History className="mr-2 h-4 w-4" />
                      <span>Historial de Pedidos</span>
                    </DropdownMenuItem>
                  </DropdownMenuGroup>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={() => handleNavigation("/ayuda")} disabled>
                    <HelpCircle className="mr-2 h-4 w-4" />
                    <span>Ayuda y Soporte</span>
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem
                    onClick={handleSignOut}
                    className="text-red-500 focus:text-red-500 cursor-pointer"
                    disabled={isLoading}
                  >
                    <LogOut className="mr-2 h-4 w-4" />
                    <span>{isLoading ? "Cerrando sesión..." : "Cerrar Sesión"}</span>
                    <DropdownMenuShortcut>⇧⌘Q</DropdownMenuShortcut>
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            )}
          </nav>

          {/* Mobile Menu Button */}
          <div className="md:hidden">
            <Button
              variant="ghost"
              size="icon"
              onClick={toggleMenu}
              aria-label="Toggle menu"
              className="text-white hover:text-[#9ACA3C] focus:outline-none"
            >
              {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </Button>
          </div>
        </div>

        {/* Mobile Navigation */}
        {isMenuOpen && (
          <div className="md:hidden py-2 pb-4">
            <div className="space-y-1">
              {navLinks.map((link) => (
                <button
                  key={link.href}
                  onClick={() => handleNavigation(link.href)}
                  className={`flex w-full items-center px-3 py-2 text-base font-medium focus:outline-none ${
                    pathname === link.href ? "text-[#9ACA3C]" : "text-gray-200 hover:text-[#9ACA3C]"
                  }`}
                >
                  <link.icon className="mr-2 h-5 w-5" />
                  {link.label}
                </button>
              ))}

              {session && (
                <>
                  <div className="px-3 py-2 mt-4">
                    <div className="flex items-center space-x-3">
                      <Avatar className="h-9 w-9 border border-gray-600">
                        <AvatarImage
                          src={session.user.user_metadata?.avatar_url || ""}
                          alt={session.user.email || "Usuario"}
                        />
                        <AvatarFallback className="bg-[#9ACA3C] text-white">{getUserInitials()}</AvatarFallback>
                      </Avatar>
                      <div>
                        <p className="text-sm font-medium">{session.user.email}</p>
                      </div>
                    </div>
                  </div>
                  <div className="border-t border-gray-700 my-2"></div>
                  <button
                    onClick={() => handleNavigation("/perfil")}
                    className="flex w-full items-center px-3 py-2 text-base font-medium text-gray-200 hover:text-[#9ACA3C] focus:outline-none"
                  >
                    <UserCircle className="mr-2 h-5 w-5" />
                    Mi Perfil
                  </button>
                  <button
                    onClick={() => handleNavigation("/historial")}
                    className="flex w-full items-center px-3 py-2 text-base font-medium text-gray-200 hover:text-[#9ACA3C] focus:outline-none"
                  >
                    <History className="mr-2 h-5 w-5" />
                    Historial de Pedidos
                  </button>
                  <button
                    onClick={handleSignOut}
                    className="flex w-full items-center px-3 py-2 text-base font-medium text-red-400 hover:text-red-300 cursor-pointer focus:outline-none"
                    disabled={isLoading}
                  >
                    <LogOut className="mr-2 h-5 w-5" />
                    <span>{isLoading ? "Cerrando sesión..." : "Cerrar Sesión"}</span>
                  </button>
                </>
              )}
            </div>
          </div>
        )}
      </div>
    </header>
  )
}
