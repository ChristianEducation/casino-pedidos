"use client"

import { useState } from "react"
import { Calendar } from "lucide-react"
import type { Pedido } from "@/types"
import PedidoItem from "./pedido-item"
import ModificarPedidoForm from "./modificar-pedido-form"

interface PedidosListProps {
  pedidos: Pedido[]
  userId: string
}

export default function PedidosList({ pedidos, userId }: PedidosListProps) {
  const [pedidoSeleccionado, setPedidoSeleccionado] = useState<Pedido | null>(null)

  const handleModificar = (pedido: Pedido) => {
    setPedidoSeleccionado(pedido)
  }

  const handleCancelarModificacion = () => {
    setPedidoSeleccionado(null)
  }

  const handlePedidoActualizado = () => {
    setPedidoSeleccionado(null)
    // Recargar la página para mostrar los datos actualizados
    window.location.reload()
  }

  if (pedidoSeleccionado) {
    return (
      <ModificarPedidoForm
        pedido={pedidoSeleccionado}
        onCancel={handleCancelarModificacion}
        onSuccess={handlePedidoActualizado}
        userId={userId}
      />
    )
  }

  // Formatear la fecha actual para mostrarla en formato DD/MM/YYYY
  const fechaActual = new Date()
  const fechaFormateada = `${fechaActual.getDate()}/${fechaActual.getMonth() + 1}/${fechaActual.getFullYear()}`

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-semibold text-gray-700">Pedidos disponibles para reagendar</h2>
        <div className="text-sm text-gray-500">
          <span className="inline-block px-2 py-1 bg-blue-100 text-blue-800 rounded-md flex items-center">
            <Calendar className="h-4 w-4 mr-1" />
            Fecha actual: {fechaFormateada}
          </span>
        </div>
      </div>

      <p className="text-sm text-gray-600 bg-yellow-50 p-3 rounded-md border border-yellow-200">
        Nota: Solo puedes modificar pedidos hasta las 9:00 AM del día anterior a la entrega.
      </p>

      <div className="space-y-4">
        {pedidos.length > 0 ? (
          pedidos.map((pedido) => (
            <PedidoItem key={pedido.codigo || pedido.id} pedido={pedido} onModificar={() => handleModificar(pedido)} />
          ))
        ) : (
          <div className="p-4 text-center bg-gray-50 rounded-md border border-gray-200">
            <p className="text-gray-600">No hay pedidos disponibles para reagendar.</p>
          </div>
        )}
      </div>
    </div>
  )
}
