"use client"

import { createContext, useContext, useEffect, useState, useCallback, type ReactNode, Suspense } from "react"
import type { Session, User } from "@supabase/supabase-js"
import {
  getSupabase,
  getUserProfile,
  signInWithGoogle as supabaseSignInWithGoogle,
  isOfflineMode,
  saveRedirectUrl,
  getRedirectUrl,
} from "@/lib/supabase-client"
import { useRouter, usePathname, useSearchParams } from "next/navigation"
import { toast } from "@/components/ui/use-toast"

type AuthContextType = {
  user: User | null
  session: Session | null
  isLoading: boolean
  hasProfile: boolean
  isProfileComplete: boolean
  isOffline: boolean
  signIn: (email: string, password: string, redirectTo?: string) => Promise<void>
  signUp: (email: string, password: string) => Promise<void>
  signOut: () => Promise<void>
  signInWithGoogle: (redirectTo?: string) => Promise<void>
  setHasProfile: (value: boolean) => void
  setIsProfileComplete: (value: boolean) => void
  retryConnection: () => Promise<boolean>
  error: string | null
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

// Componente interno que usa useSearchParams
function AuthProviderWithSearchParams({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null)
  const [session, setSession] = useState<Session | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [hasProfile, setHasProfile] = useState(false)
  const [isProfileComplete, setIsProfileComplete] = useState(false)
  const [isOffline, setIsOffline] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [isInitialized, setIsInitialized] = useState(false)

  const router = useRouter()
  const pathname = usePathname()
  const searchParams = useSearchParams()

  // Verificar conexión a internet solo cuando sea necesario
  const checkConnection = useCallback(() => {
    const offline = isOfflineMode()
    setIsOffline(offline)
    return !offline
  }, [])

  // Función para reintentar la conexión
  const retryConnection = useCallback(async () => {
    setIsLoading(true)
    setError(null)

    try {
      const isOnline = checkConnection()
      if (!isOnline) {
        setError("No hay conexión a internet. Verifica tu conexión y vuelve a intentarlo.")
        return false
      }

      // Verificar si el cliente de Supabase está inicializado
      const supabase = getSupabase()
      if (!supabase) {
        setError("Cliente de Supabase no inicializado. Verifica las variables de entorno.")
        return false
      }

      // Verificar si hay una sesión activa
      const { data, error: sessionError } = await supabase.auth.getSession()
      if (sessionError) {
        setError(`Error al obtener sesión: ${sessionError.message}`)
        return false
      }

      // Actualizar el estado con la sesión
      setSession(data.session)
      setUser(data.session?.user || null)

      // Si hay usuario, verificar perfil
      if (data.session?.user) {
        await checkUserProfile(data.session.user.id)
      }

      return true
    } catch (error) {
      console.error("Error al verificar conexión:", error)
      setError("Error al verificar la conexión. Verifica tu conexión a internet.")
      return false
    } finally {
      setIsLoading(false)
    }
  }, [user])

  // Función para verificar si el perfil está completo - optimizada
  const checkProfileCompletion = useCallback((profile: any) => {
    if (!profile) return false

    // Verificar si los campos obligatorios están completos
    const hasName = !!profile.nombre_apoderado && profile.nombre_apoderado.trim() !== ""
    const hasPhone = !!profile.numero_telefono && profile.numero_telefono.trim() !== ""
    const hasChildren =
      Array.isArray(profile.hijos_info) &&
      profile.hijos_info.length > 0 &&
      profile.hijos_info.some((child: any) => !!child.nombre && child.nombre.trim() !== "")

    return hasName && hasPhone && hasChildren
  }, [])

  // Función para verificar el perfil del usuario - optimizada y con mejor manejo de errores
  const checkUserProfile = useCallback(
    async (userId: string) => {
      try {
        console.log("Verificando perfil para usuario:", userId)

        // Verificar si el cliente de Supabase está inicializado
        const supabase = getSupabase()
        if (!supabase) {
          console.error("Cliente de Supabase no inicializado al verificar perfil")
          return { profile: null, isComplete: false }
        }

        const profile = await getUserProfile(userId)

        // Actualizar estado del perfil
        setHasProfile(!!profile)

        if (profile) {
          // Verificar si el perfil está completo
          const profileComplete = checkProfileCompletion(profile)
          setIsProfileComplete(profileComplete)

          return { profile, isComplete: profileComplete }
        }

        setIsProfileComplete(false)
        return { profile: null, isComplete: false }
      } catch (error) {
        console.error("Error al verificar perfil:", error)

        // Importante: No bloquear la navegación por errores de perfil
        // Asumimos que el perfil existe pero no pudimos acceder a él
        setHasProfile(true)
        setIsProfileComplete(false)

        if (error instanceof Error) {
          setError(`Error al verificar perfil: ${error.message}`)
        } else {
          setError("Error desconocido al verificar perfil")
        }

        return { profile: null, isComplete: false }
      }
    },
    [checkProfileCompletion],
  )

  // Función para determinar la redirección después del login
  const getPostLoginRedirect = useCallback(
    (defaultRedirect = "/dashboard") => {
      // Si el perfil no está completo, redirigir a la página de perfil
      if (hasProfile && !isProfileComplete) {
        console.log("Perfil incompleto, redirigiendo a /perfil")
        return "/perfil"
      }

      // Si no hay perfil, redirigir a la página de perfil
      if (!hasProfile) {
        console.log("No hay perfil, redirigiendo a /perfil")
        return "/perfil"
      }

      // Obtener la redirección guardada o usar el valor predeterminado
      const savedRedirect = getRedirectUrl(defaultRedirect)
      console.log("Usando redirección guardada:", savedRedirect)
      return savedRedirect
    },
    [hasProfile, isProfileComplete],
  )

  // Procesar parámetros de redirección al cargar
  useEffect(() => {
    if (searchParams && searchParams.has("redirect")) {
      const redirectPath = searchParams.get("redirect")
      if (redirectPath) {
        console.log("Guardando redirección desde URL:", redirectPath)
        saveRedirectUrl(redirectPath)
      }
    }
  }, [searchParams])

  // Inicialización del contexto de autenticación
  useEffect(() => {
    if (isInitialized) return

    // Verificar si el cliente de Supabase está inicializado
    const supabase = getSupabase()
    if (!supabase) {
      setError("Cliente de Supabase no inicializado. Verifica las variables de entorno.")
      setIsLoading(false)
      setIsInitialized(true)
      return
    }

    const initAuth = async () => {
      setIsLoading(true)

      try {
        // Verificar conexión
        const isOnline = checkConnection()

        // Obtener sesión
        const { data, error } = await supabase.auth.getSession()

        if (error) {
          console.error("Error al obtener sesión:", error)
          throw error
        }

        setSession(data.session)
        setUser(data.session?.user || null)

        // Si hay usuario, verificar perfil
        if (data.session?.user) {
          try {
            await checkUserProfile(data.session.user.id)
          } catch (profileError) {
            console.error("Error al verificar perfil durante inicialización:", profileError)
            // No bloqueamos la inicialización por errores de perfil
          }
        }

        // Guardar sesión en localStorage para acceso offline
        if (data.session && isOnline) {
          try {
            localStorage.setItem("supabase_session", JSON.stringify(data.session))
          } catch (e) {
            console.warn("Error al guardar sesión en localStorage:", e)
          }
        }
      } catch (error) {
        console.error("Error al inicializar autenticación:", error)

        // Intentar recuperar sesión de localStorage en caso de error
        try {
          const storedSession = localStorage.getItem("supabase_session")
          if (storedSession) {
            const sessionData = JSON.parse(storedSession)
            setSession(sessionData)
            setUser(sessionData.user || null)

            if (sessionData.user) {
              try {
                await checkUserProfile(sessionData.user.id)
              } catch (profileError) {
                console.error("Error al verificar perfil desde localStorage:", profileError)
              }
            }
          }
        } catch (e) {
          console.warn("Error al recuperar sesión de localStorage:", e)
        }

        if (error instanceof Error) {
          setError(`Error al inicializar autenticación: ${error.message}`)
        } else {
          setError("Error desconocido al inicializar autenticación")
        }
      } finally {
        setIsLoading(false)
        setIsInitialized(true)
      }
    }

    initAuth()

    // Suscribirse a cambios en la autenticación
    const { data: authListener } = supabase.auth.onAuthStateChange(async (event, session) => {
      console.log("Evento de autenticación:", event, "Usuario:", session?.user?.email)

      setSession(session)
      setUser(session?.user || null)

      // Guardar o eliminar sesión de localStorage
      if (session) {
        try {
          localStorage.setItem("supabase_session", JSON.stringify(session))
        } catch (e) {
          console.warn("Error al guardar sesión en localStorage:", e)
        }

        // Verificar perfil si hay usuario
        if (session.user) {
          try {
            const profileResult = await checkUserProfile(session.user.id)

            // Mostrar toast de bienvenida en login exitoso
            if (event === "SIGNED_IN") {
              toast({
                title: "Inicio de sesión exitoso",
                description: `Bienvenido, ${session.user.email}`,
              })

              // Determinar la redirección basada en el estado del perfil
              const redirectTo = getPostLoginRedirect()
              console.log("AuthContext: Redirigiendo después de SIGNED_IN a:", redirectTo)

              // Usar setTimeout para asegurar que la redirección ocurra después de que React actualice el estado
              setTimeout(() => {
                router.push(redirectTo)
              }, 100)
            }
          } catch (profileError) {
            console.error("Error al verificar perfil después de cambio de autenticación:", profileError)
          }
        }
      } else {
        // Eliminar sesión de localStorage al cerrar sesión
        try {
          localStorage.removeItem("supabase_session")
        } catch (e) {
          console.warn("Error al eliminar sesión de localStorage:", e)
        }

        // Redirigir a login en cierre de sesión
        if (event === "SIGNED_OUT") {
          router.push("/login")
          toast({
            title: "Sesión cerrada",
            description: "Has cerrado sesión correctamente",
          })
        }
      }
    })

    return () => {
      authListener.subscription.unsubscribe()
    }
  }, [isInitialized, checkConnection, checkUserProfile, router, searchParams, getPostLoginRedirect])

  // Función para iniciar sesión
  const signIn = async (email: string, password: string, redirectTo?: string) => {
    const supabase = getSupabase()
    if (!supabase) {
      throw new Error("Cliente de Supabase no inicializado. Verifica las variables de entorno.")
    }

    // Verificar conexión a internet
    if (!checkConnection()) {
      throw new Error("No hay conexión a internet. Verifica tu conexión y vuelve a intentarlo.")
    }

    try {
      // Si hay redirección específica, guardarla
      if (redirectTo) {
        saveRedirectUrl(redirectTo)
      }

      console.log("Iniciando sesión con email:", email)
      const { data, error } = await supabase.auth.signInWithPassword({ email, password })

      if (error) {
        console.error("Error en signIn:", error)
        throw error
      }

      console.log("Inicio de sesión exitoso, usuario:", data.user?.email)

      // La redirección se maneja en el listener onAuthStateChange
      return data
    } catch (error) {
      console.error("Error en signIn:", error)

      if (error instanceof Error) {
        if (error.message.includes("Failed to fetch")) {
          throw new Error("No se pudo conectar con el servidor. Verifica tu conexión a internet.")
        }
        throw new Error(`Error al iniciar sesión: ${error.message}`)
      }

      throw new Error("Error desconocido al iniciar sesión")
    }
  }

  // Función para iniciar sesión con Google
  const handleSignInWithGoogle = async (redirectTo?: string) => {
    // Verificar conexión a internet
    if (!checkConnection()) {
      throw new Error("No hay conexión a internet. Verifica tu conexión y vuelve a intentarlo.")
    }

    try {
      // Si hay redirección específica, guardarla
      if (redirectTo) {
        saveRedirectUrl(redirectTo)
      }

      await supabaseSignInWithGoogle(redirectTo)
      // La redirección se maneja automáticamente por OAuth
    } catch (error) {
      console.error("Error en handleSignInWithGoogle:", error)

      if (error instanceof Error) {
        if (error.message.includes("Failed to fetch")) {
          throw new Error("No se pudo conectar con el servidor. Verifica tu conexión a internet.")
        }
        throw new Error(`Error al iniciar sesión con Google: ${error.message}`)
      }

      throw new Error("Error desconocido al iniciar sesión con Google")
    }
  }

  // Función para registrarse
  const signUp = async (email: string, password: string) => {
    const supabase = getSupabase()
    if (!supabase) {
      throw new Error("Cliente de Supabase no inicializado. Verifica las variables de entorno.")
    }

    // Verificar conexión a internet
    if (!checkConnection()) {
      throw new Error("No hay conexión a internet. Verifica tu conexión y vuelve a intentarlo.")
    }

    try {
      console.log("Registrando nuevo usuario:", email)
      const { data, error } = await supabase.auth.signUp({
        email,
        password,
        options: {
          emailRedirectTo: `${window.location.origin}/auth/callback`,
        },
      })

      if (error) {
        console.error("Error en signUp:", error)
        throw error
      }

      console.log("Registro exitoso, verificación de email enviada")
      return data
    } catch (error) {
      console.error("Error en signUp:", error)

      if (error instanceof Error) {
        if (error.message.includes("Failed to fetch")) {
          throw new Error("No se pudo conectar con el servidor. Verifica tu conexión a internet.")
        }
        throw new Error(`Error al registrarse: ${error.message}`)
      }

      throw new Error("Error desconocido al registrarse")
    }
  }

  // Función para cerrar sesión
  const signOut = async () => {
    const supabase = getSupabase()
    if (!supabase) {
      throw new Error("Cliente de Supabase no inicializado. Verifica las variables de entorno.")
    }

    try {
      console.log("Cerrando sesión...")

      // Eliminar sesión de localStorage y sessionStorage
      try {
        localStorage.removeItem("supabase_session")
        sessionStorage.removeItem("auth_redirect")

        // Limpiar cualquier otra información de perfil almacenada
        if (user?.id) {
          localStorage.removeItem(`profile_${user.id}`)
        }
      } catch (e) {
        console.warn("Error al eliminar datos de almacenamiento:", e)
      }

      // Primero actualizar el estado local
      setUser(null)
      setSession(null)
      setHasProfile(false)
      setIsProfileComplete(false)

      // Luego cerrar sesión en Supabase
      await supabase.auth.signOut()
      console.log("Sesión cerrada correctamente")

      // No es necesario redirigir aquí, se manejará en el componente
    } catch (error) {
      console.error("Error en signOut:", error)

      if (error instanceof Error) {
        throw new Error(`Error al cerrar sesión: ${error.message}`)
      }

      throw new Error("Error desconocido al cerrar sesión")
    }
  }

  const value = {
    user,
    session,
    isLoading,
    hasProfile,
    isProfileComplete,
    isOffline,
    signIn,
    signUp,
    signOut,
    signInWithGoogle: handleSignInWithGoogle,
    setHasProfile,
    setIsProfileComplete,
    retryConnection,
    error,
  }

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>
}

// Componente principal que envuelve el AuthProviderWithSearchParams con Suspense
export function AuthProvider({ children }: { children: ReactNode }) {
  return (
    <Suspense fallback={<div>Cargando...</div>}>
      <AuthProviderWithSearchParams>{children}</AuthProviderWithSearchParams>
    </Suspense>
  )
}

export function useAuth() {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error("useAuth debe ser usado dentro de un AuthProvider")
  }
  return context
}
