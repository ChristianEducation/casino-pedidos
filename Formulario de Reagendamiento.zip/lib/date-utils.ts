// Utilidades para manejo de fechas

/**
 * Obtiene el lunes de la semana actual
 */
export function getMondayOfCurrentWeek(): Date {
  const today = new Date()
  const day = today.getDay() // 0 = domingo, 1 = lunes, ..., 6 = sábado
  const diff = today.getDate() - day + (day === 0 ? -6 : 1) // Ajustar cuando es domingo

  const monday = new Date(today)
  monday.setDate(diff)
  monday.setHours(0, 0, 0, 0)

  return monday
}

/**
 * Obtiene el viernes de la semana actual
 */
export function getFridayOfCurrentWeek(): Date {
  const monday = getMondayOfCurrentWeek()
  const friday = new Date(monday)
  friday.setDate(monday.getDate() + 4)
  return friday
}

/**
 * Obtiene el lunes de la próxima semana
 */
export function getMondayOfNextWeek(): Date {
  const monday = getMondayOfCurrentWeek()
  const nextMonday = new Date(monday)
  nextMonday.setDate(monday.getDate() + 7)
  return nextMonday
}

/**
 * Obtiene el viernes de la próxima semana
 */
export function getFridayOfNextWeek(): Date {
  const nextMonday = getMondayOfNextWeek()
  const nextFriday = new Date(nextMonday)
  nextFriday.setDate(nextMonday.getDate() + 4)
  return nextFriday
}

/**
 * Formatea una fecha como YYYY-MM-DD
 */
export function formatDateToYYYYMMDD(date: Date): string {
  return date.toISOString().split("T")[0]
}

/**
 * Verifica si una fecha es un día hábil (lunes a viernes)
 */
export function isWeekday(date: Date): boolean {
  const day = date.getDay()
  return day >= 1 && day <= 5 // 1 = lunes, 5 = viernes
}

/**
 * Verifica si una fecha es futura
 */
export function isFutureDate(date: Date): boolean {
  const today = new Date()
  today.setHours(0, 0, 0, 0)
  return date >= today
}

/**
 * Verifica si una fecha es mañana o posterior
 */
export function isTomorrowOrLater(date: Date): boolean {
  const tomorrow = new Date()
  tomorrow.setDate(tomorrow.getDate() + 1)
  tomorrow.setHours(0, 0, 0, 0)
  return date >= tomorrow
}

/**
 * Obtiene el nombre del mes en español
 */
export function getMonthName(month: number): string {
  const meses = [
    "enero",
    "febrero",
    "marzo",
    "abril",
    "mayo",
    "junio",
    "julio",
    "agosto",
    "septiembre",
    "octubre",
    "noviembre",
    "diciembre",
  ]
  return meses[month]
}

/**
 * Obtiene el nombre del día de la semana en español
 */
export function getDayName(day: number): string {
  const dias = ["Domingo", "Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado"]
  return dias[day]
}

/**
 * Formatea una fecha como "Lunes 5 de mayo"
 */
export function formatDateToLongString(date: Date): string {
  const dayName = getDayName(date.getDay())
  const day = date.getDate()
  const monthName = getMonthName(date.getMonth())
  return `${dayName} ${day} de ${monthName}`
}

/**
 * Obtiene las semanas disponibles (actual y siguiente)
 * Excluye días que ya pasaron
 */
export function getSemanasDisponibles(): {
  id: string
  fechaInicio: string
  fechaFin: string
  label: string
  dias: { fecha: string; label: string; disponible: boolean }[]
}[] {
  const semanas = []

  // Fecha de mañana (para excluir el día de hoy)
  const tomorrow = new Date()
  tomorrow.setDate(tomorrow.getDate() + 1)
  tomorrow.setHours(0, 0, 0, 0)

  // Obtener fechas de la semana actual
  const mondayCurrent = getMondayOfCurrentWeek()
  const fridayCurrent = getFridayOfCurrentWeek()

  // Obtener fechas de la próxima semana
  const mondayNext = getMondayOfNextWeek()
  const fridayNext = getFridayOfNextWeek()

  // Formatear fechas
  const mondayCurrentStr = formatDateToYYYYMMDD(mondayCurrent)
  const fridayCurrentStr = formatDateToYYYYMMDD(fridayCurrent)
  const mondayNextStr = formatDateToYYYYMMDD(mondayNext)
  const fridayNextStr = formatDateToYYYYMMDD(fridayNext)

  // Generar días para la semana actual
  const diasSemanaActual = generateWeekDays(mondayCurrent, fridayCurrent, tomorrow)

  // Generar días para la próxima semana
  const diasProximaSemana = generateWeekDays(mondayNext, fridayNext, tomorrow)

  // Solo agregar la semana actual si tiene al menos un día disponible
  const diasDisponiblesSemanaActual = diasSemanaActual.filter((dia) => dia.disponible)
  if (diasDisponiblesSemanaActual.length > 0) {
    semanas.push({
      id: `${mondayCurrentStr}_${fridayCurrentStr}`,
      fechaInicio: mondayCurrentStr,
      fechaFin: fridayCurrentStr,
      label: `${mondayCurrent.getDate()} - ${fridayCurrent.getDate()} de ${getMonthName(mondayCurrent.getMonth())}`,
      dias: diasSemanaActual,
    })
  }

  // Agregar la próxima semana
  semanas.push({
    id: `${mondayNextStr}_${fridayNextStr}`,
    fechaInicio: mondayNextStr,
    fechaFin: fridayNextStr,
    label: `${mondayNext.getDate()} - ${fridayNext.getDate()} de ${getMonthName(mondayNext.getMonth())}`,
    dias: diasProximaSemana,
  })

  return semanas
}

/**
 * Genera los días de una semana
 */
function generateWeekDays(
  monday: Date,
  friday: Date,
  minDate: Date,
): { fecha: string; label: string; disponible: boolean }[] {
  const days = []
  const currentDate = new Date(monday)

  while (currentDate <= friday) {
    if (isWeekday(currentDate)) {
      const dateStr = formatDateToYYYYMMDD(currentDate)
      const isAvailable = currentDate >= minDate

      days.push({
        fecha: dateStr,
        label: formatDateToLongString(currentDate),
        disponible: isAvailable,
      })
    }

    currentDate.setDate(currentDate.getDate() + 1)
  }

  return days
}

/**
 * Formatea una fecha como "5 de mayo"
 */
export function formatDateShort(dateString: string): string {
  const date = new Date(dateString)
  const day = date.getDate()
  const month = getMonthName(date.getMonth())

  return `${day} de ${month}`
}

/**
 * Obtiene el nombre del día de la semana para una fecha dada
 */
export function getDayNameFromDate(dateString: string): string {
  const date = new Date(dateString)
  return getDayName(date.getDay())
}

/**
 * Calcula la fecha límite para modificar un pedido (9:00 AM del día anterior)
 */
export function getFechaLimiteModificacion(fechaEntrega: string): Date {
  const fecha = new Date(fechaEntrega)
  fecha.setDate(fecha.getDate() - 1)
  fecha.setHours(9, 0, 0, 0)

  return fecha
}

/**
 * Formatea la fecha límite para mostrar al usuario
 */
export function formatFechaLimite(fechaEntrega: string): string {
  const fechaLimite = getFechaLimiteModificacion(fechaEntrega)

  const options: Intl.DateTimeFormatOptions = {
    day: "numeric",
    month: "long",
    hour: "2-digit",
    minute: "2-digit",
    timeZone: "America/Santiago",
  }

  return fechaLimite.toLocaleDateString("es-ES", options)
}
