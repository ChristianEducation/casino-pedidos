"use client"

import { Calendar, Clock } from "lucide-react"
import type { Pedido } from "@/types"
import { formatDate, getDayName, formatFechaLimite } from "@/utils/format-date"

interface PedidoItemProps {
  pedido: Pedido
  onModificar: () => void
}

export default function PedidoItem({ pedido, onModificar }: PedidoItemProps) {
  // Usar fecha_entrega si está disponible, de lo contrario usar dia_entrega
  const fechaEntrega = pedido.fecha_entrega || pedido.dia_entrega

  console.log("Renderizando pedido:", pedido)
  console.log("Fecha de entrega utilizada:", fechaEntrega)

  return (
    <div className="p-5 border rounded-lg shadow-sm bg-white hover:shadow-md transition-shadow">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div>
          <h3 className="font-medium text-gray-800 text-lg">{pedido.nombre_estudiante}</h3>
          <div className="flex items-center mt-1 text-sm text-gray-600">
            <span className="font-medium mr-2">Código:</span>
            <span className="bg-gray-100 px-2 py-0.5 rounded">{pedido.codigo || "N/A"}</span>
          </div>
          {pedido.curso && (
            <p className="text-sm text-gray-600 mt-1">
              <span className="font-medium">Curso:</span> {pedido.curso}
            </p>
          )}
        </div>

        <div className="space-y-2">
          <div className="flex items-center text-sm">
            <Calendar className="h-4 w-4 mr-2 text-blue-600" />
            <div>
              <span className="font-medium">Fecha de entrega:</span>
              <div className="flex items-center">
                <span className="capitalize">{getDayName(new Date(fechaEntrega).getDay())}</span>
                <span className="mx-1">·</span>
                <span>{formatDate(fechaEntrega)}</span>
              </div>
            </div>
          </div>

          <div className="text-sm">
            <span className="font-medium">Tipo de pedido:</span> {pedido.tipo_pedido}
          </div>

          {pedido.opcion_menu && (
            <div className="text-sm bg-gray-50 p-2 rounded border border-gray-100">
              <span className="font-medium block text-gray-700">Menú seleccionado:</span>
              <span className="text-gray-800">{pedido.opcion_menu}</span>
            </div>
          )}

          {pedido.casino_entrega && (
            <div className="text-sm">
              <span className="font-medium">Casino:</span> {pedido.casino_entrega}
            </div>
          )}
        </div>

        <div className="flex flex-col justify-between">
          <div className="text-xs text-gray-500 mb-2 flex items-center">
            <Clock className="h-3 w-3 mr-1" />
            <span>Modificable hasta: {formatFechaLimite(fechaEntrega)}</span>
          </div>

          <button
            onClick={onModificar}
            className="px-4 py-2 text-white bg-blue-600 rounded-md hover:bg-blue-700 transition-colors w-full md:w-auto md:self-end flex items-center justify-center"
          >
            <span>Modificar pedido</span>
          </button>
        </div>
      </div>
    </div>
  )
}
