import { createClient } from "@supabase/supabase-js"
import type { ClienteRecurrente, DatosHijo, OpcionMenu } from "@/app/formulario/components/formulario-multi-step"

// Usar las variables de entorno proporcionadas
const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL || "https://koesipeybsasrknvgntg.supabase.co"
const supabaseAnonKey =
  process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY ||
  "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImtvZXNpcGV5YnNhc3JrbnZnbnRnIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDI5Mzg2MzEsImV4cCI6MjA1ODUxNDYzMX0.zLUMG6PRVJK1pEaAdO4pssFKGp8XMx9VAvwii4Xw1iU"

// Crear el cliente de Supabase
export const supabase = createClient(supabaseUrl, supabaseAnonKey)

// Interfaz para los menús de almuerzos de la base de datos
interface MenuAlmuerzoDb {
  id?: number
  dia: string
  codigo: string
  descripcion: string
  precio_estudiantes?: number // Hacerlo opcional y verificar nombres alternativos
  precio_estudiante?: number // Nombre alternativo
  precio?: number // Nombre alternativo más genérico
  precio_funcionario?: number
  precio_funcionarios?: number // Nombre alternativo
  fecha: string
  tipo_dia: string
}

// Interfaz para las colaciones de la base de datos
interface ColacionDb {
  id?: number
  codigo: string
  descripcion: string
  precio: number
}

// Función para extraer la letra del curso (ej: "2°MA" -> letra: "MA")
function extraerLetraDeCurso(cursoCompleto: string): { cursoSinLetra: string; letra: string } {
  // Buscar el primer caracter que no sea número, ° o espacio
  const match = cursoCompleto.match(/^([0-9°\s]+)(.+)$/)

  if (match && match.length >= 3) {
    return {
      cursoSinLetra: match[1].trim(),
      letra: match[2].trim(),
    }
  }

  // Si no se puede extraer, devolver valores por defecto
  return {
    cursoSinLetra: cursoCompleto,
    letra: "A",
  }
}

// Función para obtener datos de un cliente recurrente por sessionId (telegram_id)
export async function getClienteRecurrentePorSessionId(sessionId: string): Promise<ClienteRecurrente | null> {
  try {
    console.log("Buscando cliente recurrente con telegram_id:", sessionId)

    // Ahora sabemos el nombre exacto de la tabla
    const tableName = "clientes_recurrentes"

    // Consultar la tabla con el nombre correcto
    const { data, error } = await supabase.from(tableName).select("*").eq("telegram_id", sessionId).maybeSingle()

    if (error) {
      console.error(`Error en la consulta a la tabla ${tableName}:`, error)
      // Si el error es que no se encontró el registro, no es realmente un error
      if (error.code === "PGRST116" || error.message.includes("not found")) {
        console.log("No se encontró ningún cliente con telegram_id:", sessionId)
        return null
      }
      throw error
    }

    if (!data) {
      console.log("No se encontró ningún cliente con telegram_id:", sessionId)
      return null
    }

    console.log("Datos obtenidos de Supabase:", data)

    // Transformar los datos al formato que espera nuestra aplicación
    const clienteDB = data as any

    // Usar los nombres de columnas correctos
    const nombreApoderado = clienteDB.nombre_apoderado || ""
    const correoApoderado = clienteDB.correo_electronico || ""
    const telefono = clienteDB.telefono || ""

    // Manejo seguro del campo hijos_info
    let hijos: DatosHijo[] = []

    try {
      // Obtener el campo hijos_info
      const hijosInfoField = clienteDB.hijos_info || "[]"

      // Parsear el campo hijos_info si es una cadena JSON
      const hijosData = typeof hijosInfoField === "string" ? JSON.parse(hijosInfoField) : hijosInfoField

      // Verificar que sea un array
      if (Array.isArray(hijosData)) {
        hijos = hijosData.map((hijo: any, index: number) => {
          // Extraer la letra del curso
          const { cursoSinLetra, letra } = extraerLetraDeCurso(hijo.curso || "")

          return {
            // Generar un ID único si no existe
            id: hijo.id || `${sessionId}_hijo_${index}`,
            nombre: hijo.nombre || "",
            // Usar el curso sin la letra
            curso: cursoSinLetra,
            nivel: hijo.nivel || "Lower",
            // Usar la letra extraída
            letra: letra,
            // Inicializar menú y colaciones vacíos
            menu: {
              lunes: null,
              martes: null,
              miercoles: null,
              jueves: null,
              viernes: null,
            },
            colaciones: {
              lunes: null,
              martes: null,
              miercoles: null,
              jueves: null,
              viernes: null,
            },
          }
        })
      } else {
        console.warn("El campo hijos_info no es un array:", hijosData)
      }
    } catch (parseError) {
      console.error("Error al parsear el campo hijos_info:", parseError)
    }

    return {
      id: clienteDB.id || "",
      nombreApoderado,
      correoApoderado,
      telefono,
      hijos,
    }
  } catch (error) {
    console.error("Error al obtener cliente recurrente:", error)
    // En lugar de propagar el error, devolvemos null para que la aplicación continúe
    return null
  }
}

// Función para obtener los menús de almuerzos para una semana específica
export async function obtenerMenusAlmuerzosPorSemana(
  fechaInicio: string,
  fechaFin: string,
): Promise<{
  lunes: OpcionMenu[]
  martes: OpcionMenu[]
  miercoles: OpcionMenu[]
  jueves: OpcionMenu[]
  viernes: OpcionMenu[]
}> {
  try {
    console.log(`Obteniendo menús de almuerzos para la semana del ${fechaInicio} al ${fechaFin}`)

    // Consultar la tabla almuerzos_menu filtrando por el rango de fechas
    const { data, error } = await supabase
      .from("almuerzos_menu")
      .select("*")
      .gte("fecha", fechaInicio)
      .lte("fecha", fechaFin)
      .order("fecha", { ascending: true })
      .order("codigo", { ascending: true })

    if (error) {
      console.error("Error al obtener menús de almuerzos:", error)
      throw error
    }

    console.log(`Se encontraron ${data?.length || 0} registros de menús`)

    // Inicializar el objeto de menús por día
    const menusPorDia = {
      lunes: [] as OpcionMenu[],
      martes: [] as OpcionMenu[],
      miercoles: [] as OpcionMenu[],
      jueves: [] as OpcionMenu[],
      viernes: [] as OpcionMenu[],
    }

    // Si no hay datos, devolver el objeto vacío
    if (!data || data.length === 0) {
      return menusPorDia
    }

    // Agrupar los menús por día
    data.forEach((menu: MenuAlmuerzoDb) => {
      // Normalizar el nombre del día (convertir a minúsculas y quitar acentos)
      const diaNormalizado = menu.dia
        .toLowerCase()
        .normalize("NFD")
        .replace(/[\u0300-\u036f]/g, "")
        .trim()

      // Crear el objeto de menú con manejo de diferentes nombres de columnas para precios
      const opcionMenu: OpcionMenu = {
        id: menu.id?.toString() || menu.codigo,
        nombre: menu.codigo,
        descripcion: menu.descripcion,
        // Intentar diferentes nombres de columnas para el precio de estudiantes
        precio: menu.precio_estudiantes || menu.precio_estudiante || menu.precio || 5000,
        // Intentar diferentes nombres de columnas para el precio de funcionarios
        precioFuncionario:
          menu.precio_funcionario || menu.precio_funcionarios || (menu.precio ? menu.precio * 0.7 : 3500),
        fecha: menu.fecha,
        tipoDia: menu.tipo_dia,
      }

      // Agregar logging para depuración
      console.log("Datos de menú extraídos:", {
        dia: menu.dia,
        codigo: menu.codigo,
        precio_estudiantes: menu.precio_estudiantes,
        precio_estudiante: menu.precio_estudiante,
        precio: menu.precio,
        precio_funcionario: menu.precio_funcionario,
        precio_funcionarios: menu.precio_funcionarios,
        precio_final: opcionMenu.precio,
        precio_funcionario_final: opcionMenu.precioFuncionario,
      })

      // Agregar el menú al día correspondiente
      if (diaNormalizado === "lunes") {
        menusPorDia.lunes.push(opcionMenu)
      } else if (diaNormalizado === "martes") {
        menusPorDia.martes.push(opcionMenu)
      } else if (diaNormalizado === "miercoles" || diaNormalizado === "miércoles") {
        menusPorDia.miercoles.push(opcionMenu)
      } else if (diaNormalizado === "jueves") {
        menusPorDia.jueves.push(opcionMenu)
      } else if (diaNormalizado === "viernes") {
        menusPorDia.viernes.push(opcionMenu)
      }
    })

    return menusPorDia
  } catch (error) {
    console.error("Error al obtener menús de almuerzos por semana:", error)
    // En caso de error, devolver un objeto vacío
    return {
      lunes: [],
      martes: [],
      miercoles: [],
      jueves: [],
      viernes: [],
    }
  }
}

// Función para listar todas las tablas disponibles en la base de datos
export async function listarTablas(): Promise<string[]> {
  try {
    console.log("Listando todas las tablas disponibles en la base de datos")

    const { data, error } = await supabase.from("pg_catalog.pg_tables").select("tablename").eq("schemaname", "public")

    if (error) {
      console.error("Error al listar tablas:", error)
      return []
    }

    const tablas = data.map((row) => row.tablename)
    console.log("Tablas disponibles:", tablas)
    return tablas
  } catch (error) {
    console.error("Error al listar tablas:", error)
    return []
  }
}

// Modificar la función obtenerColaciones para intentar con diferentes nombres de tabla
export async function obtenerColaciones(): Promise<OpcionMenu[]> {
  try {
    console.log("Obteniendo colaciones desde Supabase")

    // Listar todas las tablas para depuración
    const tablas = await listarTablas()
    console.log("Tablas disponibles:", tablas)

    // Posibles nombres de tabla para colaciones
    const posiblesTablas = [
      "colacion_catalogo",
      "colaciones_catalogo",
      "colacio_catalogo",
      "colacion_catalogos",
      "colaciones",
      "colacion",
    ]

    let data = null
    const error = null
    let tablaEncontrada = null

    // Intentar con cada posible nombre de tabla
    for (const tabla of posiblesTablas) {
      console.log(`Intentando consultar tabla: ${tabla}`)

      const result = await supabase.from(tabla).select("*")

      if (!result.error) {
        console.log(`Tabla encontrada: ${tabla}`)
        data = result.data
        tablaEncontrada = tabla
        break
      } else {
        console.log(`Error al consultar tabla ${tabla}:`, result.error)
      }
    }

    // Si no se encontró ninguna tabla, intentar una consulta más genérica
    if (!data) {
      console.log(
        "No se encontró ninguna tabla de colaciones. Intentando buscar tablas que contengan 'colac' en el nombre",
      )

      const tablasColaciones = tablas.filter(
        (tabla) =>
          tabla.toLowerCase().includes("colac") ||
          tabla.toLowerCase().includes("colacion") ||
          tabla.toLowerCase().includes("catalogo"),
      )

      console.log("Tablas que podrían contener colaciones:", tablasColaciones)

      // Si encontramos alguna tabla que podría contener colaciones, intentamos consultarla
      if (tablasColaciones.length > 0) {
        for (const tabla of tablasColaciones) {
          console.log(`Intentando consultar tabla encontrada: ${tabla}`)

          const result = await supabase.from(tabla).select("*")

          if (!result.error) {
            console.log(`Tabla válida encontrada: ${tabla}`)
            data = result.data
            tablaEncontrada = tabla
            break
          }
        }
      }
    }

    // Si no se encontró ninguna tabla o no hay datos, devolver un array vacío
    if (!data || data.length === 0) {
      console.warn("No se encontraron colaciones en ninguna tabla")
      return []
    }

    console.log(`Se encontraron ${data.length} colaciones en la tabla ${tablaEncontrada}`)
    console.log("Muestra de datos:", data.slice(0, 2))

    // Intentar determinar los nombres de columnas correctos
    const primeraFila = data[0]
    const columnas = Object.keys(primeraFila)
    console.log("Columnas disponibles:", columnas)

    // Buscar columnas que podrían contener la descripción y el precio
    const columnaDescripcion =
      columnas.find(
        (col) =>
          col.toLowerCase().includes("desc") || col.toLowerCase() === "descripcion" || col.toLowerCase() === "nombre",
      ) || "descripcion"

    const columnaPrecio =
      columnas.find(
        (col) =>
          col.toLowerCase().includes("prec") ||
          col.toLowerCase() === "precio" ||
          col.toLowerCase() === "valor" ||
          col.toLowerCase() === "costo",
      ) || "precio"

    const columnaCodigo =
      columnas.find(
        (col) => col.toLowerCase().includes("cod") || col.toLowerCase() === "codigo" || col.toLowerCase() === "id",
      ) || "codigo"

    console.log(`Usando columnas: descripcion=${columnaDescripcion}, precio=${columnaPrecio}, codigo=${columnaCodigo}`)

    // Transformar los datos de colaciones al formato que espera nuestra aplicación
    const colaciones: OpcionMenu[] = data.map((colacion: any, index: number) => {
      // Crear un objeto de colación con los campos correctos
      const opcionColacion = {
        id: colacion.id?.toString() || colacion[columnaCodigo]?.toString() || index.toString(),
        nombre: colacion[columnaCodigo]?.toString() || `Colacion ${index + 1}`,
        descripcion: colacion[columnaDescripcion]?.toString() || "",
        precio: Number.parseFloat(colacion[columnaPrecio]) || 0,
      }

      console.log("Colación procesada:", opcionColacion)
      return opcionColacion
    })

    console.log(`Procesadas ${colaciones.length} colaciones`)

    return colaciones
  } catch (error) {
    console.error("Error al obtener colaciones:", error)
    // En caso de error, devolver un array vacío
    return []
  }
}

// Función para obtener los menús y colaciones desde Supabase
export async function obtenerMenusYColaciones(): Promise<{
  menus: {
    lunes: OpcionMenu[]
    martes: OpcionMenu[]
    miercoles: OpcionMenu[]
    jueves: OpcionMenu[]
    viernes: OpcionMenu[]
  }
  colaciones: OpcionMenu[]
}> {
  try {
    // Obtener la fecha actual
    const hoy = new Date()

    // Calcular el lunes de la semana actual
    const diaSemana = hoy.getDay() // 0 = domingo, 1 = lunes, ..., 6 = sábado
    const diasHastaLunes = diaSemana === 0 ? 6 : diaSemana - 1 // Si es domingo, restar 6 días, sino restar (diaSemana - 1)

    const lunes = new Date(hoy)
    lunes.setDate(hoy.getDate() - diasHastaLunes)
    lunes.setHours(0, 0, 0, 0)

    // Calcular el viernes de la semana actual
    const viernes = new Date(lunes)
    viernes.setDate(lunes.getDate() + 4)
    viernes.setHours(23, 59, 59, 999)

    // Formatear fechas para la consulta (YYYY-MM-DD)
    const fechaInicio = lunes.toISOString().split("T")[0]
    const fechaFin = viernes.toISOString().split("T")[0]

    // Obtener menús y colaciones en paralelo
    const [menus, colaciones] = await Promise.all([
      obtenerMenusAlmuerzosPorSemana(fechaInicio, fechaFin),
      obtenerColaciones(),
    ])

    return { menus, colaciones }
  } catch (error) {
    console.error("Error al obtener menús y colaciones:", error)
    // En caso de error, devolver objetos vacíos
    return {
      menus: {
        lunes: [],
        martes: [],
        miercoles: [],
        jueves: [],
        viernes: [],
      },
      colaciones: [],
    }
  }
}

// Función para obtener los menús y colaciones para una semana específica
export async function obtenerMenusYColacionesPorSemana(
  semanaId: string,
  fechaInicio: string,
  fechaFin: string,
): Promise<{
  menus: {
    lunes: OpcionMenu[]
    martes: OpcionMenu[]
    miercoles: OpcionMenu[]
    jueves: OpcionMenu[]
    viernes: OpcionMenu[]
  }
  colaciones: OpcionMenu[]
}> {
  try {
    // Obtener menús y colaciones en paralelo
    const [menus, colaciones] = await Promise.all([
      obtenerMenusAlmuerzosPorSemana(fechaInicio, fechaFin),
      obtenerColaciones(),
    ])

    return { menus, colaciones }
  } catch (error) {
    console.error(`Error al obtener menús y colaciones para la semana ${semanaId}:`, error)
    // En caso de error, devolver objetos vacíos
    return {
      menus: {
        lunes: [],
        martes: [],
        miercoles: [],
        jueves: [],
        viernes: [],
      },
      colaciones: [],
    }
  }
}

// Función para consultar la estructura de la tabla almuerzos_menu
export async function consultarEstructuraTablaAlmuerzos(): Promise<any> {
  try {
    console.log("Consultando estructura de la tabla almuerzos_menu")

    // Obtener una muestra de datos para ver la estructura
    const { data, error } = await supabase.from("almuerzos_menu").select("*").limit(1)

    if (error) {
      console.error("Error al consultar la tabla almuerzos_menu:", error)
      throw error
    }

    if (!data || data.length === 0) {
      console.log("No se encontraron datos en la tabla almuerzos_menu")
      return null
    }

    // Mostrar las columnas disponibles
    const columnas = Object.keys(data[0])
    console.log("Columnas disponibles en almuerzos_menu:", columnas)

    // Mostrar un ejemplo de datos
    console.log("Ejemplo de datos en almuerzos_menu:", data[0])

    return {
      columnas,
      ejemploDatos: data[0],
    }
  } catch (error) {
    console.error("Error al consultar estructura de la tabla:", error)
    return null
  }
}

// Función para consultar la estructura de la tabla colacio_catalogo
export async function consultarEstructuraTablaColaciones(): Promise<any> {
  try {
    console.log("Consultando estructura de tablas de colaciones")

    // Listar todas las tablas disponibles
    const tablas = await listarTablas()

    // Buscar tablas que podrían contener colaciones
    const tablasColaciones = tablas.filter(
      (tabla) =>
        tabla.toLowerCase().includes("colac") ||
        tabla.toLowerCase().includes("colacion") ||
        tabla.toLowerCase().includes("catalogo"),
    )

    console.log("Posibles tablas de colaciones:", tablasColaciones)

    // Si no encontramos ninguna tabla que podría contener colaciones, devolver null
    if (tablasColaciones.length === 0) {
      console.log("No se encontraron tablas que podrían contener colaciones")
      return null
    }

    // Intentar consultar cada tabla
    for (const tabla of tablasColaciones) {
      try {
        console.log(`Consultando tabla: ${tabla}`)

        const { data, error } = await supabase.from(tabla).select("*")

        if (error) {
          console.error(`Error al consultar la tabla ${tabla}:`, error)
          continue
        }

        if (!data || data.length === 0) {
          console.log(`No se encontraron datos en la tabla ${tabla}`)
          continue
        }

        // Mostrar las columnas disponibles
        const columnas = Object.keys(data[0])
        console.log(`Columnas disponibles en ${tabla}:`, columnas)

        // Mostrar todos los datos
        console.log(`Datos completos de ${tabla}:`, data)

        return {
          tabla,
          columnas,
          datos: data,
        }
      } catch (error) {
        console.error(`Error al consultar estructura de la tabla ${tabla}:`, error)
      }
    }

    console.log("No se pudo obtener la estructura de ninguna tabla de colaciones")
    return null
  } catch (error) {
    console.error("Error al consultar estructura de tablas de colaciones:", error)
    return null
  }
}
