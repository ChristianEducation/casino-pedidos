"use client"

import { Check } from "lucide-react"
import type { OpcionMenu } from "@/types"

interface SelectMenuOptionProps {
  options: OpcionMenu[]
  selectedOption: OpcionMenu | null
  onSelectOption: (option: OpcionMenu) => void
  isLoading?: boolean
  error?: string | null
  selectedDate?: string | null
}

export function SelectMenuOption({
  options,
  selectedOption,
  onSelectOption,
  isLoading = false,
  error = null,
  selectedDate = null,
}: SelectMenuOptionProps) {
  if (!selectedDate) {
    return <div className="p-3 border rounded-md bg-gray-50 text-gray-500">Seleccione una fecha primero</div>
  }

  if (isLoading) {
    return (
      <div className="p-3 border rounded-md bg-gray-50 text-gray-500 flex items-center justify-center">
        <div className="w-5 h-5 border-t-2 border-b-2 border-blue-500 rounded-full animate-spin mr-2"></div>
        <span>Cargando opciones de menú...</span>
      </div>
    )
  }

  if (error) {
    return <div className="p-3 border rounded-md bg-red-50 text-red-600">{error}</div>
  }

  if (options.length === 0) {
    return (
      <div className="p-3 border rounded-md bg-yellow-50 text-yellow-700">
        No hay opciones de menú disponibles para el día seleccionado
      </div>
    )
  }

  return (
    <div className="grid grid-cols-1 gap-3">
      {options.map((option) => (
        <button
          key={option.id}
          type="button"
          onClick={() => onSelectOption(option)}
          className={`p-4 border rounded-md text-left transition-colors ${
            selectedOption?.id === option.id
              ? "bg-blue-50 border-blue-300 ring-2 ring-blue-200"
              : "bg-white hover:bg-gray-50"
          }`}
        >
          <div className="flex justify-between">
            <span className="font-medium text-gray-800">{option.codigo}</span>
            {selectedOption?.id === option.id && <Check className="h-5 w-5 text-blue-600" />}
          </div>
          <p className="text-gray-700 mt-1">{option.descripcion}</p>
          {option.precio_estudiante && (
            <p className="text-sm text-gray-500 mt-1">Precio: ${option.precio_estudiante}</p>
          )}
        </button>
      ))}
    </div>
  )
}
