"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { useSession } from "@supabase/auth-helpers-react"
import { Loader2 } from "lucide-react"

interface AuthRedirectProps {
  redirectTo: string
  message?: string
}

export default function AuthRedirect({ redirectTo, message = "Redirigiendo..." }: AuthRedirectProps) {
  const session = useSession()
  const router = useRouter()
  const [attempts, setAttempts] = useState(0)

  useEffect(() => {
    // Si hay sesión, redirigir
    if (session) {
      console.log("AuthRedirect: Sesión detectada, redirigiendo a", redirectTo)

      // Intentar la redirección con un pequeño retraso
      const timer = setTimeout(() => {
        router.push(redirectTo)
      }, 100)

      return () => clearTimeout(timer)
    }

    // Si no hay sesión después de varios intentos, redirigir a login
    if (attempts > 5 && !session) {
      console.log("AuthRedirect: No se detectó sesión después de varios intentos, redirigiendo a login")
      router.push("/login")
    }

    // Incrementar contador de intentos
    const timer = setTimeout(() => {
      setAttempts((prev) => prev + 1)
    }, 500)

    return () => clearTimeout(timer)
  }, [session, redirectTo, router, attempts])

  return (
    <div className="flex flex-col items-center justify-center min-h-[60vh]">
      <Loader2 className="h-8 w-8 animate-spin mb-4 text-[#9ACA3C]" />
      <p className="text-gray-600">{message}</p>
      <p className="text-sm text-gray-400 mt-2">Espera un momento...</p>
    </div>
  )
}
