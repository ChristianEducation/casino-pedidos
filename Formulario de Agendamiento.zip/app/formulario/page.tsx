"use client"
import { useSearchParams } from "next/navigation"
import FormularioMultiStep from "./components/formulario-multi-step"
import Image from "next/image"

export default function FormularioPage() {
  const searchParams = useSearchParams()
  const sessionId = searchParams.get("sessionId")

  if (!sessionId) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-[#F5F8EE]">
        <div className="bg-white p-8 rounded-2xl shadow-md max-w-md w-full">
          <h1 className="text-xl font-bold text-[#1e1e2d] mb-4">Error</h1>
          <p className="text-gray-600">
            No se ha proporcionado un ID de sesión. Por favor, asegúrate de incluir un parámetro sessionId en la URL.
          </p>
        </div>
      </div>
    )
  }

  // Usar la variable de entorno para el webhook
  return (
    <div className="min-h-screen bg-[#F5F8EE] py-8 px-4 sm:px-6 lg:px-8">
      <div className="max-w-3xl mx-auto">
        <div className="flex justify-center mb-6">
          <Image
            src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-hEUqx9zYXyfZPOWIn8lYLlCCGRVblj.png"
            alt="Delicias Food Service Logo"
            width={200}
            height={80}
            className="h-auto"
          />
        </div>
        <FormularioMultiStep sessionId={sessionId} />
      </div>
    </div>
  )
}
