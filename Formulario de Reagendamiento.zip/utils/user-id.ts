/**
 * Utilidad para manejar la transición de sessionId a userId
 *
 * Este archivo contiene funciones que facilitarán la transición
 * de usar sessionId a usar userId como identificador principal.
 */

/**
 * Obtiene el identificador del usuario a partir del sessionId
 * En el futuro, esta función consultará una tabla de mapeo o realizará
 * otra lógica para obtener el userId correspondiente.
 */
export async function getUserIdFromSessionId(sessionId: string): Promise<string> {
  // Por ahora, simplemente devolvemos el sessionId
  // En el futuro, aquí se implementará la lógica para obtener el userId
  return sessionId
}

/**
 * Verifica si el identificador proporcionado corresponde a Christian Wevar
 * Esta es una función temporal para el ejemplo
 */
export function isChristianWevar(identifier: string): boolean {
  return identifier === "christian_wevar"
}

/**
 * Genera datos de ejemplo para Christian Wevar
 * Esta función es temporal para propósitos de demostración
 */
export function getChristianWevarExampleData() {
  return [
    {
      id: 1,
      session_id: "christian_wevar",
      estudiante: "Christian Wevar",
      fecha_entrega: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString().split("T")[0],
      tipo_pedido: "Menú Regular",
      opcion_menu: "Menú Regular",
      created_at: new Date().toISOString(),
    },
    {
      id: 2,
      session_id: "christian_wevar",
      estudiante: "Christian Wevar",
      fecha_entrega: new Date(Date.now() + 14 * 24 * 60 * 60 * 1000).toISOString().split("T")[0],
      tipo_pedido: "Menú Especial",
      opcion_menu: "Menú Sin Gluten",
      created_at: new Date().toISOString(),
    },
  ]
}
