"use client"

import { useState, useEffect, useRef } from "react"
import { useRouter } from "next/navigation"
import { SeleccionTipoUsuario } from "./pasos/seleccion-tipo-usuario"
import { DatosApoderado } from "./pasos/datos-apoderado"
import { DatosUsuario } from "./pasos/datos-usuario"
import { SeleccionMenu } from "./pasos/seleccion-menu"
import { SeleccionColaciones } from "./pasos/seleccion-colaciones"
import { MetodoPago } from "./pasos/metodo-pago"
import { ResumenEnvio } from "./pasos/resumen-envio"
import { ProgressBar } from "./ui/progress-bar"
import {
  getClienteRecurrentePorSessionId,
  obtenerMenusYColaciones,
  obtenerMenusYColacionesPorSemana,
  consultarEstructuraTablaAlmuerzos,
  consultarEstructuraTablaColaciones,
} from "@/lib/supabase"

interface FormularioMultiStepProps {
  sessionId: string
}

// Interfaz para las opciones de menú y colaciones
export interface OpcionMenu {
  id: string
  nombre: string
  descripcion: string
  precio: number
  precioFuncionario?: number // Precio especial para funcionarios
  fecha?: string // Fecha específica del menú
  tipoDia?: string // Tipo de día
}

// Interfaz para la semana
export interface Semana {
  id: string
  nombre: string
  fechaInicio: string // Fecha del lunes en formato YYYY-MM-DD
  fechaFin: string // Fecha del viernes en formato YYYY-MM-DD
}

// Interfaz para los datos de un hijo
export interface DatosHijo {
  id: string
  nombre: string
  curso: string
  nivel: string
  letra: string
  // Menú (almuerzos) por hijo
  menu: {
    lunes: string | null
    martes: string | null
    miercoles: string | null
    jueves: string | null
    viernes: string | null
  }
  // Colaciones por hijo
  colaciones: {
    lunes: string | null
    martes: string | null
    miercoles: string | null
    jueves: string | null
    viernes: string | null
  }
  // Indicador para saber si este hijo es el funcionario
  esFuncionario?: boolean
}

// Interfaz para los datos de un cliente recurrente
export interface ClienteRecurrente {
  id: string
  nombreApoderado: string
  correoApoderado: string
  telefono: string
  hijos: DatosHijo[]
}

// Actualizar la interfaz FormData para incluir los nuevos campos
export interface FormData {
  // Tipo de usuario
  tipoUsuario: "apoderado" | "funcionario" | null

  // Datos del apoderado/funcionario
  nombreApoderado: string
  correoApoderado: string
  telefono: string

  // Lugar de retiro (solo para funcionarios)
  lugarRetiro: "Casino1" | "Casino2" | "Sala" | null

  // Curso y letra para entrega en sala (solo cuando lugarRetiro es "Sala")
  cursoSala: "Prekinder" | "Kinder" | "1st Grade" | "2nd Grade" | null
  letraSala: "A" | "B" | "C" | "D" | null

  // Cliente recurrente
  esClienteRecurrente: boolean
  hijoSeleccionado: DatosHijo | null
  hijosDisponibles: DatosHijo[]

  // Hijos (incluye al funcionario como primer "hijo" si es funcionario)
  hijos: DatosHijo[]

  // Semana seleccionada
  semanaSeleccionada: Semana | null

  // Método de pago
  metodoPago: "Pendiente" | "espera_pago"
  comprobante: File | null

  // Observaciones
  observacionesAlmuerzos: string
  observacionesColaciones: string
}

// URL del webhook
const WEBHOOK_URL = process.env.NEXT_PUBLIC_WEBHOOK_URL || ""

// Función para obtener la fecha en formato legible
const formatearFecha = (fecha: string): string => {
  const opciones: Intl.DateTimeFormatOptions = { day: "numeric", month: "long" }
  return new Date(fecha).toLocaleDateString("es-ES", opciones)
}

// Función para generar semanas disponibles
function generarSemanas(): Semana[] {
  const semanas: Semana[] = []

  // Obtener la fecha actual
  const hoy = new Date()

  // Calcular el lunes de la semana actual
  const diaSemana = hoy.getDay() // 0 = domingo, 1 = lunes, ..., 6 = sábado
  const diasHastaLunes = diaSemana === 0 ? 6 : diaSemana - 1 // Si es domingo, restar 6 días, sino restar (diaSemana - 1)

  const lunesSemanaActual = new Date(hoy)
  lunesSemanaActual.setDate(hoy.getDate() - diasHastaLunes)
  lunesSemanaActual.setHours(0, 0, 0, 0)

  // Generar 4 semanas (actual + 3 siguientes)
  for (let i = 0; i < 4; i++) {
    const lunes = new Date(lunesSemanaActual)
    lunes.setDate(lunesSemanaActual.getDate() + i * 7)

    const viernes = new Date(lunes)
    viernes.setDate(lunes.getDate() + 4)

    // Formatear fechas (YYYY-MM-DD)
    const fechaInicio = lunes.toISOString().split("T")[0]
    const fechaFin = viernes.toISOString().split("T")[0]

    // Formatear nombre de la semana
    const nombreSemana =
      i === 0 ? "Semana Actual" : i === 1 ? "Próxima Semana" : `Semana del ${formatearFecha(fechaInicio)}`

    semanas.push({
      id: `semana_${i + 1}`,
      nombre: nombreSemana,
      fechaInicio,
      fechaFin,
    })
  }

  return semanas
}

export default function FormularioMultiStep({ sessionId }: FormularioMultiStepProps) {
  const router = useRouter()
  const [paso, setPaso] = useState(0) // Empezamos en 0 para la selección de tipo de usuario
  // Referencia al contenedor del formulario para hacer scroll
  const formularioRef = useRef<HTMLDivElement>(null)

  // Estado para controlar la carga de datos
  const [cargandoDatos, setCargandoDatos] = useState(false)
  const [errorCarga, setErrorCarga] = useState<string | null>(null)

  // Generar semanas disponibles
  const [semanas, setSemanas] = useState<Semana[]>(generarSemanas())

  // Estado para las opciones de menú y colaciones
  const [opcionesMenu, setOpcionesMenu] = useState<OpcionMenu[]>([])
  const [opcionesColaciones, setOpcionesColaciones] = useState<OpcionMenu[]>([])

  // Estado para los menús por día
  const [menusPorDia, setMenusPorDia] = useState<{
    lunes: OpcionMenu[]
    martes: OpcionMenu[]
    miercoles: OpcionMenu[]
    jueves: OpcionMenu[]
    viernes: OpcionMenu[]
  }>({
    lunes: [],
    martes: [],
    miercoles: [],
    jueves: [],
    viernes: [],
  })

  // Actualizar el estado inicial para incluir los nuevos campos
  const [formData, setFormData] = useState<FormData>({
    // Tipo de usuario
    tipoUsuario: null,

    // Datos del apoderado/funcionario
    nombreApoderado: "",
    correoApoderado: "",
    telefono: "",

    // Lugar de retiro (solo para funcionarios)
    lugarRetiro: null,

    // Curso y letra para entrega en sala
    cursoSala: null,
    letraSala: null,

    // Cliente recurrente
    esClienteRecurrente: false,
    hijoSeleccionado: null,
    hijosDisponibles: [],

    // Hijos (vacío inicialmente)
    hijos: [],

    // Semana seleccionada (por defecto la primera)
    semanaSeleccionada: semanas[0],

    // Método de pago
    metodoPago: "Pendiente",
    comprobante: null,

    // Observaciones
    observacionesAlmuerzos: "",
    observacionesColaciones: "",
  })

  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [success, setSuccess] = useState(false)
  const [debugInfo, setDebugInfo] = useState<string | null>(null)

  // Función para desplazar la vista hacia arriba
  const scrollToTop = () => {
    if (formularioRef.current) {
      // Desplazar suavemente hacia el inicio del formulario
      formularioRef.current.scrollIntoView({
        behavior: "smooth",
        block: "start",
      })
    }
  }

  // Cargar opciones de menú y colaciones desde Supabase
  useEffect(() => {
    const cargarOpcionesMenuYColaciones = async () => {
      try {
        setCargandoDatos(true)

        // Consultar la estructura de la tabla colaciones para depuración
        const estructuraColaciones = await consultarEstructuraTablaColaciones()
        console.log("Estructura de la tabla colaciones:", estructuraColaciones)

        // Cargar datos para la semana actual
        const { menus, colaciones } = await obtenerMenusYColaciones()

        // Guardar los menús por día
        setMenusPorDia(menus)

        // Guardar las colaciones
        if (colaciones && colaciones.length > 0) {
          console.log(`Se cargaron ${colaciones.length} colaciones:`, colaciones)
          setOpcionesColaciones(colaciones)
        } else {
          console.warn("No se encontraron colaciones en la base de datos")
          setOpcionesColaciones([])
        }
      } catch (err) {
        console.error("Error al cargar opciones de menú y colaciones:", err)
      } finally {
        setCargandoDatos(false)
      }
    }

    cargarOpcionesMenuYColaciones()
  }, [])

  // Efecto para depurar los precios de los menús
  useEffect(() => {
    // Depurar los precios de los menús
    console.log("Menús por día cargados:", menusPorDia)

    // Verificar los precios en cada día
    Object.entries(menusPorDia).forEach(([dia, opciones]) => {
      console.log(
        `Precios para ${dia}:`,
        opciones.map((op) => ({
          nombre: op.nombre,
          precio: op.precio,
          precioFuncionario: op.precioFuncionario,
        })),
      )
    })
  }, [menusPorDia])

  // Cargar menús específicos cuando cambia la semana seleccionada
  useEffect(() => {
    const cargarMenusPorSemana = async () => {
      if (!formData.semanaSeleccionada) return

      try {
        setCargandoDatos(true)

        const { menus } = await obtenerMenusYColacionesPorSemana(
          formData.semanaSeleccionada.id,
          formData.semanaSeleccionada.fechaInicio,
          formData.semanaSeleccionada.fechaFin,
        )

        setMenusPorDia(menus)
      } catch (err) {
        console.error("Error al cargar menús por semana:", err)
      } finally {
        setCargandoDatos(false)
      }
    }

    cargarMenusPorSemana()
  }, [formData.semanaSeleccionada])

  // Cargar datos del cliente recurrente desde Supabase
  useEffect(() => {
    const cargarDatosClienteRecurrente = async () => {
      if (!sessionId || !formData.tipoUsuario) return

      try {
        setCargandoDatos(true)
        setErrorCarga(null)

        console.log("Iniciando carga de datos para sessionId:", sessionId)

        // Consultar a Supabase para obtener los datos del cliente recurrente
        const clienteRecurrente = await getClienteRecurrentePorSessionId(sessionId)

        if (clienteRecurrente && clienteRecurrente.hijos && clienteRecurrente.hijos.length > 0) {
          console.log("Cliente recurrente encontrado:", clienteRecurrente)

          // Preparar los hijos con la estructura completa
          const hijosCompletos = clienteRecurrente.hijos.map((hijo) => ({
            ...hijo,
            menu: {
              lunes: null,
              martes: null,
              miercoles: null,
              jueves: null,
              viernes: null,
            },
            colaciones: {
              lunes: null,
              martes: null,
              miercoles: null,
              jueves: null,
              viernes: null,
            },
          }))

          // Actualizar el formulario con los datos del cliente recurrente
          setFormData((prevData) => ({
            ...prevData,
            nombreApoderado: clienteRecurrente.nombreApoderado || "",
            correoApoderado: clienteRecurrente.correoApoderado || "",
            telefono: clienteRecurrente.telefono || "",
            esClienteRecurrente: true,
            hijosDisponibles: hijosCompletos,
            hijos: hijosCompletos,
          }))

          // Avanzar al paso de selección de menú
          setPaso(2)
        } else {
          console.log("No se encontró cliente recurrente para el sessionId:", sessionId)
          // Si no hay cliente recurrente, simplemente continuamos con el formulario normal
          setFormData((prevData) => ({
            ...prevData,
            esClienteRecurrente: false,
          }))
          // Asegurarse de que comience en el paso de datos de apoderado
          setPaso(1)
        }
      } catch (err) {
        console.error("Error al cargar datos del cliente recurrente:", err)
        setErrorCarga(err instanceof Error ? err.message : "Error al cargar datos del cliente")
        // Si hay un error, continuamos con el formulario normal
        setFormData((prevData) => ({
          ...prevData,
          esClienteRecurrente: false,
        }))
        setPaso(1)
      } finally {
        setCargandoDatos(false)
      }
    }

    if (formData.tipoUsuario) {
      cargarDatosClienteRecurrente()
    }
  }, [sessionId, formData.tipoUsuario])

  // Efecto para desplazar hacia arriba cuando cambia el paso
  useEffect(() => {
    scrollToTop()
  }, [paso])

  // Función para seleccionar el tipo de usuario
  const seleccionarTipoUsuario = (tipo: "apoderado" | "funcionario") => {
    let hijos: DatosHijo[] = []

    if (tipo === "apoderado") {
      // Para apoderado, iniciar con un hijo normal
      hijos = [
        {
          id: `${tipo}_${Date.now()}`,
          nombre: "",
          curso: "1st Grade",
          nivel: "Lower",
          letra: "A",
          menu: {
            lunes: null,
            martes: null,
            miercoles: null,
            jueves: null,
            viernes: null,
          },
          colaciones: {
            lunes: null,
            martes: null,
            miercoles: null,
            jueves: null,
            viernes: null,
          },
        },
      ]
    } else {
      // Para funcionario, crear un "hijo" que represente al funcionario
      hijos = [
        {
          id: `funcionario_${Date.now()}`,
          nombre: "Tú", // Nombre por defecto, se actualizará con el nombre real
          curso: "Funcionario",
          nivel: "Funcionario",
          letra: "",
          menu: {
            lunes: null,
            martes: null,
            miercoles: null,
            jueves: null,
            viernes: null,
          },
          colaciones: {
            lunes: null,
            martes: null,
            miercoles: null,
            jueves: null,
            viernes: null,
          },
          esFuncionario: true, // Marcar como funcionario
        },
      ]
    }

    // Actualizar el formulario con el tipo de usuario y los hijos iniciales
    actualizarFormData({
      tipoUsuario: tipo,
      hijos: hijos,
    })

    setPaso(1)
  }

  // Consultar la estructura de la tabla almuerzos_menu al cargar el componente
  useEffect(() => {
    const verificarEstructuraTabla = async () => {
      try {
        const estructura = await consultarEstructuraTablaAlmuerzos()
        console.log("Estructura de la tabla almuerzos_menu:", estructura)
      } catch (error) {
        console.error("Error al verificar estructura de la tabla:", error)
      }
    }

    verificarEstructuraTabla()
  }, [])

  // Efecto para actualizar el nombre del funcionario cuando se completan los datos del apoderado
  useEffect(() => {
    if (formData.tipoUsuario === "funcionario" && formData.nombreApoderado && formData.hijos.length > 0) {
      // Actualizar el nombre del funcionario en el primer hijo
      const hijosFuncionario = formData.hijos.map((hijo, index) => {
        if (index === 0 && hijo.esFuncionario) {
          return {
            ...hijo,
            nombre: formData.nombreApoderado, // Actualizar con el nombre real del funcionario
          }
        }
        return hijo
      })

      // Solo actualizar si hay cambios
      if (hijosFuncionario[0]?.nombre !== formData.hijos[0]?.nombre) {
        setFormData((prevData) => ({
          ...prevData,
          hijos: hijosFuncionario,
        }))
      }
    }
  }, [formData.tipoUsuario, formData.nombreApoderado, formData.hijos])

  const siguientePaso = () => {
    // Si es funcionario y no hay hijos, asegurarse de que haya al menos un hijo que represente al funcionario
    if (paso === 1 && formData.tipoUsuario === "funcionario" && formData.hijos.length === 0) {
      // Crear un "hijo" que represente al funcionario
      const funcionarioComoHijo: DatosHijo = {
        id: `funcionario_${Date.now()}`,
        nombre: formData.nombreApoderado || "Funcionario",
        curso: "Funcionario",
        nivel: "Funcionario",
        letra: "",
        menu: {
          lunes: null,
          martes: null,
          miercoles: null,
          jueves: null,
          viernes: null,
        },
        colaciones: {
          lunes: null,
          martes: null,
          miercoles: null,
          jueves: null,
          viernes: null,
        },
        esFuncionario: true,
      }

      setFormData((prevData) => ({
        ...prevData,
        hijos: [funcionarioComoHijo],
      }))
    }

    setPaso((p) => p + 1)
  }

  const anteriorPaso = () => {
    setPaso((p) => Math.max(p - 1, 0))
  }

  const actualizarFormData = (data: Partial<FormData>) => {
    setFormData((prevData) => ({
      ...prevData,
      ...data,
    }))
  }

  // Función para seleccionar un hijo
  const seleccionarHijo = (hijo: DatosHijo) => {
    actualizarFormData({
      hijoSeleccionado: hijo,
    })
  }

  const enviarFormulario = async () => {
    try {
      setLoading(true)
      setError(null)
      setDebugInfo(null)

      // Función para generar la lista de pedidos por hijo
      const generarPedidosPorHijo = () => {
        return formData.hijos.map((hijo, index) => {
          const esFuncionarioPrincipal = hijo.esFuncionario || (formData.tipoUsuario === "funcionario" && index === 0)

          // Función para generar la lista de días seleccionados con descripciones
          const generarListaDias = (
            selecciones: Record<string, string | null>,
            tipo: string,
            obtenerDescripcion: (dia: string, nombre: string) => string,
            obtenerPrecio: (dia: string, nombre: string) => number,
          ) => {
            const diasSeleccionados = Object.entries(selecciones)
              .filter(([_, opcion]) => opcion !== null)
              .map(([dia, opcion]) => {
                const nombreDia =
                  dia === "lunes"
                    ? "Lunes"
                    : dia === "martes"
                      ? "Martes"
                      : dia === "miercoles"
                        ? "Miércoles"
                        : dia === "jueves"
                          ? "Jueves"
                          : "Viernes"

                // Incluir la descripción y precio si están disponibles
                const descripcion = opcion ? obtenerDescripcion(dia, opcion) : ""
                const precio = opcion ? obtenerPrecio(dia, opcion) : 0
                const textoOpcion = `${opcion} (${descripcion}) - $${precio}`

                return `- ${nombreDia}: ${textoOpcion}`
              })

            if (diasSeleccionados.length === 0) {
              return `${tipo}:\nNo se ha seleccionado ninguno`
            }

            return `${tipo}:\n${diasSeleccionados.join("\n")}`
          }

          // Función para obtener la descripción de una opción de menú
          const obtenerDescripcionMenu = (dia: string, nombre: string): string => {
            const diaKey = dia as keyof typeof menusPorDia
            const opcion = menusPorDia[diaKey].find((op) => op.nombre === nombre)
            return opcion ? opcion.descripcion : ""
          }

          // Función para obtener el precio de una opción de menú
          const obtenerPrecioMenu = (dia: string, nombre: string): number => {
            const diaKey = dia as keyof typeof menusPorDia
            const opcion = menusPorDia[diaKey].find((op) => op.nombre === nombre)
            if (!opcion) return 0

            // Si es funcionario y es para sí mismo, aplicar precio especial
            if (esFuncionarioPrincipal && opcion.precioFuncionario !== undefined) {
              return opcion.precioFuncionario
            }

            return opcion.precio
          }

          // Función para obtener la descripción de una opción de colación
          const obtenerDescripcionColacion = (dia: string, nombre: string): string => {
            const opcion = opcionesColaciones.find((op) => op.nombre === nombre)
            return opcion ? opcion.descripcion : ""
          }

          // Función para obtener el precio de una opción de colación
          const obtenerPrecioColacion = (dia: string, nombre: string): number => {
            const opcion = opcionesColaciones.find((op) => op.nombre === nombre)
            return opcion ? opcion.precio : 0
          }

          // Calcular el total para este hijo
          const calcularTotal = () => {
            let total = 0

            // Sumar almuerzos
            Object.entries(hijo.menu).forEach(([dia, opcion]) => {
              if (opcion) {
                total += obtenerPrecioMenu(dia, opcion)
              }
            })

            // Sumar colaciones
            Object.entries(hijo.colaciones).forEach(([dia, opcion]) => {
              if (opcion) {
                total += obtenerPrecioColacion(dia, opcion)
              }
            })

            return total
          }

          return {
            nombre: hijo.nombre,
            curso: `${hijo.curso} ${hijo.letra}`,
            nivel: hijo.nivel,
            esFuncionario: esFuncionarioPrincipal,
            almuerzos: generarListaDias(hijo.menu, "Almuerzos", obtenerDescripcionMenu, obtenerPrecioMenu),
            colaciones: generarListaDias(
              hijo.colaciones,
              "Colaciones",
              obtenerDescripcionColacion,
              obtenerPrecioColacion,
            ),
            total: calcularTotal(),
          }
        })
      }

      // Información de la semana seleccionada
      const infoSemana = formData.semanaSeleccionada
        ? `Semana: ${formData.semanaSeleccionada.nombre} (${formatearFecha(formData.semanaSeleccionada.fechaInicio)} al ${formatearFecha(formData.semanaSeleccionada.fechaFin)})`
        : "Semana: No seleccionada"

      // Calcular el total general
      const totalGeneral = formData.hijos.reduce((total, hijo) => {
        const esFuncionarioPrincipal =
          hijo.esFuncionario || (formData.tipoUsuario === "funcionario" && hijo.curso === "Funcionario")

        // Función para obtener el precio de una opción de menú
        const obtenerPrecioMenu = (dia: string, nombre: string): number => {
          const diaKey = dia as keyof typeof menusPorDia
          const opcion = menusPorDia[diaKey].find((op) => op.nombre === nombre)
          if (!opcion) return 0

          // Si es funcionario y es para sí mismo, aplicar precio especial
          if (esFuncionarioPrincipal && opcion.precioFuncionario !== undefined) {
            return opcion.precioFuncionario
          }

          return opcion.precio
        }

        // Función para obtener el precio de una opción de colación
        const obtenerPrecioColacion = (dia: string, nombre: string): number => {
          const opcion = opcionesColaciones.find((op) => op.nombre === nombre)
          return opcion ? opcion.precio : 0
        }

        let subtotal = 0

        // Sumar almuerzos
        Object.entries(hijo.menu).forEach(([dia, opcion]) => {
          if (opcion) {
            subtotal += obtenerPrecioMenu(dia, opcion)
          }
        })

        // Sumar colaciones
        Object.entries(hijo.colaciones).forEach(([dia, opcion]) => {
          if (opcion) {
            subtotal += obtenerPrecioColacion(dia, opcion)
          }
        })

        return total + subtotal
      }, 0)

      // Información adicional sobre el lugar de retiro para funcionarios
      let infoLugarRetiro = ""
      if (formData.tipoUsuario === "funcionario" && formData.lugarRetiro) {
        infoLugarRetiro = `- Lugar de retiro: ${formData.lugarRetiro}`

        // Si el lugar de retiro es "Sala", incluir información del curso y letra
        if (formData.lugarRetiro === "Sala" && formData.cursoSala && formData.letraSala) {
          infoLugarRetiro += ` (${formData.cursoSala} ${formData.letraSala})`
        }
      }

      // Construir el mensaje de resumen
      const mensaje = `
Tipo de usuario: ${formData.tipoUsuario}

Datos del ${formData.tipoUsuario === "funcionario" ? "Funcionario" : "Apoderado"}:
- Nombre: ${formData.nombreApoderado}
- Correo: ${formData.correoApoderado}
- Teléfono: ${formData.telefono}
${infoLugarRetiro}

${infoSemana}

${generarPedidosPorHijo()
  .map(
    (pedido, index) => `
=== Pedido ${index + 1} ===
${pedido.esFuncionario ? "Funcionario" : "Alumno"}: ${pedido.nombre}
${
  !pedido.esFuncionario
    ? `Curso: ${pedido.curso}
Nivel: ${pedido.nivel}`
    : ""
}

${pedido.almuerzos}

${pedido.colaciones}

Subtotal: $${pedido.total}
`,
  )
  .join("\n")}

TOTAL A PAGAR: $${totalGeneral}

Observaciones sobre almuerzos:
${formData.observacionesAlmuerzos || "No hay observaciones"}

Observaciones sobre colaciones:
${formData.observacionesColaciones || "No hay observaciones"}

Modo de pago: ${formData.metodoPago === "Pendiente" ? "Pagaré después" : "Pagar ahora"}
`

      // Datos a enviar
      const orderData = {
        sessionId,
        phone_id: formData.telefono, // Usar el número de teléfono ingresado por el usuario
        type: "order",
        message: mensaje,
        payment_mode: formData.metodoPago,
        tipo_usuario: formData.tipoUsuario,
        lugar_retiro: formData.lugarRetiro, // Añadir lugar de retiro
        curso_sala: formData.cursoSala, // Añadir curso para entrega en sala
        letra_sala: formData.letraSala, // Añadir letra para entrega en sala
        total: totalGeneral,
        pedidos: generarPedidosPorHijo(),
        observaciones_almuerzos: formData.observacionesAlmuerzos,
        observaciones_colaciones: formData.observacionesColaciones,
        // Incluir información del cliente recurrente si aplica
        cliente_recurrente: formData.esClienteRecurrente
          ? {
              id: formData.hijoSeleccionado?.id || "",
              nombre_apoderado: formData.nombreApoderado,
              correo_apoderado: formData.correoApoderado,
              telefono: formData.telefono,
            }
          : null,
      }

      // Información de depuración
      setDebugInfo(`Intentando enviar a: ${WEBHOOK_URL}
Datos: ${JSON.stringify(orderData, null, 2)}`)

      // Enviar los datos al webhook
      try {
        const orderResponse = await fetch(WEBHOOK_URL, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Accept: "application/json",
          },
          mode: "cors",
          body: JSON.stringify(orderData),
        })

        if (!orderResponse.ok) {
          const errorText = await orderResponse.text()
          console.error("Error en la respuesta del servidor:", errorText)
          throw new Error(`Error del servidor: ${orderResponse.status} ${orderResponse.statusText}`)
        }

        console.log("Pedido enviado correctamente")

        // Si es espera_pago, redirigir a la página de subir comprobante
        if (formData.metodoPago === "espera_pago") {
          // Guardar los datos del formulario en sessionStorage para recuperarlos en la página de comprobante
          sessionStorage.setItem("formData", JSON.stringify(formData))
          sessionStorage.setItem("sessionId", sessionId)
          router.push(`/formulario/comprobante?sessionId=${sessionId}`)
          return
        }

        setSuccess(true)
      } catch (fetchError) {
        console.error("Error al enviar el pedido:", fetchError)
        throw new Error(
          `Error al enviar el pedido: ${fetchError instanceof Error ? fetchError.message : "Error de red"}`,
        )
      }
    } catch (err) {
      console.error("Error al enviar formulario:", err)
      setError(err instanceof Error ? err.message : "Error al enviar el formulario")
    } finally {
      setLoading(false)
    }
  }

  const renderPaso = () => {
    // Si estamos cargando datos, mostrar indicador de carga
    if (cargandoDatos) {
      return (
        <div className="flex flex-col items-center justify-center py-12">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mb-4"></div>
          <p className="text-gray-600">Cargando datos...</p>
        </div>
      )
    }

    // Si hay un error al cargar datos, mostrar mensaje de error
    if (errorCarga) {
      return (
        <div className="bg-red-50 border border-red-200 rounded-xl p-6 mb-6">
          <h3 className="text-lg font-medium text-red-800 mb-2">Error al cargar datos</h3>
          <p className="text-red-600">{errorCarga}</p>
          <button
            onClick={() => window.location.reload()}
            className="mt-4 bg-red-600 text-white py-2 px-4 rounded-lg hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-red-500 focus:ring-offset-2 transition-all duration-200"
          >
            Reintentar
          </button>
        </div>
      )
    }

    // Renderizar el paso correspondiente
    switch (paso) {
      case 0:
        return <SeleccionTipoUsuario seleccionarTipoUsuario={seleccionarTipoUsuario} />
      case 1:
        return (
          <DatosApoderado formData={formData} actualizarFormData={actualizarFormData} siguientePaso={siguientePaso} />
        )
      case 2:
        return (
          <DatosUsuario
            formData={formData}
            actualizarFormData={actualizarFormData}
            siguientePaso={siguientePaso}
            anteriorPaso={anteriorPaso}
          />
        )
      case 3:
        return (
          <SeleccionMenu
            formData={formData}
            actualizarFormData={actualizarFormData}
            siguientePaso={siguientePaso}
            anteriorPaso={anteriorPaso}
            semanas={semanas}
            opcionesMenu={opcionesMenu}
          />
        )
      case 4:
        return (
          <SeleccionColaciones
            formData={formData}
            actualizarFormData={actualizarFormData}
            siguientePaso={siguientePaso}
            anteriorPaso={anteriorPaso}
            opcionesColaciones={opcionesColaciones}
          />
        )
      case 5:
        return (
          <MetodoPago
            formData={formData}
            actualizarFormData={actualizarFormData}
            siguientePaso={siguientePaso}
            anteriorPaso={anteriorPaso}
          />
        )
      case 6:
        return (
          <ResumenEnvio
            formData={formData}
            anteriorPaso={anteriorPaso}
            enviarFormulario={enviarFormulario}
            loading={loading}
            error={error}
            success={success}
            debugInfo={debugInfo}
            opcionesMenu={opcionesMenu}
            opcionesColaciones={opcionesColaciones}
            menusPorDia={menusPorDia}
          />
        )
      default:
        return null
    }
  }

  // Determinar el número total de pasos
  const totalPasos = 7 // Incluye el paso 0 (selección de tipo de usuario)

  return (
    <div ref={formularioRef} className="bg-white rounded-2xl shadow-md overflow-hidden transition-all duration-300">
      <div className="p-6">
        <h1 className="text-2xl font-bold text-[#1e1e2d] mb-6">Formulario de Pedido</h1>
        {paso > 0 && <ProgressBar paso={paso} totalPasos={totalPasos - 1} tipoUsuario={formData.tipoUsuario} />}
        <div className="mt-8">{renderPaso()}</div>
      </div>
    </div>
  )
}
