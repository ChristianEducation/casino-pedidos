import { NextResponse } from "next/server"
import type { WebhookPayload } from "@/types"

const N8N_WEBHOOK_URL = process.env.N8N_WEBHOOK_URL || "https://n8n.example.com/webhook/registro-perfil"

export async function POST(request: Request) {
  try {
    const data = await request.json()

    // Validar datos recibidos
    if (!data.user_id || !data.nombre_completo || !data.correo_electronico) {
      return NextResponse.json({ error: "Datos incompletos para el registro de perfil" }, { status: 400 })
    }

    // Preparar payload para n8n
    const payload: WebhookPayload = {
      tipo: "registro_perfil",
      datos: {
        user_id: data.user_id,
        nombre_completo: data.nombre_completo,
        correo_electronico: data.correo_electronico,
        telefono: data.telefono,
        tipo_usuario: data.tipo_usuario,
        hijos_info: data.hijos_info || [],
        timestamp: new Date().toISOString(),
      },
    }

    // Enviar datos a n8n
    const response = await fetch(N8N_WEBHOOK_URL, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(payload),
    })

    if (!response.ok) {
      throw new Error(`Error al enviar datos a n8n: ${response.statusText}`)
    }

    const result = await response.json()

    return NextResponse.json({
      success: true,
      message: "Perfil registrado correctamente",
      data: result,
    })
  } catch (error) {
    console.error("Error en API de registro de perfil:", error)
    return NextResponse.json({ error: "Error al procesar el registro de perfil" }, { status: 500 })
  }
}
