"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Bug, X, AlertCircle, CheckCircle, RefreshCw, Eye, EyeOff } from "lucide-react"
import { useSession, useSupabaseClient } from "@supabase/auth-helpers-react"

export default function DebugTools() {
  const [isOpen, setIsOpen] = useState(false)
  const [isVisible, setIsVisible] = useState(false)
  const [activeTab, setActiveTab] = useState("connection")
  const [showValues, setShowValues] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const session = useSession()
  const supabase = useSupabaseClient()
  const [error, setError] = useState<string | null>(null)

  // Diagnósticos de conexión
  const [diagnostics, setDiagnostics] = useState({
    supabaseConnection: false,
    authInitialized: false,
    networkStatus: navigator.onLine,
    routerWorking: false,
    storageAccess: false,
    environmentVars: false,
  })

  // Datos de perfil para la pestaña de perfil
  const [profileData, setProfileData] = useState<any>(null)
  const [sessionData, setSessionData] = useState<any>(null)

  // Mostrar/ocultar con combinación de teclas (Ctrl+Shift+D)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.ctrlKey && e.shiftKey && e.key === "D") {
        e.preventDefault()
        setIsVisible((prev) => !prev)
      }
    }

    window.addEventListener("keydown", handleKeyDown)
    return () => window.removeEventListener("keydown", handleKeyDown)
  }, [])

  // Ejecutar diagnósticos cuando se abre
  useEffect(() => {
    if (isOpen) {
      runDiagnostics()
    }
  }, [isOpen])

  // Función para ejecutar diagnósticos
  const runDiagnostics = async () => {
    setIsLoading(true)

    try {
      // Verificar conexión a internet
      const networkStatus = navigator.onLine

      // Verificar variables de entorno
      const environmentVars = !!(process.env.NEXT_PUBLIC_SUPABASE_URL && process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY)

      // Verificar conexión a Supabase
      let supabaseConnection = false
      let authInitialized = false

      if (supabase) {
        try {
          // Intentar una operación simple para verificar la conexión
          const { error } = await supabase.from("clientes_recurrentes").select("count", { count: "exact", head: true })
          supabaseConnection = !error

          // Verificar inicialización de autenticación
          const { data } = await supabase.auth.getSession()
          authInitialized = !!data
        } catch (e) {
          console.error("Error al verificar conexión con Supabase:", e)
        }
      }

      // Verificar acceso al almacenamiento
      let storageAccess = false
      try {
        localStorage.setItem("test_storage", "test")
        storageAccess = localStorage.getItem("test_storage") === "test"
        localStorage.removeItem("test_storage")
      } catch (e) {
        console.error("Error al verificar acceso al almacenamiento:", e)
      }

      // Verificar si el router está funcionando
      const routerWorking = typeof window !== "undefined" && !!window.history

      setDiagnostics({
        supabaseConnection,
        authInitialized,
        networkStatus,
        routerWorking,
        storageAccess,
        environmentVars,
      })
    } catch (error) {
      console.error("Error al ejecutar diagnósticos:", error)
    } finally {
      setIsLoading(false)
    }
  }

  // Verificar perfil
  const checkProfile = async () => {
    if (!session?.user?.id) return

    try {
      const { data, error } = await supabase
        .from("clientes_recurrentes")
        .select("*")
        .eq("telegram_id", session.user.id)
        .single()

      setProfileData({ data, error })
    } catch (err) {
      setProfileData({ error: err })
    }
  }

  // Verificar sesión
  const checkSession = async () => {
    try {
      const { data, error } = await supabase.auth.getSession()
      setSessionData({ data, error })
    } catch (err) {
      setSessionData({ error: err })
    }
  }

  // Variables de entorno
  const envVars = {
    NEXT_PUBLIC_SUPABASE_URL: process.env.NEXT_PUBLIC_SUPABASE_URL || "",
    NEXT_PUBLIC_SUPABASE_ANON_KEY: process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || "",
    NEXT_PUBLIC_N8N_WEBHOOK_URL: process.env.NEXT_PUBLIC_N8N_WEBHOOK_URL || "",
  }

  const maskValue = (value: string) => {
    if (!value) return "No definido"
    if (showValues) return value
    if (value.length <= 8) return "********"
    return value.substring(0, 4) + "..." + value.substring(value.length - 4)
  }

  // Si no está visible, mostrar solo un pequeño indicador
  if (!isVisible) {
    return (
      <div className="fixed bottom-2 left-2 z-50 opacity-30 hover:opacity-100 transition-opacity">
        <Button
          onClick={() => setIsVisible(true)}
          variant="ghost"
          size="sm"
          className="w-8 h-8 p-0 rounded-full bg-gray-200 text-gray-500"
          title="Herramientas de depuración (Ctrl+Shift+D)"
        >
          <Bug className="h-4 w-4" />
          <span className="sr-only">Depuración</span>
        </Button>
      </div>
    )
  }

  // Si está visible pero cerrado, mostrar botón para abrir
  if (!isOpen) {
    return (
      <div className="fixed bottom-2 left-2 z-50">
        <Button
          onClick={() => setIsOpen(true)}
          variant="outline"
          size="sm"
          className="flex items-center gap-2 bg-gray-100 text-gray-700 border-gray-300"
        >
          <Bug className="h-4 w-4" />
          <span>Depuración</span>
        </Button>
      </div>
    )
  }

  // Panel completo de depuración
  return (
    <div className="fixed bottom-2 left-2 z-50 w-80 md:w-96">
      <Card className="shadow-xl border-gray-300">
        <CardHeader className="bg-gray-50 pb-2">
          <div className="flex justify-between items-center">
            <CardTitle className="text-lg text-gray-800 flex items-center gap-2">
              <Bug className="h-5 w-5" />
              Herramientas de Depuración
            </CardTitle>
            <div className="flex gap-1">
              <Button variant="ghost" size="sm" className="h-7 w-7 p-0" onClick={() => setIsOpen(false)}>
                <X className="h-4 w-4" />
              </Button>
            </div>
          </div>
          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="grid grid-cols-3 w-full">
              <TabsTrigger value="connection">Conexión</TabsTrigger>
              <TabsTrigger value="env">Variables</TabsTrigger>
              <TabsTrigger value="profile">Perfil</TabsTrigger>
            </TabsList>
          </Tabs>
        </CardHeader>

        <CardContent className="p-3 max-h-96 overflow-y-auto">
          <TabsContent value="connection" className="mt-0 space-y-3">
            <DiagnosticItem
              title="Conexión a Internet"
              status={diagnostics.networkStatus}
              description={diagnostics.networkStatus ? "Conectado" : "Sin conexión"}
            />
            <DiagnosticItem
              title="Variables de Entorno"
              status={diagnostics.environmentVars}
              description={diagnostics.environmentVars ? "Configuradas" : "No configuradas"}
            />
            <DiagnosticItem
              title="Conexión a Supabase"
              status={diagnostics.supabaseConnection}
              description={diagnostics.supabaseConnection ? "Conectado" : "No conectado"}
            />
            <DiagnosticItem
              title="Autenticación"
              status={diagnostics.authInitialized}
              description={diagnostics.authInitialized ? "Inicializada" : "No inicializada"}
            />
            <DiagnosticItem
              title="Router"
              status={diagnostics.routerWorking}
              description={diagnostics.routerWorking ? "Funcionando" : "No funciona"}
            />
            <DiagnosticItem
              title="Almacenamiento Local"
              status={diagnostics.storageAccess}
              description={diagnostics.storageAccess ? "Accesible" : "No accesible"}
            />
          </TabsContent>

          <TabsContent value="env" className="mt-0 space-y-3">
            {Object.entries(envVars).map(([key, value]) => (
              <div key={key} className="flex items-center justify-between">
                <div>
                  <div className="font-medium">{key}</div>
                  <div className="text-sm text-gray-500 font-mono">{maskValue(value)}</div>
                </div>
                {value ? (
                  <CheckCircle className="h-5 w-5 text-green-500" />
                ) : (
                  <AlertCircle className="h-5 w-5 text-red-500" />
                )}
              </div>
            ))}
            <Button
              onClick={() => setShowValues(!showValues)}
              className="w-full flex items-center justify-center gap-2 mt-2"
              variant="outline"
              size="sm"
            >
              {showValues ? (
                <>
                  <EyeOff className="h-4 w-4" />
                  <span>Ocultar valores</span>
                </>
              ) : (
                <>
                  <Eye className="h-4 w-4" />
                  <span>Mostrar valores</span>
                </>
              )}
            </Button>
          </TabsContent>

          <TabsContent value="profile" className="mt-0 space-y-3">
            <div>
              <h3 className="font-bold">Estado de autenticación:</h3>
              <p>Usuario: {session ? "Autenticado" : "No autenticado"}</p>
              <p>ID: {session?.user?.id || "N/A"}</p>
              <p>Email: {session?.user?.email || "N/A"}</p>
            </div>

            <div>
              <h3 className="font-bold">Estado de perfil:</h3>
              <p>Tiene perfil: {profileData?.data ? "Sí" : "No"}</p>
              {error && <p className="text-red-500">Error: {error}</p>}
            </div>

            {sessionData && (
              <div>
                <h3 className="font-bold">Datos de sesión:</h3>
                {sessionData.error ? (
                  <p className="text-red-500">Error: {JSON.stringify(sessionData.error)}</p>
                ) : (
                  <pre className="text-xs bg-gray-100 p-2 rounded overflow-auto max-h-40">
                    {JSON.stringify(sessionData.data, null, 2)}
                  </pre>
                )}
              </div>
            )}

            {profileData && (
              <div>
                <h3 className="font-bold">Datos de perfil:</h3>
                {profileData.error ? (
                  <p className="text-red-500">Error: {JSON.stringify(profileData.error)}</p>
                ) : (
                  <pre className="text-xs bg-gray-100 p-2 rounded overflow-auto max-h-40">
                    {JSON.stringify(profileData.data, null, 2)}
                  </pre>
                )}
              </div>
            )}

            <div className="flex gap-2 mt-2">
              <Button onClick={checkProfile} className="flex-1" variant="outline" size="sm" disabled={!session?.user}>
                Verificar Perfil
              </Button>
              <Button onClick={checkSession} className="flex-1" variant="outline" size="sm">
                Verificar Sesión
              </Button>
            </div>
          </TabsContent>
        </CardContent>

        <CardFooter className="p-3 pt-0">
          <Button
            onClick={runDiagnostics}
            disabled={isLoading}
            className="w-full flex items-center justify-center gap-2"
            variant="outline"
            size="sm"
          >
            {isLoading ? (
              <>
                <RefreshCw className="h-4 w-4 animate-spin" />
                <span>Verificando...</span>
              </>
            ) : (
              <>
                <RefreshCw className="h-4 w-4" />
                <span>Actualizar diagnósticos</span>
              </>
            )}
          </Button>
        </CardFooter>
      </Card>
    </div>
  )
}

function DiagnosticItem({ title, status, description }: { title: string; status: boolean; description: string }) {
  return (
    <div className="flex items-center justify-between">
      <div>
        <div className="font-medium">{title}</div>
        <div className="text-sm text-gray-500">{description}</div>
      </div>
      {status ? <CheckCircle className="h-5 w-5 text-green-500" /> : <AlertCircle className="h-5 w-5 text-red-500" />}
    </div>
  )
}
