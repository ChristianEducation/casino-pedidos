import AuthTest from "@/components/auth-test"

export default function TestAuthPage() {
  return (
    <div className="container mx-auto py-8">
      <h1 className="text-2xl font-bold mb-6">Prueba de Autenticación</h1>
      <p className="mb-6 text-gray-600">
        Esta página es pública y no está protegida por el middleware. Puedes acceder a ella sin iniciar sesión.
      </p>
      <AuthTest />
    </div>
  )
}
