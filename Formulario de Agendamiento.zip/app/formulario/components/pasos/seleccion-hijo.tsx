"use client"

import type React from "react"
import { useState } from "react"
import type { DatosHijo } from "../formulario-multi-step"

interface SeleccionHijoProps {
  hijos: DatosHijo[]
  hijoSeleccionado: DatosHijo | null
  seleccionarHijo: (hijo: DatosHijo) => void
  siguientePaso: () => void
}

export function SeleccionHijo({ hijos, hijoSeleccionado, seleccionarHijo, siguientePaso }: SeleccionHijoProps) {
  const [error, setError] = useState<string | null>(null)

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    if (!hijoSeleccionado) {
      setError("Por favor, selecciona un alumno para continuar")
      return
    }

    siguientePaso()
  }

  return (
    <div className="transition-all duration-300">
      <h2 className="text-xl font-semibold text-gray-800 mb-6">Selección de Alumno</h2>

      <div className="bg-blue-50 p-4 rounded-xl mb-6">
        <p className="text-sm text-blue-700">
          <span className="font-medium">¡Bienvenido de nuevo!</span> Hemos encontrado tus datos en nuestro sistema.
        </p>
        <p className="text-sm text-blue-700 mt-1">
          Por favor, selecciona el alumno para el que deseas realizar el pedido.
        </p>
      </div>

      <form onSubmit={handleSubmit}>
        <div className="space-y-6">
          {error && (
            <div className="bg-red-50 border border-red-200 rounded-xl p-4">
              <p className="text-red-600 text-sm">{error}</p>
            </div>
          )}

          <div className="grid gap-4">
            {hijos.map((hijo) => (
              <div
                key={hijo.id}
                className={`border rounded-xl p-4 cursor-pointer transition-all duration-200 ${
                  hijoSeleccionado?.id === hijo.id
                    ? "border-blue-500 bg-blue-50"
                    : "border-gray-200 hover:border-blue-300 hover:bg-blue-50/50"
                }`}
                onClick={() => seleccionarHijo(hijo)}
              >
                <div className="flex items-center">
                  <div className="flex-1">
                    <h3 className="font-medium text-gray-800">{hijo.nombre}</h3>
                    <p className="text-sm text-gray-600">
                      {hijo.curso} {hijo.letra} - {hijo.nivel}
                    </p>
                  </div>
                  <div className="flex items-center justify-center w-6 h-6 rounded-full border border-gray-300 bg-white">
                    {hijoSeleccionado?.id === hijo.id && <div className="w-3 h-3 rounded-full bg-blue-600"></div>}
                  </div>
                </div>
              </div>
            ))}
          </div>

          <div className="pt-4">
            <button
              type="submit"
              className="w-full bg-blue-600 text-white py-3 px-6 rounded-xl hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 transition-all duration-200"
            >
              Continuar
            </button>
          </div>
        </div>
      </form>
    </div>
  )
}
