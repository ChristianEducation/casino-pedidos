"use client"

import type React from "react"
import { useState, useEffect } from "react"
import { Plus, Trash2 } from "lucide-react"
import type { FormData, DatosHijo } from "../formulario-multi-step"

interface DatosUsuarioProps {
  formData: FormData
  actualizarFormData: (data: Partial<FormData>) => void
  siguientePaso: () => void
  anteriorPaso: () => void
}

export function DatosUsuario({ formData, actualizarFormData, siguientePaso, anteriorPaso }: DatosUsuarioProps) {
  const [error, setError] = useState<string | null>(null)

  // Efecto para actualizar el nombre del funcionario cuando cambian los datos del apoderado
  useEffect(() => {
    if (formData.tipoUsuario === "funcionario" && formData.nombreApoderado && formData.hijos.length > 0) {
      // Actualizar el nombre del funcionario en el primer hijo si es el funcionario
      const hijosFuncionario = formData.hijos.map((hijo, index) => {
        if (index === 0 && hijo.esFuncionario) {
          return {
            ...hijo,
            nombre: formData.nombreApoderado, // Actualizar con el nombre real del funcionario
          }
        }
        return hijo
      })

      // Solo actualizar si hay cambios
      if (hijosFuncionario[0]?.nombre !== formData.hijos[0]?.nombre) {
        actualizarFormData({
          hijos: hijosFuncionario,
        })
      }
    }
  }, [formData.tipoUsuario, formData.nombreApoderado, formData.hijos, actualizarFormData])

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    siguientePaso()
  }

  // Función para determinar el nivel según el curso
  const determinarNivel = (curso: string): string => {
    if (curso === "Prekinder" || curso === "Kinder") {
      return "Playground"
    } else if (["1st Grade", "2nd Grade", "3rd Grade", "4th Grade"].includes(curso)) {
      return "Lower"
    } else if (["5th Grade", "6th Grade", "7th Grade", "8th Grade"].includes(curso)) {
      return "Middle"
    } else if (["9th Grade", "10th Grade", "11th Grade", "12th Grade"].includes(curso)) {
      return "High"
    }
    return "Lower" // Valor por defecto
  }

  // Opciones para los cursos en formato EEUU
  const cursos = [
    "Prekinder",
    "Kinder",
    "1st Grade",
    "2nd Grade",
    "3rd Grade",
    "4th Grade",
    "5th Grade",
    "6th Grade",
    "7th Grade",
    "8th Grade",
    "9th Grade",
    "10th Grade",
    "11th Grade",
    "12th Grade",
  ]

  // Opciones para las letras del curso
  const letras = ["A", "B", "C", "D"]

  // Función para agregar un nuevo hijo
  const agregarHijo = () => {
    // Crear un nuevo hijo/alumno normal
    const nuevoHijo: DatosHijo = {
      id: `hijo_${Date.now()}`,
      nombre: "",
      curso: cursos[0],
      nivel: determinarNivel(cursos[0]),
      letra: "A",
      menu: {
        lunes: null,
        martes: null,
        miercoles: null,
        jueves: null,
        viernes: null,
      },
      colaciones: {
        lunes: null,
        martes: null,
        miercoles: null,
        jueves: null,
        viernes: null,
      },
      esFuncionario: false,
    }

    actualizarFormData({
      hijos: [...formData.hijos, nuevoHijo],
    })
  }

  // Función para eliminar un hijo
  const eliminarHijo = (id: string) => {
    // Si es el funcionario y es el único hijo, no permitir eliminarlo
    const hijoAEliminar = formData.hijos.find((h) => h.id === id)
    if (hijoAEliminar?.esFuncionario && formData.hijos.length === 1) {
      setError("No puedes eliminar tu propio registro como funcionario")
      return
    }

    actualizarFormData({
      hijos: formData.hijos.filter((hijo) => hijo.id !== id),
    })
  }

  // Función para actualizar los datos de un hijo
  const actualizarHijo = (id: string, datos: Partial<DatosHijo>) => {
    actualizarFormData({
      hijos: formData.hijos.map((hijo) => {
        if (hijo.id === id) {
          // Si estamos actualizando el curso, también actualizamos el nivel
          if (datos.curso) {
            return {
              ...hijo,
              ...datos,
              nivel: determinarNivel(datos.curso),
            }
          }
          return { ...hijo, ...datos }
        }
        return hijo
      }),
    })
  }

  // Función para determinar el texto del botón de agregar hijo
  const textoBotonAgregarHijo = () => {
    if (formData.tipoUsuario === "funcionario") {
      return "Agregar un hijo"
    } else {
      return formData.hijos.length === 0 ? "Agregar alumno" : "Agregar otro alumno"
    }
  }

  // Filtrar los hijos para mostrar solo los que no son el funcionario
  const hijosNoFuncionario = formData.hijos.filter(
    (hijo, index) => !(formData.tipoUsuario === "funcionario" && index === 0 && hijo.esFuncionario),
  )

  return (
    <div className="transition-all duration-300">
      <h2 className="text-xl font-semibold text-gray-800 mb-6">
        {formData.tipoUsuario === "funcionario" ? "Datos del Hijo" : "Datos del Alumno"}
      </h2>

      {formData.tipoUsuario === "funcionario" && (
        <div className="bg-[#F5F8EE] p-4 rounded-xl mb-6">
          <p className="text-sm text-gray-700">
            Como funcionario, puedes realizar pedidos para ti mismo y/o para tus hijos. Si tienes hijos en el colegio,
            puedes agregarlos usando el botón "Agregar un hijo".
          </p>
        </div>
      )}

      <form onSubmit={handleSubmit}>
        <div className="space-y-6">
          {error && (
            <div className="bg-red-50 border border-red-200 rounded-xl p-4">
              <p className="text-red-600 text-sm">{error}</p>
            </div>
          )}

          {/* Lista de hijos (excluyendo al funcionario) */}
          <div className="space-y-8">
            {hijosNoFuncionario.map((hijo, index) => (
              <div key={hijo.id} className="border border-gray-200 rounded-xl p-6 relative">
                <div className="absolute top-4 right-4">
                  <button
                    type="button"
                    onClick={() => eliminarHijo(hijo.id)}
                    className="text-red-500 hover:text-red-700 transition-colors"
                    aria-label="Eliminar alumno"
                  >
                    <Trash2 className="h-5 w-5" />
                  </button>
                </div>

                <h3 className="text-lg font-medium text-gray-800 mb-4">{`Alumno ${index + 1}`}</h3>

                <div className="space-y-4">
                  <div>
                    <label htmlFor={`nombre-${hijo.id}`} className="block text-base font-medium text-gray-700 mb-2">
                      Nombre del Alumno
                    </label>
                    <input
                      type="text"
                      id={`nombre-${hijo.id}`}
                      value={hijo.nombre}
                      onChange={(e) => actualizarHijo(hijo.id, { nombre: e.target.value })}
                      className="w-full px-4 py-3 rounded-xl border border-gray-300 focus:outline-none focus:ring-2 focus:ring-[#9ACA3C] focus:border-transparent transition-all duration-200"
                      placeholder="Ingresa el nombre del alumno"
                      required
                    />
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label htmlFor={`curso-${hijo.id}`} className="block text-base font-medium text-gray-700 mb-2">
                        Curso
                      </label>
                      <select
                        id={`curso-${hijo.id}`}
                        value={hijo.curso}
                        onChange={(e) => actualizarHijo(hijo.id, { curso: e.target.value })}
                        className="w-full px-4 py-3 rounded-xl border border-gray-300 focus:outline-none focus:ring-2 focus:ring-[#9ACA3C] focus:border-transparent transition-all duration-200"
                        required
                      >
                        {cursos.map((curso) => (
                          <option key={curso} value={curso}>
                            {curso}
                          </option>
                        ))}
                      </select>
                    </div>

                    <div>
                      <label htmlFor={`letra-${hijo.id}`} className="block text-base font-medium text-gray-700 mb-2">
                        Letra
                      </label>
                      <select
                        id={`letra-${hijo.id}`}
                        value={hijo.letra}
                        onChange={(e) => actualizarHijo(hijo.id, { letra: e.target.value })}
                        className="w-full px-4 py-3 rounded-xl border border-gray-300 focus:outline-none focus:ring-2 focus:ring-[#9ACA3C] focus:border-transparent transition-all duration-200"
                        required
                      >
                        {letras.map((letra) => (
                          <option key={letra} value={letra}>
                            {letra}
                          </option>
                        ))}
                      </select>
                    </div>
                  </div>

                  <div className="bg-[#F5F8EE] p-4 rounded-xl">
                    <p className="text-sm text-gray-700">
                      <span className="font-medium">Nivel educativo:</span> {hijo.nivel}
                    </p>
                    <p className="text-xs text-gray-600 mt-1">
                      El nivel se determina automáticamente según el curso seleccionado.
                    </p>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Botón para agregar otro hijo */}
          <button
            type="button"
            onClick={agregarHijo}
            className="w-full flex items-center justify-center py-3 px-6 border border-[#9ACA3C] text-[#9ACA3C] rounded-xl hover:bg-[#F5F8EE] focus:outline-none focus:ring-2 focus:ring-[#9ACA3C] focus:ring-offset-2 transition-all duration-200"
          >
            <Plus className="h-5 w-5 mr-2" />
            {textoBotonAgregarHijo()}
          </button>

          <div className="pt-4 flex space-x-4">
            <button
              type="button"
              onClick={anteriorPaso}
              className="w-1/2 bg-gray-200 text-gray-800 py-3 px-6 rounded-xl hover:bg-gray-300 focus:outline-none focus:ring-2 focus:ring-gray-500 focus:ring-offset-2 transition-all duration-200"
            >
              Anterior
            </button>
            <button
              type="submit"
              className="w-1/2 bg-[#9ACA3C] text-white py-3 px-6 rounded-xl hover:bg-[#8BB52E] focus:outline-none focus:ring-2 focus:ring-[#9ACA3C] focus:ring-offset-2 transition-all duration-200"
            >
              Siguiente
            </button>
          </div>
        </div>
      </form>
    </div>
  )
}
