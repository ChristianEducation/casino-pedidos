import { formatDateToLongString, getDayName, formatFechaLimite } from "@/lib/date-utils"

// Re-exportar funciones de date-utils para mantener compatibilidad
export { formatDateToLongString, getDayName, formatFechaLimite }

/**
 * Formatea una fecha en formato largo (5 de mayo de 2023)
 */
export function formatDate(dateString: string): string {
  const options: Intl.DateTimeFormatOptions = {
    year: "numeric",
    month: "long",
    day: "numeric",
    timeZone: "UTC",
  }

  return new Date(dateString).toLocaleDateString("es-ES", options)
}

/**
 * Formatea una fecha en formato corto (5 may)
 */
export function formatDateShort(dateString: string): string {
  const options: Intl.DateTimeFormatOptions = {
    day: "numeric",
    month: "short",
    timeZone: "UTC",
  }

  return new Date(dateString).toLocaleDateString("es-ES", options)
}
