import { createClient } from "@supabase/supabase-js"
import type { Database } from "@/types/supabase"

// Obtener las variables de entorno
const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL
const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY

// Validación mejorada de variables de entorno
if (!supabaseUrl || !supabaseAnonKey) {
  console.error("Error crítico: Variables de entorno de Supabase no definidas")
  if (typeof window !== "undefined") {
    // Solo mostrar alerta en el cliente
    console.warn("Variables de entorno faltantes: NEXT_PUBLIC_SUPABASE_URL o NEXT_PUBLIC_SUPABASE_ANON_KEY")
  }
}

// Variable global para almacenar la instancia única
let supabaseInstance: ReturnType<typeof createClient<Database>> | null = null

// Función para obtener la instancia de Supabase (singleton verdadero)
export const getSupabase = () => {
  // Si ya existe una instancia, devolverla
  if (supabaseInstance) return supabaseInstance

  // Verificar variables de entorno
  if (!supabaseUrl || !supabaseAnonKey) {
    console.error("Error: Variables de entorno de Supabase no definidas")
    return null
  }

  try {
    // Crear una nueva instancia con las variables de entorno
    console.log("Creando nueva instancia de Supabase con URL:", supabaseUrl.substring(0, 15) + "...")

    // Asegurarse de que la clave anónima esté presente
    if (!supabaseAnonKey.trim()) {
      throw new Error("La clave anónima de Supabase está vacía")
    }

    supabaseInstance = createClient<Database>(supabaseUrl, supabaseAnonKey, {
      auth: {
        persistSession: true,
        autoRefreshToken: true,
        detectSessionInUrl: true,
        storageKey: "supabase_auth_token",
      },
    })

    // Verificar que la instancia se creó correctamente
    if (!supabaseInstance) {
      throw new Error("No se pudo crear la instancia de Supabase")
    }

    console.log("Instancia de Supabase creada correctamente")
    return supabaseInstance
  } catch (error) {
    console.error("Error al crear instancia de Supabase:", error)
    return null
  }
}

// Reemplazar la exportación directa de supabase con una función que devuelva la instancia singleton

// Cambiar esta línea:
// Exportar getSupabase como método principal y no crear una instancia global

// Para compatibilidad con código existente, mantenemos la exportación de supabase
// pero como una función que siempre devuelve la misma instancia
export const supabase = getSupabase()

// Función para obtener el perfil del usuario con mejor manejo de errores y creación automática
export async function getUserProfile(userId: string) {
  // Obtener una instancia fresca de Supabase para evitar problemas con la API key
  const client = getSupabase()

  if (!client) {
    console.warn("Cliente de Supabase no inicializado. Usando perfil local.")
    return createLocalProfile(userId)
  }

  console.log("Buscando perfil para usuario:", userId)

  try {
    // Verificar que la API key esté presente en el cliente
    if (!client.supabaseKey) {
      console.error("API key no encontrada en el cliente de Supabase")
      return createLocalProfile(userId)
    }

    const { data, error } = await client.from("clientes_recurrentes").select("*").eq("telegram_id", userId).single()

    if (error) {
      // Si el error es que no se encontró el registro, intentar crear un perfil básico
      if (error.code === "PGRST116") {
        console.log("No se encontró perfil para el usuario, intentando crear uno básico")
        return await createBasicProfile(userId)
      }

      // Para otros errores, usar perfil local
      console.error("Error al obtener perfil de Supabase:", error)
      return createLocalProfile(userId)
    }

    console.log("Perfil encontrado:", data)

    // Guardar en localStorage para acceso offline
    try {
      localStorage.setItem(`profile_${userId}`, JSON.stringify(data))
    } catch (e) {
      console.warn("No se pudo guardar el perfil en localStorage:", e)
    }

    return data
  } catch (error) {
    console.error("Error en getUserProfile:", error)
    return createLocalProfile(userId)
  }
}

// Nueva función para crear un perfil básico en la base de datos
async function createBasicProfile(userId: string) {
  // Obtener una instancia fresca de Supabase
  const client = getSupabase()

  if (!client) {
    return createLocalProfile(userId)
  }

  try {
    // Obtener email del usuario
    const { data: userData, error: userError } = await client.auth.getUser()

    if (userError) {
      console.error("Error al obtener datos del usuario:", userError)
      return createLocalProfile(userId)
    }

    const email = userData?.user?.email || ""

    // Crear perfil básico
    const basicProfile = {
      telegram_id: userId,
      nombre_apoderado: "",
      correo_electronico: email,
      numero_telefono: "",
      hijos_info: [],
      tipo_usuario: "web",
      ultima_interaccion: new Date().toISOString(),
      conversation_state: "nuevo_usuario",
      last_action: "registro",
      session_context: null,
      last_pedido_state: "sin_pedidos",
      fecha_ultimo_pedido: null,
    }

    // Insertar el perfil básico
    const { data, error } = await client.from("clientes_recurrentes").insert(basicProfile).select().single()

    if (error) {
      console.error("Error al crear perfil básico:", error)
      return createLocalProfile(userId)
    }

    console.log("Perfil básico creado:", data)
    return data
  } catch (error) {
    console.error("Error al crear perfil básico:", error)
    return createLocalProfile(userId)
  }
}

// Función para crear un perfil local cuando no hay conexión
function createLocalProfile(userId: string) {
  console.log("Creando perfil local para:", userId)

  // Intentar recuperar perfil de localStorage
  try {
    const storedProfile = localStorage.getItem(`profile_${userId}`)
    if (storedProfile) {
      const profile = JSON.parse(storedProfile)
      console.log("Perfil recuperado de localStorage:", profile)
      return {
        ...profile,
        _is_local: true,
      }
    }
  } catch (e) {
    console.warn("Error al recuperar perfil de localStorage:", e)
  }

  // Si no hay perfil en localStorage, crear uno vacío
  return {
    telegram_id: userId,
    nombre_apoderado: "",
    correo_electronico: "",
    numero_telefono: "",
    hijos_info: [],
    tipo_usuario: "web",
    ultima_interaccion: new Date().toISOString(),
    conversation_state: "perfil_local",
    last_action: "error_conexion",
    session_context: null,
    last_pedido_state: "sin_pedidos",
    fecha_ultimo_pedido: null,
    _is_local: true, // Marcador para identificar perfiles locales
  }
}

// Función para iniciar sesión con Google
export async function signInWithGoogle(redirectTo?: string) {
  // Obtener una instancia fresca de Supabase
  const client = getSupabase()

  if (!client) {
    throw new Error("Cliente de Supabase no inicializado. Verifica las variables de entorno.")
  }

  try {
    // Construir URL de redirección
    const callbackUrl = `${window.location.origin}/auth/callback`
    const finalRedirectUrl = redirectTo ? `${callbackUrl}?redirect=${encodeURIComponent(redirectTo)}` : callbackUrl

    console.log("Iniciando OAuth con Google, redirección final:", finalRedirectUrl)

    const { data, error } = await client.auth.signInWithOAuth({
      provider: "google",
      options: {
        redirectTo: finalRedirectUrl,
      },
    })

    if (error) {
      console.error("Error al iniciar sesión con Google:", error)
      throw error
    }

    return data
  } catch (error) {
    console.error("Error al iniciar sesión con Google:", error)
    throw new Error(
      `Error al iniciar sesión con Google: ${error instanceof Error ? error.message : "Error desconocido"}`,
    )
  }
}

// Función para enviar datos al webhook de N8N
export async function sendToN8nWebhook(payload: any) {
  const webhookUrl = process.env.NEXT_PUBLIC_N8N_WEBHOOK_URL || ""

  if (!webhookUrl) {
    throw new Error("URL del webhook no configurada")
  }

  console.log("Enviando datos al webhook:", payload)

  try {
    const controller = new AbortController()
    const timeoutId = setTimeout(() => controller.abort(), 10000) // 10 segundos de timeout

    const response = await fetch(webhookUrl, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
      signal: controller.signal,
    })

    clearTimeout(timeoutId)

    if (!response.ok) {
      console.error("Error en respuesta del webhook:", response.statusText)
      throw new Error(`Error al enviar datos: ${response.statusText}`)
    }

    // Intentar parsear la respuesta como JSON
    try {
      const jsonResponse = await response.json()
      console.log("Respuesta del webhook:", jsonResponse)
      return jsonResponse
    } catch (e) {
      // Si no es JSON, devolver el texto
      const textResponse = await response.text()
      console.log("Respuesta del webhook (texto):", textResponse)
      return { success: true, text: textResponse }
    }
  } catch (error) {
    console.error("Error en la solicitud al webhook:", error)

    if (error instanceof Error && error.name === "AbortError") {
      throw new Error("La solicitud al webhook excedió el tiempo de espera")
    }

    if (error instanceof Error) {
      throw new Error(`Error al enviar datos al webhook: ${error.message}`)
    }

    throw new Error("Error desconocido al enviar datos al webhook")
  }
}

// Función para verificar si estamos en modo offline
export function isOfflineMode() {
  return typeof navigator !== "undefined" && !navigator.onLine
}

// Funciones para manejar redirecciones
export function saveRedirectUrl(url: string) {
  try {
    console.log("Guardando URL de redirección:", url)
    sessionStorage.setItem("auth_redirect", url)
    return true
  } catch (e) {
    console.warn("Error al guardar URL de redirección:", e)
    return false
  }
}

export function getRedirectUrl(defaultUrl = "/dashboard") {
  try {
    const redirectUrl = sessionStorage.getItem("auth_redirect")
    console.log("Recuperando URL de redirección:", redirectUrl || defaultUrl)

    // Limpiar después de usar
    if (redirectUrl) {
      sessionStorage.removeItem("auth_redirect")
    }

    return redirectUrl || defaultUrl
  } catch (e) {
    console.warn("Error al recuperar URL de redirección:", e)
    return defaultUrl
  }
}
