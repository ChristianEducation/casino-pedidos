"use client"

import { useEffect, useState, type ReactNode } from "react"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { AlertCircle } from "lucide-react"

export default function ConfigCheck({ children }: { children: ReactNode }) {
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    // Verificar que las variables de entorno necesarias estén definidas
    if (!process.env.NEXT_PUBLIC_SUPABASE_URL) {
      setError("La variable de entorno NEXT_PUBLIC_SUPABASE_URL no está definida")
      return
    }

    if (!process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY) {
      setError("La variable de entorno NEXT_PUBLIC_SUPABASE_ANON_KEY no está definida")
      return
    }

    if (!process.env.NEXT_PUBLIC_N8N_WEBHOOK_URL) {
      setError("La variable de entorno NEXT_PUBLIC_N8N_WEBHOOK_URL no está definida")
      return
    }

    // Si todas las variables están definidas, no hay error
    setError(null)
  }, [])

  if (error) {
    return (
      <div className="container mx-auto px-4 py-8">
        <Alert variant="destructive" className="mb-4">
          <AlertCircle className="h-4 w-4" />
          <AlertTitle>Error de configuración</AlertTitle>
          <AlertDescription>
            <p>{error}</p>
            <p className="mt-2">
              Por favor, asegúrate de que has configurado correctamente el archivo .env.local con las siguientes
              variables:
            </p>
            <pre className="mt-2 p-2 bg-gray-800 text-white rounded text-sm overflow-x-auto">
              {`NEXT_PUBLIC_SUPABASE_URL=https://koesipeybsasrknvgntg.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
NEXT_PUBLIC_N8N_WEBHOOK_URL=https://christianwevar.app.n8n.cloud/webhook-test/b3c993b7-d60b-46f9-a80a-7cbfae43fc87`}
            </pre>
          </AlertDescription>
        </Alert>
      </div>
    )
  }

  return <>{children}</>
}
