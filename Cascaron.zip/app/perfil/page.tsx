"use client"

import type React from "react"
import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { toast } from "@/components/ui/use-toast"
import { PlusCircle, Trash2, Loader2 } from "lucide-react"
import ProtectedRoute from "@/components/protected-route"
import { useSession, useSupabaseClient } from "@supabase/auth-helpers-react"
import { sendToN8nWebhook } from "@/lib/supabase-client"

// Tipo para los datos de un hijo
type ChildData = {
  nombre: string
  curso: number
  letra: string
  nivel: string
}

// Tipo para los datos del formulario
type FormData = {
  nombre: string
  telefono: string
  correo: string
  hijos: ChildData[]
}

// Función para calcular el nivel educativo basado en el curso
const calcularNivel = (curso: number): string => {
  if (curso >= 1 && curso <= 2) return "Playgroup"
  if (curso >= 3 && curso <= 4) return "Lower"
  if (curso >= 5 && curso <= 8) return "Middle"
  if (curso >= 9 && curso <= 12) return "High"
  return ""
}

export default function PerfilPage() {
  return (
    <ProtectedRoute>
      <PerfilContent />
    </ProtectedRoute>
  )
}

function PerfilContent() {
  const session = useSession()
  const supabase = useSupabaseClient()
  const router = useRouter()
  const [isLoading, setIsLoading] = useState(false)
  const [isLoadingProfile, setIsLoadingProfile] = useState(true)
  const [formData, setFormData] = useState<FormData>({
    nombre: "",
    telefono: "",
    correo: "",
    hijos: [{ nombre: "", curso: 1, letra: "A", nivel: "Playgroup" }],
  })

  // Cargar datos del perfil existente si hay
  useEffect(() => {
    const loadProfile = async () => {
      if (session?.user?.id) {
        try {
          setIsLoadingProfile(true)

          // Obtener perfil del usuario
          const { data: profile, error } = await supabase
            .from("clientes_recurrentes")
            .select("*")
            .eq("telegram_id", session.user.id)
            .single()

          if (error) {
            console.error("Error al cargar perfil:", error)
            // Si no existe el perfil, intentar crearlo
            if (error.code === "PGRST116") {
              await createBasicProfile(session.user.id, session.user.email || "")
            }
          }

          if (profile) {
            console.log("Cargando datos de perfil existente:", profile)

            // Actualizar el formulario con los datos existentes
            setFormData({
              nombre: profile.nombre_apoderado || "",
              telefono: profile.numero_telefono || "",
              correo: profile.correo_electronico || session.user.email || "",
              hijos:
                Array.isArray(profile.hijos_info) && profile.hijos_info.length > 0
                  ? profile.hijos_info.map((hijo: any) => ({
                      nombre: hijo.nombre || "",
                      curso: typeof hijo.curso === "number" ? hijo.curso : 1,
                      letra: hijo.letra || "A",
                      nivel: hijo.nivel || calcularNivel(typeof hijo.curso === "number" ? hijo.curso : 1),
                    }))
                  : [{ nombre: "", curso: 1, letra: "A", nivel: "Playgroup" }],
            })
          }
        } catch (error) {
          console.error("Error al cargar perfil:", error)
        } finally {
          setIsLoadingProfile(false)
        }
      } else {
        setIsLoadingProfile(false)
      }
    }

    loadProfile()
  }, [session, supabase])

  // Crear perfil básico si no existe
  const createBasicProfile = async (userId: string, email: string) => {
    try {
      const basicProfile = {
        telegram_id: userId,
        nombre_apoderado: "",
        correo_electronico: email,
        numero_telefono: "",
        hijos_info: [],
        tipo_usuario: "web",
        ultima_interaccion: new Date().toISOString(),
        conversation_state: "nuevo_usuario",
        last_action: "registro",
        session_context: null,
        last_pedido_state: "sin_pedidos",
        fecha_ultimo_pedido: null,
      }

      const { error } = await supabase.from("clientes_recurrentes").insert(basicProfile)

      if (error) {
        console.error("Error al crear perfil básico:", error)
      }
    } catch (error) {
      console.error("Error al crear perfil básico:", error)
    }
  }

  // Actualizar el correo cuando el usuario está disponible
  useEffect(() => {
    if (session?.user?.email && !formData.correo) {
      setFormData((prev) => ({
        ...prev,
        correo: session.user.email || "",
      }))
    }
  }, [session, formData.correo])

  // Manejar cambios en los campos del apoderado
  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }))
  }

  // Manejar cambios en los campos de los hijos
  const handleChildChange = (index: number, field: keyof ChildData, value: string | number) => {
    setFormData((prev) => {
      const newHijos = [...prev.hijos]
      newHijos[index] = {
        ...newHijos[index],
        [field]: value,
      }

      // Si el campo es curso, actualizar el nivel automáticamente
      if (field === "curso") {
        const cursoNum = typeof value === "string" ? Number.parseInt(value, 10) : value
        newHijos[index].nivel = calcularNivel(cursoNum)
      }

      return {
        ...prev,
        hijos: newHijos,
      }
    })
  }

  // Agregar un nuevo hijo
  const addChild = () => {
    setFormData((prev) => ({
      ...prev,
      hijos: [...prev.hijos, { nombre: "", curso: 1, letra: "A", nivel: "Playgroup" }],
    }))
  }

  // Eliminar un hijo
  const removeChild = (index: number) => {
    setFormData((prev) => {
      const newHijos = [...prev.hijos]
      newHijos.splice(index, 1)
      return {
        ...prev,
        hijos: newHijos,
      }
    })
  }

  // Enviar el formulario
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)

    try {
      if (!session?.user?.id) {
        throw new Error("Usuario no autenticado")
      }

      // Validar que todos los campos estén completos
      if (!formData.nombre || !formData.telefono || !formData.correo) {
        throw new Error("Por favor, completa todos los campos del apoderado")
      }

      // Validar que todos los hijos tengan nombre
      if (formData.hijos.some((hijo) => !hijo.nombre)) {
        throw new Error("Por favor, completa el nombre de todos los hijos")
      }

      // Preparar el payload para el webhook
      const webhookPayload = {
        tipo: "registro_perfil",
        datos: {
          user_id: session.user.id,
          nombre: formData.nombre,
          correo: formData.correo,
          telefono: formData.telefono,
          hijos: formData.hijos,
        },
      }

      console.log("Enviando datos al webhook:", webhookPayload)

      // Enviar al webhook
      await sendToN8nWebhook(webhookPayload)

      toast({
        title: "Perfil guardado",
        description: "Tu información ha sido enviada correctamente",
      })

      // Redirigir al dashboard
      router.push("/dashboard")
    } catch (error: any) {
      toast({
        title: "Error al guardar el perfil",
        description: error.message,
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  if (isLoadingProfile) {
    return (
      <div className="flex justify-center items-center min-h-[60vh]">
        <div className="text-center">
          <Loader2 className="h-8 w-8 animate-spin mx-auto mb-4 text-[#9ACA3C]" />
          <p className="text-gray-600">Cargando información del perfil...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="max-w-3xl mx-auto">
      <Card className="shadow-lg">
        <CardHeader className="bg-[#F5F8EE]">
          <CardTitle className="text-2xl text-[#9ACA3C]">Completa tu Perfil</CardTitle>
          <CardDescription>
            Esta información es necesaria para procesar tus pedidos. Por favor, completa todos los campos.
          </CardDescription>
        </CardHeader>
        <CardContent className="pt-6">
          <form onSubmit={handleSubmit} className="space-y-8">
            {/* Sección de datos del apoderado */}
            <div className="space-y-4">
              <h3 className="text-lg font-medium">Datos del Apoderado</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="nombre">Nombre Completo</Label>
                  <Input
                    id="nombre"
                    name="nombre"
                    value={formData.nombre}
                    onChange={handleChange}
                    placeholder="Nombre y apellidos"
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="telefono">Número de Teléfono</Label>
                  <Input
                    id="telefono"
                    name="telefono"
                    type="tel"
                    value={formData.telefono}
                    onChange={handleChange}
                    placeholder="912345678"
                    required
                  />
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="correo">Correo Electrónico</Label>
                <Input
                  id="correo"
                  name="correo"
                  type="email"
                  value={formData.correo}
                  onChange={handleChange}
                  placeholder="correo@ejemplo.com"
                  required
                  disabled={!!session?.user?.email}
                />
                {session?.user?.email && (
                  <p className="text-xs text-gray-500">
                    Este campo se completa automáticamente con tu correo de registro
                  </p>
                )}
              </div>
            </div>

            {/* Sección de datos de los hijos */}
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <h3 className="text-lg font-medium">Datos de los Hijos</h3>
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={addChild}
                  className="flex items-center gap-1"
                >
                  <PlusCircle className="h-4 w-4" />
                  <span>Agregar Hijo</span>
                </Button>
              </div>

              {formData.hijos.map((hijo, index) => (
                <Card key={index} className="p-4 border border-gray-200">
                  <div className="flex justify-between items-center mb-4">
                    <h4 className="font-medium">Hijo/a #{index + 1}</h4>
                    {formData.hijos.length > 1 && (
                      <Button
                        type="button"
                        variant="ghost"
                        size="sm"
                        onClick={() => removeChild(index)}
                        className="text-red-500 hover:text-red-700 hover:bg-red-50"
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    )}
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor={`hijo-nombre-${index}`}>Nombre</Label>
                      <Input
                        id={`hijo-nombre-${index}`}
                        value={hijo.nombre}
                        onChange={(e) => handleChildChange(index, "nombre", e.target.value)}
                        placeholder="Nombre y apellidos"
                        required
                      />
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor={`hijo-curso-${index}`}>Curso</Label>
                        <Select
                          value={hijo.curso.toString()}
                          onValueChange={(value) => handleChildChange(index, "curso", Number.parseInt(value, 10))}
                        >
                          <SelectTrigger id={`hijo-curso-${index}`}>
                            <SelectValue placeholder="Selecciona el curso" />
                          </SelectTrigger>
                          <SelectContent>
                            {Array.from({ length: 12 }, (_, i) => i + 1).map((curso) => (
                              <SelectItem key={curso} value={curso.toString()}>
                                {curso}º
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor={`hijo-letra-${index}`}>Letra</Label>
                        <Select value={hijo.letra} onValueChange={(value) => handleChildChange(index, "letra", value)}>
                          <SelectTrigger id={`hijo-letra-${index}`}>
                            <SelectValue placeholder="Selecciona la letra" />
                          </SelectTrigger>
                          <SelectContent>
                            {["A", "B", "C", "D", "E", "F"].map((letra) => (
                              <SelectItem key={letra} value={letra}>
                                {letra}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                  </div>
                  <div className="mt-4">
                    <Label htmlFor={`hijo-nivel-${index}`}>Nivel</Label>
                    <Input id={`hijo-nivel-${index}`} value={hijo.nivel} readOnly className="bg-gray-50" />
                    <p className="text-xs text-gray-500 mt-1">
                      El nivel se calcula automáticamente según el curso seleccionado
                    </p>
                  </div>
                </Card>
              ))}
            </div>

            <CardFooter className="px-0 pt-4">
              <Button type="submit" className="w-full bg-[#9ACA3C] hover:bg-[#8BB52E]" disabled={isLoading}>
                {isLoading ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Guardando...
                  </>
                ) : (
                  "Guardar Perfil"
                )}
              </Button>
            </CardFooter>
          </form>
        </CardContent>
      </Card>
    </div>
  )
}
