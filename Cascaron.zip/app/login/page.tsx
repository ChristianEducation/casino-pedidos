"use client"

import type React from "react"
import { useState, useEffect } from "react"
import { useRouter, useSearchParams } from "next/navigation"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { toast } from "@/components/ui/use-toast"
import Image from "next/image"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { AlertCircle, Loader2 } from "lucide-react"
import { useSupabaseClient } from "@supabase/auth-helpers-react"

export default function LoginPage() {
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [isGoogleLoading, setIsGoogleLoading] = useState(false)
  const [authError, setAuthError] = useState<string | null>(null)
  const supabase = useSupabaseClient()
  const router = useRouter()
  const searchParams = useSearchParams()

  // Manejar errores de URL
  useEffect(() => {
    const errorParam = searchParams?.get("error")
    if (errorParam) {
      setAuthError(decodeURIComponent(errorParam))
      toast({
        title: "Error de autenticación",
        description: decodeURIComponent(errorParam),
        variant: "destructive",
      })
    }
  }, [searchParams])

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)
    setAuthError(null)

    try {
      // Obtener redirección de los parámetros de búsqueda
      const redirectTo = searchParams?.get("redirect") || "/dashboard"
      console.log("Login: Iniciando sesión con redirección a:", redirectTo)

      // Intentar iniciar sesión
      const { data, error } = await supabase.auth.signInWithPassword({
        email,
        password,
      })

      if (error) throw error

      // Mostrar toast de éxito
      toast({
        title: "Inicio de sesión exitoso",
        description: "Redirigiendo...",
      })

      // Forzar la redirección manualmente después de un breve retraso
      // para permitir que el estado de autenticación se actualice
      setTimeout(() => {
        console.log("Redirigiendo manualmente a:", redirectTo)
        router.push(redirectTo)
      }, 500)
    } catch (error: any) {
      console.error("Error en inicio de sesión:", error)
      setAuthError(error.message || "Error al iniciar sesión")
      toast({
        title: "Error al iniciar sesión",
        description: error.message,
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  const handleGoogleSignIn = async () => {
    setIsGoogleLoading(true)
    setAuthError(null)

    try {
      // Obtener redirección de los parámetros de búsqueda
      const redirectTo = searchParams?.get("redirect") || "/dashboard"
      const callbackUrl = `${window.location.origin}/auth/callback`
      const finalRedirectUrl = redirectTo ? `${callbackUrl}?redirect=${encodeURIComponent(redirectTo)}` : callbackUrl

      console.log("Login: Iniciando sesión con Google, redirección a:", finalRedirectUrl)

      const { error } = await supabase.auth.signInWithOAuth({
        provider: "google",
        options: {
          redirectTo: finalRedirectUrl,
        },
      })

      if (error) throw error

      // No necesitamos redireccionar aquí, ya que OAuth redireccionará automáticamente
    } catch (error: any) {
      console.error("Error en inicio de sesión con Google:", error)
      setAuthError(error.message || "Error al iniciar sesión con Google")
      toast({
        title: "Error al iniciar sesión con Google",
        description: error.message,
        variant: "destructive",
      })
      setIsGoogleLoading(false)
    }
  }

  return (
    <div className="flex justify-center items-center min-h-[80vh]">
      <Card className="w-full max-w-md shadow-lg">
        <CardHeader className="space-y-1 bg-[#F5F8EE]">
          <div className="flex justify-center mb-4">
            <div className="relative w-48 h-16">
              <Image src="/images/logo.png" alt="Delicias Food Service" fill style={{ objectFit: "contain" }} />
            </div>
          </div>
          <CardTitle className="text-2xl text-center text-[#9ACA3C]">Iniciar Sesión</CardTitle>
          <CardDescription className="text-center">Ingresa tus credenciales para acceder a tu cuenta</CardDescription>
        </CardHeader>
        <CardContent className="pt-6">
          <div className="space-y-4">
            {authError && (
              <Alert variant="destructive">
                <AlertCircle className="h-4 w-4" />
                <AlertTitle>Error</AlertTitle>
                <AlertDescription>{authError}</AlertDescription>
              </Alert>
            )}

            {/* Botón de Google */}
            <Button
              type="button"
              variant="outline"
              className="w-full flex items-center justify-center gap-2"
              onClick={handleGoogleSignIn}
              disabled={isGoogleLoading || isLoading}
            >
              {isGoogleLoading ? (
                <Loader2 className="h-4 w-4 animate-spin" />
              ) : (
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24" className="h-5 w-5">
                  <path
                    fill="#4285F4"
                    d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                  />
                  <path
                    fill="#34A853"
                    d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                  />
                  <path
                    fill="#FBBC05"
                    d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"
                  />
                  <path
                    fill="#EA4335"
                    d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"
                  />
                </svg>
              )}
              <span>{isGoogleLoading ? "Iniciando sesión..." : "Continuar con Google"}</span>
            </Button>

            <div className="relative">
              <div className="absolute inset-0 flex items-center">
                <span className="w-full border-t border-gray-300" />
              </div>
              <div className="relative flex justify-center text-xs uppercase">
                <span className="bg-white px-2 text-gray-500">O continúa con</span>
              </div>
            </div>

            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="email">Correo Electrónico</Label>
                <Input
                  id="email"
                  type="email"
                  placeholder="correo@ejemplo.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                  className="border-gray-300 focus:border-[#9ACA3C] focus:ring-[#9ACA3C]"
                  disabled={isLoading || isGoogleLoading}
                />
              </div>
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <Label htmlFor="password">Contraseña</Label>
                  <Link href="/recuperar-password" className="text-sm text-[#9ACA3C] hover:underline">
                    ¿Olvidaste tu contraseña?
                  </Link>
                </div>
                <Input
                  id="password"
                  type="password"
                  placeholder="••••••••"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                  className="border-gray-300 focus:border-[#9ACA3C] focus:ring-[#9ACA3C]"
                  disabled={isLoading || isGoogleLoading}
                />
              </div>
              <Button
                type="submit"
                className="w-full bg-[#9ACA3C] hover:bg-[#8BB52E]"
                disabled={isLoading || isGoogleLoading}
              >
                {isLoading ? (
                  <div className="flex items-center justify-center gap-2">
                    <Loader2 className="h-4 w-4 animate-spin" />
                    <span>Iniciando sesión...</span>
                  </div>
                ) : (
                  "Iniciar Sesión"
                )}
              </Button>
            </form>
          </div>
        </CardContent>
        <CardFooter className="flex flex-col space-y-4">
          <div className="text-center text-sm">
            ¿No tienes una cuenta?{" "}
            <Link href="/registro" className="text-[#9ACA3C] hover:underline">
              Regístrate aquí
            </Link>
          </div>
        </CardFooter>
      </Card>
    </div>
  )
}
