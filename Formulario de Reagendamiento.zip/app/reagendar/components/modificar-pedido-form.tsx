"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Loader2, ArrowLeft, Check, AlertCircle, User, Calendar, Phone, Mail } from "lucide-react"
import type { Pedido, OpcionMenu, ClienteRecurrente, SemanaDisponible } from "@/types"
import { formatDate } from "@/utils/format-date"
import { getClienteInfo, actualizarPedido } from "@/utils/supabase"
import { getSemanasDisponibles } from "@/lib/date-utils"
import { getOpcionesMenuPorFecha } from "@/lib/menu-utils"

interface ModificarPedidoFormProps {
  pedido: Pedido
  onCancel: () => void
  onSuccess: () => void
  userId: string
}

export default function ModificarPedidoForm({ pedido, onCancel, onSuccess, userId }: ModificarPedidoFormProps) {
  // Estados
  const [nuevaFecha, setNuevaFecha] = useState<string>(pedido.fecha_entrega || pedido.dia_entrega)
  const [nuevaOpcion, setNuevaOpcion] = useState<string>(pedido.opcion_menu || "")
  const [semanas, setSemanas] = useState<SemanaDisponible[]>([])
  const [semanaSeleccionada, setSemanaSeleccionada] = useState<SemanaDisponible | null>(null)
  const [opciones, setOpciones] = useState<OpcionMenu[]>([])
  const [loading, setLoading] = useState(false)
  const [cargandoOpciones, setCargandoOpciones] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [success, setSuccess] = useState(false)
  const [clienteInfo, setClienteInfo] = useState<ClienteRecurrente | null>(null)
  const [cargandoCliente, setCargandoCliente] = useState(true)

  const router = useRouter()

  // Cargar información del cliente
  useEffect(() => {
    async function cargarInfoCliente() {
      setCargandoCliente(true)
      try {
        console.log(`Cargando información del cliente para: ${userId}`)
        const cliente = await getClienteInfo(userId)
        setClienteInfo(cliente)
        console.log("Información del cliente cargada:", cliente)
      } catch (err) {
        console.error("Error al cargar información del cliente:", err)
      } finally {
        setCargandoCliente(false)
      }
    }

    cargarInfoCliente()
  }, [userId])

  // Cargar semanas disponibles
  useEffect(() => {
    // Obtener semanas disponibles
    const semanasDisponibles = getSemanasDisponibles()
    setSemanas(semanasDisponibles)

    // Encontrar la semana que contiene la fecha actual del pedido
    const fechaPedido = pedido.fecha_entrega || pedido.dia_entrega
    const semanaConFechaPedido = semanasDisponibles.find((semana) => {
      return semana.dias.some((dia) => dia.fecha === fechaPedido && dia.disponible)
    })

    if (semanaConFechaPedido) {
      setSemanaSeleccionada(semanaConFechaPedido)
    } else if (semanasDisponibles.length > 0) {
      setSemanaSeleccionada(semanasDisponibles[0])
    }
  }, [pedido])

  // Cargar opciones de menú cuando cambia la fecha
  useEffect(() => {
    async function cargarOpcionesMenu() {
      if (!nuevaFecha) return

      setCargandoOpciones(true)
      setError(null)

      try {
        const opcionesMenu = await getOpcionesMenuPorFecha(nuevaFecha)
        setOpciones(opcionesMenu)

        // Si no hay opciones disponibles, mostrar mensaje
        if (opcionesMenu.length === 0) {
          setError("No hay opciones de menú disponibles para la fecha seleccionada")
        }

        // Si es la fecha original del pedido, seleccionar la opción original
        if (nuevaFecha === (pedido.fecha_entrega || pedido.dia_entrega) && pedido.opcion_menu) {
          setNuevaOpcion(pedido.opcion_menu)
        } else if (opcionesMenu.length > 0) {
          // Seleccionar la primera opción por defecto
          setNuevaOpcion(opcionesMenu[0].descripcion)
        } else {
          setNuevaOpcion("")
        }
      } catch (err) {
        console.error("Error al cargar opciones de menú:", err)
        setError("Error al cargar las opciones de menú")
        setNuevaOpcion("")
      } finally {
        setCargandoOpciones(false)
      }
    }

    cargarOpcionesMenu()
  }, [nuevaFecha, pedido])

  const handleSelectSemana = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const semanaId = e.target.value
    const semana = semanas.find((s) => s.id === semanaId) || null
    setSemanaSeleccionada(semana)

    // Seleccionar el primer día disponible de la semana
    if (semana) {
      const primerDiaDisponible = semana.dias.find((dia) => dia.disponible)
      if (primerDiaDisponible) {
        setNuevaFecha(primerDiaDisponible.fecha)
      }
    }
  }

  const handleSelectFecha = (fecha: string) => {
    setNuevaFecha(fecha)
  }

  const handleSelectOpcion = (e: React.ChangeEvent<HTMLSelectElement>) => {
    setNuevaOpcion(e.target.value)
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setError(null)

    try {
      // Usar fecha_entrega si está disponible, de lo contrario usar dia_entrega
      const fechaActualPedido = pedido.fecha_entrega || pedido.dia_entrega

      // Validar que la nueva fecha sea diferente a la actual o que la opción sea diferente
      if (nuevaFecha === fechaActualPedido && nuevaOpcion === pedido.opcion_menu) {
        setError("No se han realizado cambios en el pedido")
        setLoading(false)
        return
      }

      // Validar que se haya seleccionado una opción de menú
      if (!nuevaOpcion) {
        setError("Debe seleccionar una opción de menú")
        setLoading(false)
        return
      }

      // Actualizar el pedido en la base de datos
      if (!pedido.codigo) {
        throw new Error("El pedido no tiene un código válido")
      }

      const resultado = await actualizarPedido(pedido.codigo, nuevaFecha, nuevaOpcion)

      if (!resultado.success) {
        throw new Error(resultado.error || "Error al actualizar el pedido")
      }

      // Enviar datos a la API de reagendamiento para webhooks
      const reagendamientoData = {
        pedido_id: pedido.id,
        codigo_pedido: pedido.codigo,
        user_id: userId,
        fecha_anterior: fechaActualPedido,
        nueva_fecha: nuevaFecha,
        opcion_anterior: pedido.opcion_menu,
        nueva_opcion: nuevaOpcion,
      }

      await fetch("/api/reagendamiento", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(reagendamientoData),
      })

      setSuccess(true)

      // Esperar 2 segundos antes de redirigir
      setTimeout(() => {
        onSuccess()
        // Refrescar la página para mostrar los cambios
        router.refresh()
      }, 2000)
    } catch (err) {
      console.error("Error al actualizar el pedido:", err)
      setError(err instanceof Error ? err.message : "Error al actualizar el pedido. Por favor, intente nuevamente.")
    } finally {
      setLoading(false)
    }
  }

  if (success) {
    return (
      <div className="p-6 border rounded-lg bg-green-50 text-center">
        <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
          <Check className="h-6 w-6 text-green-600" />
        </div>
        <h3 className="text-xl font-semibold text-green-700 mb-2">¡Pedido actualizado con éxito!</h3>
        <p className="text-green-600 mb-4">El pedido ha sido reagendado correctamente.</p>
        <button
          onClick={onSuccess}
          className="px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700 transition-colors"
        >
          Volver a la lista de pedidos
        </button>
      </div>
    )
  }

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <button onClick={onCancel} className="flex items-center text-gray-600 hover:text-gray-800 transition-colors">
          <ArrowLeft className="h-4 w-4 mr-1" />
          <span>Volver</span>
        </button>
        <h2 className="text-xl font-semibold text-gray-700">Modificar Pedido</h2>
      </div>

      <div className="p-5 border rounded-lg bg-gray-50">
        <h3 className="font-medium text-gray-800 mb-3 text-lg">Información actual</h3>

        {cargandoCliente ? (
          <div className="flex items-center space-x-2 text-gray-500">
            <Loader2 className="w-4 h-4 animate-spin" />
            <span>Cargando información del cliente...</span>
          </div>
        ) : clienteInfo ? (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              {clienteInfo.nombre_apoderado && (
                <p className="mb-2 flex items-center">
                  <User className="h-4 w-4 mr-1 text-gray-500" />
                  <span className="font-medium">Apoderado:</span> {clienteInfo.nombre_apoderado}
                </p>
              )}

              {clienteInfo.hijos_info && clienteInfo.hijos_info.length > 0 && (
                <div className="mb-2">
                  <span className="font-medium">Estudiante(s):</span>
                  <ul className="mt-1 ml-5 list-disc">
                    {clienteInfo.hijos_info.map((hijo, index) => (
                      <li key={index}>
                        {hijo.nombre} {hijo.curso && `- ${hijo.curso}`}
                      </li>
                    ))}
                  </ul>
                </div>
              )}

              <p className="mb-2">
                <span className="font-medium">Tipo de pedido:</span> {pedido.tipo_pedido}
              </p>

              {clienteInfo.tipo_usuario && (
                <p className="mb-2">
                  <span className="font-medium">Tipo de usuario:</span> {clienteInfo.tipo_usuario}
                </p>
              )}
            </div>
            <div>
              <p className="mb-2 flex items-center">
                <Calendar className="h-4 w-4 mr-1 text-gray-500" />
                <span className="font-medium">Fecha de entrega:</span> {formatDate(pedido.dia_entrega)}
              </p>

              {pedido.opcion_menu && (
                <p className="mb-2">
                  <span className="font-medium">Opción de menú:</span> {pedido.opcion_menu}
                </p>
              )}

              {clienteInfo.numero_telefono && (
                <p className="mb-2 flex items-center">
                  <Phone className="h-4 w-4 mr-1 text-gray-500" />
                  <span className="font-medium">Teléfono:</span> {clienteInfo.numero_telefono}
                </p>
              )}

              {clienteInfo.correo_electronico && (
                <p className="mb-2 flex items-center">
                  <Mail className="h-4 w-4 mr-1 text-gray-500" />
                  <span className="font-medium">Email:</span> {clienteInfo.correo_electronico}
                </p>
              )}
            </div>
          </div>
        ) : (
          <div className="p-4 border rounded-md bg-gray-50 text-gray-500 flex items-center">
            <AlertCircle className="h-5 w-5 mr-2 text-gray-400" />
            <span>No se pudo cargar la información del cliente</span>
          </div>
        )}
      </div>

      {error && (
        <div className="p-4 border rounded-lg bg-red-50 text-red-700 flex items-start">
          <AlertCircle className="h-5 w-5 mr-2 flex-shrink-0 mt-0.5" />
          <span>{error}</span>
        </div>
      )}

      <form onSubmit={handleSubmit} className="space-y-5">
        <div>
          <label htmlFor="semanaSeleccionada" className="block text-sm font-medium text-gray-700 mb-2">
            Seleccionar semana
          </label>

          <select
            id="semanaSeleccionada"
            value={semanaSeleccionada?.id || ""}
            onChange={handleSelectSemana}
            className="w-full p-2 border rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
          >
            <option value="" disabled>
              Seleccionar semana
            </option>
            {semanas.map((semana) => (
              <option key={semana.id} value={semana.id}>
                Semana del {semana.label}
              </option>
            ))}
          </select>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">Seleccionar día</label>

          <div className="grid grid-cols-1 sm:grid-cols-3 md:grid-cols-5 gap-2">
            {semanaSeleccionada?.dias.map((dia) => (
              <button
                key={dia.fecha}
                type="button"
                onClick={() => dia.disponible && handleSelectFecha(dia.fecha)}
                disabled={!dia.disponible}
                className={`p-3 border rounded-md text-left transition-colors ${
                  !dia.disponible
                    ? "bg-gray-100 text-gray-400 cursor-not-allowed"
                    : nuevaFecha === dia.fecha
                      ? "bg-blue-50 border-blue-300 ring-2 ring-blue-200"
                      : "bg-white hover:bg-gray-50"
                }`}
              >
                <div className="flex flex-col">
                  <div className="flex items-center">
                    <Calendar className="h-3 w-3 mr-1 text-blue-600" />
                    <span className="font-medium text-blue-600">{dia.label.split(" ")[0]}</span>
                  </div>
                  <span className="text-gray-700">{dia.label.split(" ").slice(1).join(" ")}</span>
                </div>
              </button>
            ))}
          </div>

          <p className="mt-2 text-xs text-gray-500">
            <span className="font-medium">Nota:</span> Solo se muestran días hábiles (lunes a viernes) posteriores a la
            fecha actual.
          </p>
        </div>

        <div>
          <label htmlFor="nuevaOpcion" className="block text-sm font-medium text-gray-700 mb-2">
            Seleccionar opción de menú
          </label>

          {cargandoOpciones ? (
            <div className="p-3 border rounded-md bg-gray-50 text-gray-500 flex items-center justify-center">
              <Loader2 className="w-5 h-5 animate-spin mr-2" />
              <span>Cargando opciones de menú...</span>
            </div>
          ) : opciones.length > 0 ? (
            <select
              id="nuevaOpcion"
              value={nuevaOpcion}
              onChange={handleSelectOpcion}
              className="w-full p-2 border rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              required
            >
              <option value="">Seleccionar opción</option>
              {opciones.map((opcion) => (
                <option key={opcion.id} value={opcion.descripcion}>
                  {opcion.codigo} - {opcion.descripcion}
                </option>
              ))}
            </select>
          ) : (
            <div className="p-3 border rounded-md bg-yellow-50 text-yellow-700">
              No hay opciones de menú disponibles para la fecha seleccionada
            </div>
          )}
        </div>

        <div className="flex justify-end space-x-4 pt-2">
          <button
            type="button"
            onClick={onCancel}
            className="px-4 py-2 border text-gray-700 rounded-md hover:bg-gray-100 transition-colors"
            disabled={loading}
          >
            Cancelar
          </button>
          <button
            type="submit"
            className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors flex items-center justify-center min-w-[140px]"
            disabled={loading || !nuevaOpcion}
          >
            {loading ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                <span>Guardando...</span>
              </>
            ) : (
              "Guardar cambios"
            )}
          </button>
        </div>
      </form>
    </div>
  )
}
