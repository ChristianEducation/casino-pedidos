"use client"

import type React from "react"

import { useRouter } from "next/navigation"
import { useSession, useSupabaseClient } from "@supabase/auth-helpers-react"
import { useEffect, useState } from "react"
import { Loader2 } from "lucide-react"

export default function ProtectedRoute({ children }: { children: React.ReactNode }) {
  const session = useSession()
  const supabase = useSupabaseClient()
  const router = useRouter()
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    const checkSession = async () => {
      try {
        // Verificar si hay una sesión activa
        const { data, error } = await supabase.auth.getSession()

        if (error) {
          console.error("Error al verificar sesión:", error)
        }

        // Esperar un momento para asegurarnos de que la sesión se ha cargado completamente
        setTimeout(() => {
          setIsLoading(false)
        }, 100)
      } catch (error) {
        console.error("Error al verificar sesión:", error)
        setIsLoading(false)
      }
    }

    checkSession()
  }, [supabase.auth])

  useEffect(() => {
    // Solo redirigir cuando estemos seguros de que no hay sesión y la carga ha terminado
    if (!isLoading && !session) {
      router.replace("/login")
    }
  }, [session, isLoading, router])

  // Mostrar spinner mientras se carga
  if (isLoading) {
    return (
      <div className="flex justify-center items-center min-h-[60vh]">
        <div className="text-center">
          <Loader2 className="h-8 w-8 animate-spin mx-auto mb-4 text-[#9ACA3C]" />
          <p className="text-gray-600">Verificando sesión...</p>
        </div>
      </div>
    )
  }

  // Si no hay sesión, no renderizar nada (la redirección ya se está manejando)
  if (!session) {
    return null
  }

  // Si hay sesión, renderizar el contenido
  return <>{children}</>
}
