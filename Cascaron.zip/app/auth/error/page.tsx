"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { AlertTriangle } from "lucide-react"
import Link from "next/link"

export default function AuthErrorPage() {
  return (
    <div className="flex justify-center items-center min-h-[80vh]">
      <Card className="w-full max-w-md shadow-lg">
        <CardHeader className="space-y-1 bg-red-50">
          <div className="flex justify-center mb-4 text-red-500">
            <AlertTriangle size={48} />
          </div>
          <CardTitle className="text-2xl text-center text-red-600">Error de Autenticación</CardTitle>
          <CardDescription className="text-center">
            Ha ocurrido un error durante el proceso de autenticación.
          </CardDescription>
        </CardHeader>
        <CardContent className="pt-6">
          <div className="space-y-4">
            <p className="text-gray-700">Esto puede deberse a varias razones:</p>
            <ul className="list-disc pl-5 space-y-2 text-gray-600">
              <li>La configuración de OAuth en Google Cloud no está correctamente configurada</li>
              <li>Las URLs de redirección en Supabase no coinciden con las configuradas en Google Cloud</li>
              <li>El dominio de tu aplicación no está autorizado en la configuración de OAuth</li>
              <li>Problemas temporales con los servicios de autenticación</li>
            </ul>
          </div>
        </CardContent>
        <CardFooter className="flex flex-col space-y-4">
          <Button asChild className="w-full bg-[#9ACA3C] hover:bg-[#8BB52E]">
            <Link href="/login">Volver a Iniciar Sesión</Link>
          </Button>
          <div className="text-center text-sm text-gray-500">
            Si el problema persiste, por favor contacta al administrador del sistema.
          </div>
        </CardFooter>
      </Card>
    </div>
  )
}
