"use client"

import { useState } from "react"
import { ChevronDown } from "lucide-react"
import type { SemanaDisponible } from "@/types"

interface SelectWeekProps {
  weeks: SemanaDisponible[]
  selectedWeek: SemanaDisponible | null
  onSelectWeek: (week: SemanaDisponible) => void
  isLoading?: boolean
  error?: string | null
}

export function SelectWeek({ weeks, selectedWeek, onSelectWeek, isLoading = false, error = null }: SelectWeekProps) {
  const [isOpen, setIsOpen] = useState(false)

  const handleSelectWeek = (week: SemanaDisponible) => {
    onSelectWeek(week)
    setIsOpen(false)
  }

  if (isLoading) {
    return (
      <div className="w-full p-3 border rounded-md bg-gray-50 text-gray-500 flex items-center justify-center">
        <div className="w-5 h-5 border-t-2 border-b-2 border-blue-500 rounded-full animate-spin mr-2"></div>
        <span>Cargando semanas disponibles...</span>
      </div>
    )
  }

  if (error) {
    return <div className="w-full p-3 border rounded-md bg-red-50 text-red-600">{error}</div>
  }

  if (weeks.length === 0) {
    return (
      <div className="w-full p-3 border rounded-md bg-yellow-50 text-yellow-700">
        No hay semanas disponibles con menús
      </div>
    )
  }

  return (
    <div className="relative">
      <button
        type="button"
        onClick={() => setIsOpen(!isOpen)}
        className="w-full p-3 pr-10 border rounded-md bg-white text-left flex items-center justify-between focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
      >
        <span>{selectedWeek ? `Semana del ${selectedWeek.etiqueta}` : "Seleccionar semana"}</span>
        <ChevronDown className="h-5 w-5 text-gray-400" />
      </button>

      {isOpen && (
        <div className="absolute z-10 w-full mt-1 bg-white border rounded-md shadow-lg">
          {weeks.map((week) => (
            <button
              key={week.id}
              type="button"
              onClick={() => handleSelectWeek(week)}
              className={`w-full p-3 text-left hover:bg-gray-50 ${
                selectedWeek?.id === week.id ? "bg-blue-50 text-blue-700" : ""
              }`}
            >
              Semana del {week.etiqueta}
            </button>
          ))}
        </div>
      )}
    </div>
  )
}
